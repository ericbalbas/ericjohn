<?php
$servername='localhost';
$username='aics';
$password='';
$dbname='recording_management';

$conn=mysqli_connect($servername,$username,$password,$dbname);
if(!$conn){
    die('failed'.mysql_error());
}
?>
<?php
    include '../database/database.php';
    $servername='localhost';
    $username='root';
    $password='';
    $dbname='recording_management';
    
    
    $con = new mysqli($servername, $username, $password, $dbname);
    if($con->connect_errno > 0) {
      die('Connection failed [' . $con->connect_error . ']');
    }
    
    $tableName  = 'recording_management';
    $file = 'data.sql';
    $query= "SELECT * INTO OUTFILE '$file' FROM $tableName";

    
    if($query){
        echo "successfull";
    }
    $location = '../backup_data/';
    $rand = rand();
    $filename = $rand.$file ;
    $filePath = $location.$filename;
    $handle = fopen($location.$filename,'w+');
    fwrite($handle,$return);
    fclose($handle);
    
    


    $fileName = basename($filePath);
    $fileSize = filesize($filePath);

    header("Cache-Control: private");
    header("Content-Type: application/stream");
    header("Content-Length: ".$fileSize);
    header("Content-Disposition: attachment; filename=".$fileName);
   
      
    // Output file.
    readfile ($filePath);   
     
   
 ?>
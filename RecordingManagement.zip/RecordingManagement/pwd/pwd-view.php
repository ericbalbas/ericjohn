<?php
include_once '../database/database.php';
function validate($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

$id = $_GET['id'];

$sql = "Select * from `pwdprofile` where id=$id";
$result=mysqli_query($conn,$sql);
$row = mysqli_fetch_assoc($result);

$pwdno = validate($row['pwdno']);
$date = validate($row['date']);
$applicantname = validate($row['applicantname']);
$dob = validate($row['dob']);
$age = validate($row['age']);
$religion = validate($row['religion']);
$egroup = validate($row['egroup']);
$disability1 = validate($row['disability1']);
$disability2 = validate($row['disability2']);
$raddress = validate($row['raddress']);
$lno = validate($row['lno']);
$mno = validate($row['mno']);
$eadd = validate($row['eadd']);
$educational = validate($row['educational']);
$occupation = validate($row['occupation']);
$status = validate($row['status']);
$category = validate($row['category']);
$types = validate($row['types']);
$orgaffi = validate($row['orgaffi']);
$cperson = validate($row['cperson']);
$oadd = validate($row['oadd']);
$tnos = validate($row['tnos']);
$sno = validate($row['sno']);
$gno = validate($row['gno']);
$pno = validate($row['pno']);
$philno = validate($row['philno']);
$fathersname = validate($row['fathersname']);
$mothersname = validate($row['mothersname']);
$guardianname = validate($row['accomplished']);
$noru = validate($row['noru']);
$rno = validate($row['rno']);
$gender = validate($row['gender']);
?>
<?php
session_start();
if(isset($_SESSION['username']) && isset($_SESSION['id'])){
    $s_id = $_SESSION['id'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content ="IE=edge" />
    <meta name="viewport" content ="width=device-width, initial-scale=1.0" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
    <link rel="stylesheet" href="../aics/css/aicsstyle.css" />
    <link rel="stylesheet" type="text/css" href="../aics/css/print5.css" media="print">
    <title>Admi-PWD view</title>
</head>

<div class="d-flex" id="wrapper">
         <!-- Sidebar -->
         <div style="background:#232B2B" id="sidebar-wrapper">
        <div class="sidebar-heading text-center py-4 text-success fs-4 fw-bold text-uppercase text-light "><i
                    class="	fas fa-campground me-2"></i>e-rms</div>
            <div class="list-group list-group-flush my-3">
          
                <a href="../aics/admindashboard.php" class="list-group-item list-group-item-action bg-transparent text-light  fw-bold "><i
                        class="fas fa-tachometer-alt me-2"></i>Dashboard</a>
                <a class="list-group-item list-group-item-action bg-transparent text-light   fw-bold" 
                data-toggle="collapse" href="#collapse1">Reports</a>
                <div id="collapse1" class="list-group list-group-flush my-3 collapse">
                <a href="../report/senior-report.php" class="list-group-item list-group-item-action bg-transparent text-light   fw-bold"><i
                        class="fas fa-assistive-listening-systems ms-3"></i> Senior Citizen</a>
               
                <a href="../report/aics-report.php" class="list-group-item list-group-item-action bg-transparent text-light   fw-bold"><i
                        class="	fas fa-money-check-alt ms-3"></i> AICS</a>
                <a href="../report/pwd-report.php" class="list-group-item list-group-item-action bg-transparent text-light   fw-bold"><i
                class="	fas fa-heartbeat ms-3"></i> PWD</a>    
                </div>
               
                <a class="list-group-item list-group-item-action bg-transparent text-light  fw-bold" 
                data-toggle="collapse" href="#collapse2">Manage Records</a>
                <div id="collapse2" class="list-group list-group-flush my-3 collapse">
                <a href="../seniorcitizen/sc-display.php" class="list-group-item list-group-item-action bg-transparent text-light  fw-bold"><i
                        class="fas fa-assistive-listening-systems ms-3"></i> Senior Citizen</a>
            
                <a href="../aics/aicsdisplay.php" class="list-group-item list-group-item-action bg-transparent text-light   fw-bold"><i
                        class="fas fa-money-check-alt ms-3"></i> AICS</a>  
                <a href="../pwd/pwd-display.php" class="list-group-item list-group-item-action bg-transparent text-light   fw-bold"><i
                        class="fas fa-heartbeat ms-3"></i> PWD</a>
                </div>
                <a class="list-group-item list-group-item-action bg-transparent text-light  fw-bold" 
                data-toggle="collapse" href="#collapse3">Memorandum</a>
                <div id="collapse3" class="list-group list-group-flush my-3 collapse">
              
                <a href="../memorandum/display_memo.php" class="list-group-item list-group-item-action bg-transparent text-light   fw-bold"><i
                        class="	fas fa-file-signature ms-3"></i> Manage</a>
        
                </div>
    
                <a class="list-group-item list-group-item-action text-light bg-transparent fw-bold" 
                data-toggle="collapse" href="#collapse4">Settings</a>
                <div id="collapse4" class="list-group list-group-flush my-3 collapse">
                <a href="#" data-toggle="modal" data-target="#changeModal" class="list-group-item text-light list-group-item-action bg-transparent text-light fw-bold"><i
                    class="fa fa-cog me-2"></i> Change password</a> 
                    <a href="#" data-toggle="modal" data-target="#addModal" class="list-group-item text-light list-group-item-action bg-transparent text-light fw-bold"><i
                    class="fa fa-plus me-2"></i> Add user</a> 
                    <a href="../logs/admin_logs.php" class="list-group-item list-group-item-action text-light bg-transparent  fw-bold"><i
                        class="fas fa-tasks me-2"></i> Logs</a>
                        <a href="../backup/export.php" class="list-group-item list-group-item-action text-light bg-transparent  fw-bold"><i class="fa fa-archive" aria-hidden="true"></i>
                     Back up</a> 
                        </div>
                 <!-- Button trigger modal -->
                 
                    <!-- Modal -->
                    <div class="modal fade" id="changeModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                        <div class="modal-header text-center" style="background:#7dd07d">
                            <h5 class="modal-title fw-bold text-light " id="exampleModalLabel" ><i class="fa fa-cog me-2"></i>CHANGE PASSWORD</h5>
                            <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <style>
                                .form-control{
                                    border-top: 0;
                                    border-left: 0;
                                    border-right: 0;
   
                                }
                                .form-select{
                                    border-top: 0;
                                    border-left: 0;
                                    border-right: 0;
                                }
                                .form-select:focus{
                                    border-top: 0;
                                    border-left: 0;
                                    border-right: 0;
                                }
                                .form-control:focus{  
                                    box-shadow: none;
                                  
                                }
                            </style>
                        <form action="../login/changepass.php" method="POST" class="" autocomplete="off">
                        <div class="row">
                            <div class="col">
                                <label for="">Current Password</label>
                                    <input type="text" name="current" class="form-control" placeholder="Current Password" required>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col">
                                <label for="">New Password</label>
                                    <input type="Password" name="new" class="form-control" placeholder="New Password" required>
                                </div>
                        </div>
                        <div class="row">
                            <div class="col">
                                <label for="">Confirm Password</label>
                                    <input type="password" name="confirm" class="form-control" placeholder="Confirm Password" required>
                            </div>
                        </div>
                            
                        
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn fw-bold text-light text-uppercase mt-2" name="change_btn" style="background:#7dd07d">Change password</button>          
                         </form>
                              
                           
                        </div>
                        </div>
                    </div>
                    </div>    

                      <!-- Modal -->
                      <div class="modal fade" id="addModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                        <div class="modal-header" style="background:#7dd07d">
                            <h5 class="modal-title fw-bold text-light" id="exampleModalLabel"><i class="fa fa-cog me-2"></i>ADD USER</h5>
                            <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                        <!-- STATUS -->
                       
                    <!-- STATUS -->
                        
                        <form action="../login/add-user.php" method="POST" class="">
                        <div class="row">
                            <div class="col">
                                <label for="">Username</label>
                                <select class="form-select" name="add_username" required>
                                  <option value="" disable selected hidden>user</option>
                                  <option value="admin">admin</option>
                                  <option value="pwd">pwd</option>   
                                  <option value="senior">senior</option>
                                  <option value="aics">aics</option>     
                                </select>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col">
                                <label for="">Role</label>
                                <select class="form-select" name="add_role" required>
                                  <option value="" disable selected hidden>role</option>
                                  <option value="admin">admin</option>
                                  <option value="user">user</option>   
                                </select>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col">
                                <label for="">Password</label>
                                    <input type="Password" name="add_pass" class="form-control" placeholder="New Password" required>
                                </div>
                        </div>
                        <div class="row">
                            <div class="col">
                                <label for="">Confirm Password</label>
                                    <input type="password" name="add_confirm" class="form-control" placeholder="Confirm Password" required>
                            </div>
                        </div>
                           
                        
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn fw-bold text-light text-uppercase" name="add_btn" style="background:#7dd07d">Add user</button>          
                            </form>
                              
                           
                        </div>
                        </div>
                    </div>
                    </div>    
                <a href="#" data-toggle="modal" data-target="#logoutModal" class="list-group-item list-group-item-action bg-transparent text-light  fw-bold"><i
                        class="fas fa-power-off me-2"></i>Logout</a>
                <!-- Button trigger modal -->
                 
                    <!-- Modal -->
                    <div class="modal fade" id="logoutModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content ">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Warning</h5>
                            <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            Ready to leave the site?
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                           <form action="../login/logout.php" method="POST">
                               <button type="submit" name="logout_btn" class="btn btn-primary">logout</button>
                           </form>
                        </div>
                        </div>
                    </div>
                    </div>
            </div>
        </div>
        <!-- /#sidebar-wrapper -->

        <!-- Page Content  -->
        <div id="page-content-wrapper" style="background:#E0E0E0">
        
        <div class="d-flex px-3">
            <div class="flex-grow-1 ">
                <nav class="navbar navbar-expand navbar-light bg-transparent text-light">
                    <div class="d-flex align-items-center">
                        <i class="fas fa-align-left text-dark fs-4 me-3" id="menu-toggle"></i>
                        <h2 class="fs-3 m-0 fw-bold text-dark text-uppercase border-bottom">PWD</h2>
                    </div>      
                </nav>
            </div>
            <div class="pt-2">
                <div class="dropdown show">
                    <a class="btn btn-secondary bg-transparent dropdown-toggle border-0 text-dark" href="#" role="button" id="btn_print" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i class="fa fa-cog me-2"></i> Action
                    </a>

                    <div class="dropdown-menu" aria-labelledby="btn_print">
                        <a href="pwd-update.php?id=<?php echo $id?>"
                            class="text-dark text-decoration-none dropdown-item text-uppercase fw-bold" id="btn_print"><i class="fa fa-edit"></i> Update</a>
                            <a href="#" data-toggle="modal" data-target="#deleteModal" class=" dropdown-item text-uppercase fw-bold  " id="btn_print"><i class="fa fa-trash"></i>delete</a>    
                            <button onclick="window.print();" class="btn bg-transparent text-uppercase fw-bold dropdown-item " id="btn_print"><i class="fas fa-print"></i> print</button>                  
                        </div>
                        <div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Warning</h5>
                                <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                            <form action="../pwd/pwd-delete.php" method="POST" >
                                Please enter password to delete.
                                <input type="hidden" class="form-control" name="id" value="<?php echo $id ?>">
                                <input type="password" class="form-control" name="con" placeholder="Password" required>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                <button type="submit" name="delete_btn" class="btn btn-primary">delete</button>
                            </form>
                            </div>
                            </div>
                        </div>
                        </div>
                </div>
            </div>
        </div>

            <div class="container-fluid px-3"> 
                <div class="scrollable rounded">
                <style>
                     .scrollable{
                                height: 720px;
                                overflow: auto;
                    }
                    .scrollable::-webkit-scrollbar {
                                display: none;
                    }
                    .scrollable .d-flex img {
                        width: 90px;
                        
                    }
                </style>
               
                <form id="form" action="" method="POST" class="bg-light px-2" autocomplete="off"> 
                         <div class="d-flex align-items-center pt-2">
                            <img src="../asset/aics.png" class="me-4 mt-2 " alt="">  
                            <label for="" class="fw-bold">Republic of the Philippine<br>Province of La Union<br>
                            Municipality of Tubao <br>Municipal Social Welfare and Development <br>
                            </label><br>
                           
                        </div>      
                    <div class="text-center">
                         <label class="text-center my-3"><h3>APPLICATION FORM</h3></label>
                    </div>
                 
                    <div class="row">
                    <style>
                            .form-control{
                                border-top: 0;
                                border-left: 0;
                                border-right: 0;
                               
                
                            }
                            .form-control:focus{  
                                box-shadow: none;
                            }
                        </style>
                        <div class="col">
                            <div class="form-group">
                            <label for=""><b>PWD NUMBER</b></label>
                            <input type="text" class="form-control" value="<?php echo $row['pwdno']; ?>" name="pwdno" placeholder="PWD number" readonly>   
                            </div>
                        </div>
                        
                        <div class="col">
                            <div class="form-group">
                            <label for=""><b>DATE APPLIED</b></label>
                            <input type="date" class="form-control" value="<?php echo $row['date']; ?>" name="date" readonly>   
                            </div>
                        </div>
                        <div class="col">
                        <label for="" class="fw-bold">GENDER</label>
                        <input type="text" class="form-control" value="<?php echo $row['gender']; ?>" name="gender" placeholder="gender" readonly>
                        </div>  
                    </div>
                    <label for=""><b>PERSONAL INFORMATION</b></label>
                    <div class="row">
                        <div class="col">
                            <div class="form-group">
                                <input type="text" class="form-control" value="<?php echo $row['applicantname']; ?>" name="applicantname" placeholder="FULLNAME(LASTNAME, FIRSTNAME MIDDLENAME SUFFIX)" readonly>
                            </div>
                        </div>  
                        
                    </div>
                    <div class="row">
                        <div class="col">
                            <label for=""><b>DATE OF BIRTH</b></label>
                                <div class="form-group">
                                    <input type="date" class="form-control" value="<?php echo $row['dob']; ?>" name="dob" placeholder="DATE OF BIRTH"readonly>
                                </div>
                            </div>
                            <div class="col">
                                <div class="form-group">
                                <label for="" class="fw-bold">AGE</label>
                                    <input type="text" class="form-control" value="<?php echo $row['age']; ?>" name="age" placeholder="AGE" readonly>
                                </div>
                            </div>
                            <div class="col">
                            <label for="" class="fw-bold">RELIGION</label>
                                <div class="form-group">
                                    <input type="text" class="form-control" value="<?php echo $row['religion']; ?>" name="religion" placeholder="RELIGION"readonly>
                                </div>
                            </div>
                            <div class="col">
                                <label for="" class="fw-bold">ETHNIC GROUP</label>
                                    <div class="form-group">
                                        <input type="text" class="form-control" value="<?php echo $row['egroup']; ?>" name="egroup" placeholder="ETHNIC GROUP"readonly>
                                    </div>
                            </div>
                    </div>
                     <div class="row">
                             <div class="col-auto">
                                    <label class="form-label fw-bold" >Type of Disability</label>
                                    <input class="form-control" value="<?php echo $row['disability1']; ?>" name="disability1" readonly> 
                                      
                                </div>
                                <div class="col-auto">
                                    <label class="form-label fw-bold" ">Cause of Disability</label>
                                    <input class="form-control" value="<?php echo $row['disability2']; ?>" name="disability2"readonly>
                    </div>
                    <div class="row">
                            <label for="" class="fw-bold">RESIDENCE ADDRESS</label>
                            <div class="col">
                                <input type="text" class="form-control" value="<?php echo $row['raddress']; ?>" name="raddress" placeholder="House # and Street / Barangay / Municipality / Province / Region" readonly>
                            </div>
                    </div>
                    <div class="row">
                        <label for="" class="fw-bold">CONTACT DETAILS</label>
                        <div class="col">
                        <input type="text" class="form-control" value="<?php echo $row['lno']; ?>" name="lno" placeholder="Landline No."readonly>
                        </div>
                        <div class="col">
                        <input type="text" class="form-control" value="<?php echo $row['mno']; ?>" name="mno" placeholder="Mobile No."readonly>
                        </div>
                        <div class="col">
                        <input type="text" class="form-control" value="<?php echo $row['eadd']; ?>" name="eadd" placeholder="Email Address"readonly>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col">
                            <label for="" class="fw-bold">EDUCATIONAL ATTAINMENT </label>
                            <input class="form-control" value="<?php echo $row['educational']; ?>" name="educational">
                        </div>
                        <div class="col">
                            <label for="" class="fw-bold">OCCUPATION</label>
                            <input type="text" class="form-control" value="<?php echo $row['occupation']; ?>" name="occupation" placeholder="Occupation"readonly>
                        </div>
                        
                    </div>
                    <div class="row">
                        <div class="col">
                                <label for="" class="fw-bold">STATUS OF EMPLOYMENT </label>
                                <input class="form-control" value="<?php echo $row['status']; ?>" name="status"readonly>
                                            
                                </select>
                        </div>
                        <div class="col">
                                <label for="" class="fw-bold">CATEGORY OF EMPLOYMENT </label>
                                <input class="form-control" value="<?php echo $row['category']; ?>" name="category"readonly>
                        </div>
                        <div class="col">
                                <label for="" class="fw-bold">TYPES OF EMPLOYMENT </label>
                                <input class="form-control" value="<?php echo $row['types']; ?>" name="types"readonly>
                                         
                        </div>
                    </div>
                    <div class="row">
                        <label for="" class="fw-bold"> ORGANIZATION INFORMATION</label>
                        <div class="col">
                        <input type="text" class="form-control" value="<?php echo $row['orgaffi']; ?>" name="orgaffi" placeholder="Organization Affiliated"readonly>
                        </div>
                        <div class="col">
                        <input type="text" class="form-control" value="<?php echo $row['cperson']; ?>" name="cperson" placeholder="Contact Person"readonly>
                        </div>
                        <div class="col"> 
                        <input type="text" class="form-control" value="<?php echo $row['oadd']; ?>" name="oadd" placeholder="Office Address"readonly>
                        </div>
                        <div class="col">
                        <input type="text" class="form-control" value="<?php echo $row['tnos']; ?>" name="tnos" placeholder="Tel. Nos" readonly>
                        </div>
                    </div>
                    <div class="row">
                        <label for="" class="fw-bold"> ID REFERRENCES NO.</label>
                        <div class="col">
                        <input type="text" class="form-control" value="<?php echo $row['sno']; ?>" name="sno" placeholder="SSS NO." readonly>
                        </div>
                        <div class="col">
                        <input type="text" class="form-control" value="<?php echo $row['gno']; ?>" name="gno" placeholder="GSIS NO." readonly>
                        </div>
                        <div class="col">
                        <input type="text" class="form-control" value="<?php echo $row['pno']; ?>" name="pno" placeholder="PAG-IBIG NO." readonly>
                        </div>
                        <div class="col">
                        <input type="text" class="form-control mb-4" value="<?php echo $row['philno']; ?>" name="philno" placeholder="PhilHealth NO." readonly>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col">
                            <label for="" class="fw-bold">FAMILY BACKGROUND</label>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-auto">
                            <label for="" >FATHER'S NAME</label>
                        </div>
                        <div class="col">
                            <input type="text" class="form-control" value="<?php echo $row['fathersname']; ?>" name="fathersname" placeholder="FULLNAME(LASTNAME, FIRSTNAME MIDDLENAME)" readonly>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-auto">
                            <label for="" >MOTHER'S NAME</label>
                        </div>
                        <div class="col">
                            <input type="text" class="form-control" value="<?php echo $row['mothersname']; ?>" name="mothersname" placeholder="FULLNAME(LASTNAME, FIRSTNAME MIDDLENAME)" readonly>
                        </div>

                    </div>
                    <div class="row">
                        <div class="col-auto">
                            <label for="">GUARDIAN'S NAME</label>
                        </div>
                        <div class="col">
                            <input type="text" class="form-control " value="<?php echo $row['guardianname']; ?>" name="guardianname" placeholder="FULLNAME(LASTNAME, FIRSTNAME MIDDLENAME)" readonly>
                        </div>
                       
                    </div>

                    <div class="row ">
                        <div class="col-auto">
                            <label for="" class="fw-bold" >ACCOMPLISHED BY</label>
                        </div>
                        <div class="col">
                            <input type="text" class="form-control" value="<?php echo $row['accomplished']; ?>" name="accomplished" placeholder="FULLNAME(LASTNAME, FIRSTNAME MIDDLENAME)" readonly>
                        </div>
                       
                    </div>
                    <div class="row mt-5">
                            <label for="" class="fw-bold" >NAME OF REPORTING UNIT</label>
                        <div class="col">
                            <input type="text" class="form-control" value="<?php echo $row['noru']; ?>" name="noru" placeholder="Name of reporting unit" readonly>
                        </div>
                    </div>
                    <div class="row">
                            <label for="" class="fw-bold" >REGISTRATION NUMBER</label>
                        <div class="col-sm-2">
                            <input type="text" class="form-control mb-3" value="<?php echo $row['rno']; ?>" name="rno" placeholder="registration no." readonly>
                        </div>
                    </div>
                   
                </form>
                </div>
      

            </div>
            
     </div>
     <!-- /#page-content -wrapper -->
    </div>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>  
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script>
              
        var el = document.getElementById("wrapper");
        var toggleButton = document.getElementById("menu-toggle");

        toggleButton.onclick = function () {
            el.classList.toggle("toggled");
        };
    </script>
</body>

</html>
<?php
}else{  
    header("location:../login/LoginForm.php");     
}
?>
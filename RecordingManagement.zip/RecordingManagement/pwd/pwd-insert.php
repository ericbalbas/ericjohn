<?php
session_start();
include_once '../database/database.php';
function validate($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

if(isset($_POST['submit'])){

    $pwdno = validate(mysqli_real_escape_string($conn,$_POST['pwdno']));
    $date = validate(mysqli_real_escape_string($conn,$_POST['date']));
    $applicantname = validate(mysqli_real_escape_string($conn,$_POST['applicantname']));
    $dob = validate(mysqli_real_escape_string($conn,$_POST['dob']));
    
    $religion = validate(mysqli_real_escape_string($conn,$_POST['religion']));
    $egroup = validate(mysqli_real_escape_string($conn,$_POST['egroup']));
    $disability1 = validate(mysqli_real_escape_string($conn,$_POST['disability1']));
    $disability2 = validate(mysqli_real_escape_string($conn,$_POST['disability2']));

    $raddress = validate(mysqli_real_escape_string($conn,$_POST['raddress']));
    $lno = validate(mysqli_real_escape_string($conn,$_POST['lno']));
    $mno = validate(mysqli_real_escape_string($conn,$_POST['mno']));
    $eadd = validate(mysqli_real_escape_string($conn,$_POST['eadd']));
    $educational = validate(mysqli_real_escape_string($conn,$_POST['educational']));
    $occupation = validate(mysqli_real_escape_string($conn,$_POST['occupation']));
    $status = validate(mysqli_real_escape_string($conn,$_POST['status']));
    $category = validate(mysqli_real_escape_string($conn,$_POST['category']));
    $types = validate(mysqli_real_escape_string($conn,$_POST['types']));
    $orgaffi = validate(mysqli_real_escape_string($conn,$_POST['orgaffi']));
    $cperson = validate(mysqli_real_escape_string($conn,$_POST['cperson']));
    $oadd = validate(mysqli_real_escape_string($conn,$_POST['oadd']));
    $tnos = validate(mysqli_real_escape_string($conn,$_POST['tnos']));
    $sno = validate(mysqli_real_escape_string($conn,$_POST['sno']));
    $gno = validate(mysqli_real_escape_string($conn,$_POST['gno']));
    $pno = validate(mysqli_real_escape_string($conn,$_POST['pno']));
    $philno = validate(mysqli_real_escape_string($conn,$_POST['philno']));
    $fathersname = validate(mysqli_real_escape_string($conn,$_POST['fathersname']));
    $mothersname = validate(mysqli_real_escape_string($conn,$_POST['mothersname']));
    $guardianname = validate(mysqli_real_escape_string($conn,$_POST['guardianname']));
    $accomplished = validate(mysqli_real_escape_string($conn,$_POST['accomplished']));
    $noru = validate(mysqli_real_escape_string($conn,$_POST['noru']));
    $rno = validate(mysqli_real_escape_string($conn,$_POST['rno']));
    $gender = validate(mysqli_real_escape_string($conn,$_POST['gender']));
   

    $currentDate = date("d-m-Y");
    $diff = date_diff(date_create($dob), date_create($currentDate));
    $age = $diff->format('%y');
    
   
    $sql = "INSERT INTO pwdprofile(pwdno,date,applicantname,dob,age,religion,egroup,
    disability1,disability2,raddress,lno,mno,eadd,educational,occupation,status,category,types,
    orgaffi,cperson,oadd,tnos,sno,gno,pno,philno,fathersname,mothersname,guardianname,accomplished,
    noru,rno,gender) 
    VALUES 
    ('$pwdno','$date','$applicantname','$dob','$age','$religion','$egroup','$disability1','$disability2',
    '$raddress','$lno','$mno','$eadd','$educational','$occupation',' $status',' $category','$types','$orgaffi','$cperson',
    '$oadd','$tnos','$sno',' $gno','$pno','$philno','$fathersname','$mothersname','$guardianname','$accomplished','$noru','$rno','$gender')";

if(mysqli_query($conn, $sql)){
    date_default_timezone_set('Asia/Manila');
    $action="INSERT";// query for inser user log in to data base
      $date = date('m/d/Y h:i:s', time());
      $data = $applicantname;
      $user = "ADMIN";
      mysqli_query($conn,"insert into pwd_logs(session,date,data,user) values('$action','$date','$data','$user')");
    $_SESSION['pwdstatus']="Record inserted successfully!";
    header('location:../pwd/pwd-display.php');
    
}else{
    $_SESSION['pwdstatus']="Record failed to insert!";
    header('location:../pwd/pwd-form.php');
}
mysqli_close($conn);
}


?>
<?php
session_start();
include_once '../../database/database.php';
function validate($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

$id = $_GET['id'];

$sql = "Select * from `pwdprofile` where id=$id";
$result=mysqli_query($conn,$sql);
$row = mysqli_fetch_assoc($result);

$pwdno = validate($row['pwdno']);
$date = validate($row['date']);
$applicantname = validate($row['applicantname']);
$dob = validate($row['dob']);
$age = validate($row['age']);
$religion = validate($row['religion']);
$egroup = validate($row['egroup']);
$disability1 = validate($row['disability1']);
$disability2 = validate($row['disability2']);
$raddress = validate($row['raddress']);
$lno = validate($row['lno']);
$mno = validate($row['mno']);
$eadd = validate($row['eadd']);
$educational = validate($row['educational']);
$occupation = validate($row['occupation']);
$status = validate($row['status']);
$category = validate($row['category']);
$types = validate($row['types']);
$orgaffi = validate($row['orgaffi']);
$cperson = validate($row['cperson']);
$oadd = validate($row['oadd']);
$tnos = validate($row['tnos']);
$sno = validate($row['sno']);
$gno = validate($row['gno']);
$pno = validate($row['pno']);
$philno = validate($row['philno']);
$fathersname = validate($row['fathersname']);
$mothersname = validate($row['mothersname']);
$guardianname = validate($row['accomplished']);
$noru = validate($row['noru']);
$rno = validate($row['rno']);

if(isset($_POST['update'])){
    $pwdno = validate(mysqli_real_escape_string($conn,$_POST['pwdno']));
    $date = validate(mysqli_real_escape_string($conn,$_POST['date']));
    $applicantname = validate(mysqli_real_escape_string($conn,$_POST['applicantname']));
    $dob  = validate(mysqli_real_escape_string($conn,$_POST['dob']));
   
    $religion = validate(mysqli_real_escape_string($conn,$_POST['religion']));
    $egroup = validate(mysqli_real_escape_string($conn,$_POST['egroup']));
    $disability1 = validate(mysqli_real_escape_string($conn,$_POST['disability1']));
    $disability2 = validate(mysqli_real_escape_string($conn,$_POST['disability2']));
    $raddress = validate(mysqli_real_escape_string($conn,$_POST['raddress']));
    $lno = validate(mysqli_real_escape_string($conn,$_POST['lno']));
    $mno = validate(mysqli_real_escape_string($conn,$_POST['mno']));
    $eadd = validate(mysqli_real_escape_string($conn,$_POST['eadd']));
    $educational = validate(mysqli_real_escape_string($conn,$_POST['educational']));
    $occupation = validate(mysqli_real_escape_string($conn,$_POST['occupation']));
    $status = validate(mysqli_real_escape_string($conn,$_POST['status']));
    $category = validate(mysqli_real_escape_string($conn,$_POST['category']));
    $types = validate(mysqli_real_escape_string($conn,$_POST['types']));
    $orgaffi = validate(mysqli_real_escape_string($conn,$_POST['orgaffi']));
    $cperson = validate(mysqli_real_escape_string($conn,$_POST['cperson']));
    $tnos = validate(mysqli_real_escape_string($conn,$_POST['tnos']));
    $sno = validate(mysqli_real_escape_string($conn,$_POST['sno']));
    $gno = validate(mysqli_real_escape_string($conn,$_POST['gno']));
    $pno = validate(mysqli_real_escape_string($conn,$_POST['pno']));
    $philno = validate(mysqli_real_escape_string($conn,$_POST['philno']));
    $fathersname = validate(mysqli_real_escape_string($conn,$_POST['fathersname']));
    $mothersname  = validate(mysqli_real_escape_string($conn,$_POST['mothersname']));
    $guardianname = validate(mysqli_real_escape_string($conn,$_POST['guardianname']));
    $noru = validate(mysqli_real_escape_string($conn,$_POST['noru']));
    $rno = validate(mysqli_real_escape_string($conn,$_POST['rno']));
    $gender = validate(mysqli_real_escape_string($conn,$_POST['gender'])); 
    $currentDate = date("d-m-Y");
    $diff = date_diff(date_create($dob), date_create($currentDate));
    $age = $diff->format('%y');

    $sql="update `pwdprofile` set id=$id, pwdno = '$pwdno', date = '$date', applicantname = '$applicantname', dob = '$dob', 
    age = '$age', religion = '$religion', egroup = '$egroup',disability1 = '$disability1', disability2 = '$disability2',
    raddress = '$raddress',lno = '$lno', mno = '$mno',eadd = '$eadd',educational = '$educational',
    occupation = '$occupation',status = '$status',category = '$category',types = '$types',orgaffi = '$orgaffi',cperson = '$cperson',
    tnos = '$tnos', sno = '$sno', gno = '$gno', pno = '$pno', philno = '$philno', fathersname = '$fathersname', mothersname = '$mothersname', 
    guardianname = '$guardianname', noru = '$noru', rno = '$rno', gender = '$gender' where id = $id";

    if(mysqli_query($conn, $sql)){
      date_default_timezone_set('Asia/Manila');
      $user = "PWD USER";
      $action = "UPDATE";
      $data= $applicantname;// query for inser user log in to data base
      $date = date('m/d/Y h:i:s a', time());
      mysqli_query($conn,"insert into pwd_logs(session,date,data,user) values('$action','$date','$data','$user')");
        $_SESSION['statuspwd']="Record updated successfully!";
        header('Location: ../../user1/record/us-pwd-display.php');
    }else{
        $_SESSION['statuspwd']="Record updated successfully!";
        header('Location: ../../user1/record/us-pwd-display.php');
     
    }
    mysqli_close($conn);
}
?>
<?php

if(isset($_SESSION['username']) && isset($_SESSION['id'])){

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
    <link rel="stylesheet" href="../../aics/css/scstyle.css"/>
    <title>PWD update</title>
</head>

<div class="d-flex" id="wrapper">
 <!-- Sidebar -->
 <div style="background:#231f20" id="sidebar-wrapper">
                        <?php 
                            if(isset($_SESSION['status1'])&& $_SESSION !=''){
                            ?>
                            <div class="alert alert-warning alert-dismissible fade show" role="alert">
                            <strong>HEY!</strong> <?php echo $_SESSION['status1'];?>
                            </div>
                            <?php
                            unset($_SESSION['status1']);
                            }
                        ?>
        <div class="sidebar-heading text-center py-4 text-success fs-4 fw-bold text-uppercase"><i
                    class="	fas fa-campground me-2"></i>e-rms</div>
            <div class="list-group list-group-flush my-3">
                <a href="../../user1/pwddashboard.php" class="list-group-item text-uppercase list-group-item-action bg-transparent text-light fw-bold "><i
                        class="fas fa-tachometer-alt me-2"></i>Dashboard</a>
                <a href="../../report/us-pwd-report.php" class="list-group-item list-group-item-action bg-transparent text-light text-uppercase  fw-bold"><i
                        class="	fas fa-chart-bar"></i> REPORT</a>       
                <a href="../../user1/record/us-pwd-display.php" class="list-group-item list-group-item-action bg-transparent text-light  fw-bold"><i
                        class="fa fa-edit"></i> MANAGE RECORD</a>  
                        <a href="#" data-toggle="modal" data-target="#changeModal" class="list-group-item list-group-item-action bg-transparent text-light fw-bold"><i
                    class="fa fa-cog me-2"></i>SETTING</a> 
                    <a href="../../user/record/aics_logs.php" class="list-group-item list-group-item-action text-light bg-transparent  fw-bold"><i
                        class="fa fa-tasks "></i> LOGS</a> 
                    <!-- Modal -->
                    <div class="modal fade" id="changeModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                        <style>
                                .form-control{
                                    border-top: 0;
                                    border-left: 0;
                                    border-right: 0;
   
                                }
                                .form-select{
                                    border-top: 0;
                                    border-left: 0;
                                    border-right: 0;
                                }
                                .form-select:focus{
                                    border-top: 0;
                                    border-left: 0;
                                    border-right: 0;
                                }
                                .form-control:focus{  
                                    box-shadow: none;
                                  
                                }
                            </style>
                        <div class="modal-header" style="background:#42A5F5">
                            <h5 class="modal-title fw-bold" id="exampleModalLabel"><i  class="fa fa-cog me-2"></i>CHANGE PASSWORD</h5>
                            <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                        <form action="../login/changepass.php" method="POST" autocomplete="off">
                        <div class="row">
                            <div class="col">
                                <label for="">Current Password</label>
                                    <input type="text" name="current" class="form-control" placeholder="Current Password">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col">
                                <label for="">New Password</label>
                                    <input type="Password" name="new" class="form-control" placeholder="New Password">
                                </div>
                        </div>
                        <div class="row">
                            <div class="col">
                                <label for="">Confirm Password</label>
                                    <input type="password" name="confirm" class="form-control" placeholder="Confirm Password">
                            </div>
                        </div>
                            
                        
                        </div>
                        <div class="modal-footer">
                             <button type="submit" class="btn fw-bold text-light text-uppercase " name="change_btn" style="background:#42A5F5">Change Password</button>          
                        </form>
                              
                           
                        </div>
                        </div>
                    </div>
                    </div>           
                <!-- Button trigger modal -->
                 
                    <!-- Modal -->
                    <div class="modal fade" id="logoutModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Warning</h5>
                            <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            Ready to leave the site?
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                           <form action="../../login/logout.php" method="POST">
                               <button type="submit" name="logout_btn" class="btn btn-primary">logout</button>
                           </form>
                        </div>
                        </div>
                    </div>
                    </div>
                 
                <a href="#" data-toggle="modal" data-target="#logoutModal" class="list-group-item text-uppercase list-group-item-action bg-transparent text-light text-danger fw-bold"><i
                        class="fas fa-power-off me-2 "></i>Logout</a>
                <!-- Button trigger modal -->
               
            </div>
        </div>
        <!-- /#sidebar-wrapper -->
        <!-- Page Content -->
        <div id="page-content-wrapper" style="background:#E0E0E0">
        
            <nav class="navbar navbar-expand-lg navbar-light bg-transparent text-light py-2 px-4">
                <div class="d-flex align-items-center">
                    <i class="fas fa-align-left text-dark fs-4 me-3" id="menu-toggle"></i>
                    <h2 class="fs-2 m-0 fw-bold text-dark text-light border-bottom">PWD</h2>
                
                </div>
            </nav>

            <div class="container-fluid px-3">
                <div class="scrollable">
                <form id="form" action="" method="POST" class="bg-light px-2" autocomplete="off">       
                    <div class="text-center">
                         <label class="text-center my-3"><h3>APPLICATION FORM</h3></label>
                    </div>
                 
                    <div class="row">
                    <style>
                            .form-control{
                                border-top: 0;
                                border-left: 0;
                                border-right: 0;
                            }
                            .form-control:focus{  
                                box-shadow: none;
                            }
                            .form-select{
                                border-top: 0;
                                border-left: 0;
                                border-right: 0;
                            }
                            .form-select:focus{  
                                box-shadow: none;
                            }
                            .scrollable{
                                height: 680px;
                                overflow: auto;
                            }
                            .scrollable::-webkit-scrollbar {
                                    display: none;
                                }
                        </style>
                        <div class="col-auto">
                            <div class="form-group">
                            <label for=""><b>PERSONS WITH DISABILITY NUMBER (RR-PPMM-BBB-NNNNNNN)</b></label>
                            <input type="text" class="form-control" value="<?php echo $row['pwdno']; ?>" name="pwdno" placeholder="PWD number">   
                            </div>
                        </div>
                        
                        <div class="col">
                            <div class="form-group">
                            <label for=""><b>DATE APPLIED</b></label>
                            <input type="date" class="form-control" value="<?php echo $row['date']; ?>" name="date">   
                            </div>
                        </div>
                        <div class="col">
                          <label for="" class="fw-bold">Sex</label>
                                <select class="form-select" name="gender">
                                  <option  selected hidden><?php echo $row['gender']; ?></option>
                                  <option value="Female">Female</option>
                                  <option value="Male">Male</option>       
                                </select>
                        </div> 
                    </div>
                    <label for=""><b>PERSONAL INFORMATION</b></label>
                    <div class="row">
                        <div class="col">
                            <div class="form-group">
                                <input type="text" class="form-control" value="<?php echo $row['applicantname']; ?>" name="applicantname" placeholder="FULLNAME(LASTNAME, FIRSTNAME MIDDLENAME SUFFIX)">
                            </div>
                        </div>  
                        
                    </div>
                    <div class="row">
                        <div class="col">
                            <label for=""><b>DATE OF BIRTH</b></label>
                                <div class="form-group">
                                    <input type="date" class="form-control" value="<?php echo $row['dob']; ?>" name="dob" placeholder="DATE OF BIRTH">
                                </div>
                            </div>
                            <div class="col-sm-1">
                                <div class="form-group">
                                <label for="" class="fw-bold">AGE</label>
                                    <input type="text" class="form-control" value="<?php echo $row['age']; ?>" name="age" placeholder="AGE" readonly>
                                </div>
                            </div>
                            <div class="col">
                            <label for="" class="fw-bold">RELIGION</label>
                                <div class="form-group">
                                    <input type="text" class="form-control" value="<?php echo $row['religion']; ?>" name="religion" placeholder="RELIGION">
                                </div>
                            </div>
                            <div class="col">
                                <label for="" class="fw-bold">ETHNIC GROUP</label>
                                    <div class="form-group">
                                        <input type="text" class="form-control" value="<?php echo $row['egroup']; ?>" name="egroup" placeholder="ETHNIC GROUP">
                                    </div>
                            </div>
                    </div>
                     <div class="row">
                             <div class="col-auto">
                                    <label class="form-label fw-bold" >Type of Disability</label>
                                    <select class="form-select" name="disability1">
                                        <option  selected hidden><?php echo $row['disability1']; ?></option>
                                        <option value="Deaf or Hard of hearing">Deaf or Hard of hearing</option>
                                        <option value="Intellectuat Disability">Intellectuat Disability</option>
                                        <option value="Learning Disability">Learning Disability</option>
                                        <option value="Mental Disability">Mental Disability</option>
                                        <option value="Orthopedic Disability">Orthopedic Disability</option>
                                        <option value="Physical Disability">Physical Disability</option>
                                        <option value="Psycological Disability">Psycological Disability</option>
                                        <option value="Speech and Language Impairment">Speech and Language Impairment</option>
                                        <option value="Visual Disability">Visual Disability</option>
                                    </select>
                                </div>
                                <div class="col-auto">
                                    <label class="form-label fw-bold" ">Cause of Disability</label>
                                    <select class="form-select"  name="disability2">
                                        <option  selected hidden><?php echo $row['disability2']; ?> </option>
                                        <option value="Acquired">Acquired</option>
                                        <option value="Cancer">Cancer</option>
                                        <option value="Chronic illnes">Chronic illness</option>
                                        <option value="Congenital/Illness">Congenital/Illness</option>
                                        <option value="Injury">Injury</option>
                                        <option value="Rare disease">Rare disease</option>
                                        <option value="Autism">Autism</option>   
                                    </select>
                                </div>
                    </div>
                    <div class="row">
                            <label for="" class="fw-bold">RESIDENCE ADDRESS</label>
                            <div class="col">
               
                          <select class="form-select" id="raddress" name="raddress">
                            <option  selected hidden><?php echo $row['raddress']; ?></option>
                            <option value="Amallapay, Tubao, La Union">Amallapay, Tubao, La Union</option>
                            <option value="Anduyan, Tubao, La Union">Anduyan, Tubao, La Union</option>
                            <option value="Caoigue, Tubao, La Union">Caoigue, Tubao, La Union</option>
                            <option value="Francia Sur, Tubao, La Union">Francia Sur, Tubao, La Union</option>
                            <option value="Francia West, Tubao, La Union">Francia West,Tubao, La Union</option>
                            <option value="Gonzales, Tubao, La Union">Gonzales, Tubao,  La Union</option>
                            <option value="Garcia, Tubao, La Union">Gonzales, Tubao, La Union</option>
                            <option value="Halog East, Tubao, La Union">Halog East, Tubao, La Union</option>
                            <option value="Halog West, Tubao, La Union">Halog West, Tubao, La Union</option>
                            <option value="Leones East, Tubao, La Union">Leones East, Tubao, La Union</option>
                            <option value="Leones West, Tubao, La Union">Leones West, Tubao, La Union</option>
                            <option value="Linapew, Tubao, La Union">Linapew, Tubao, La Union</option>
                            <option value="Lloren, Tubao, La Union">Lloren, Tubao, La Union</option>
                            <option value="Magsaysay, Tubao, La Union">Magsaysay, Tubao, La Union</option>
                            <option value="Pideg, Tubao, La Union">Pideg, Tubao, La Union</option>
                            <option value="Poblacion, Tubao, La Union">Poblacion, Tubao, La Union</option>
                            <option value="Rizal, Tubao, La Union">Rizal, Tubao, La Union</option>
                            <option value="Santa Teresa, Tubao, La Union">Santa Teresa, Tubao, La Union</option>
                        </select>
                            </div>
                    </div>
                    <div class="row">
                        <label for="" class="fw-bold">CONTACT DETAILS</label>
                        <div class="col">
                        <input type="text" class="form-control" value="<?php echo $row['lno']; ?>" name="lno" placeholder="Landline No.">
                        </div>
                        <div class="col">
                        <input type="text" class="form-control" value="<?php echo $row['mno']; ?>" name="mno" placeholder="Mobile No.">
                        </div>
                        <div class="col">
                        <input type="text" class="form-control" value="<?php echo $row['eadd']; ?>" name="eadd" placeholder="Email Address">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col">
                            <label for="" class="fw-bold">EDUCATIONAL ATTAINMENT</label>
                            <select class="form-select" value=">" name="educational">
                                            <option selected hidden><?php echo $row['educational']; ?></option>
                                            <option value="None">None</option>
                                            <option value="Elementary Education">Elementary Education</option>
                                            <option value="Elementary Education">Elementary Education</option>
                                            <option value="College">College</option>
                                            <option value="Postgraduate Program">Postgraduate Program</option>
                                            <option value="Non-formal Education">Non-formal Education</option>
                                            <option value="Vocational">Vocational</option>   
                            </select>
                        </div>
                        <div class="col">
                            <label for="" class="fw-bold">OCCUPATION</label>
                            <input type="text" class="form-control" value="" name="occupation" placeholder="Occupation">
                        </div>
                        
                    </div>
                    <div class="row">
                        <div class="col">
                                <label for="" class="fw-bold">STATUS OF EMPLOYMENT</label>
                                <select class="form-select"  name="status">
                                                <option selected hidden><?php echo $row['status']; ?></option>
                                                <option value="Employed">Employed</option>
                                                <option value="Unemployed">Unemployed</option>
                                                <option value="Self-employed<">Self-employed</option>
                                            
                                </select>
                        </div>
                        <div class="col">
                                <label for="" class="fw-bold">CATEGORY OF EMPLOYMENT</label>
                                <select class="form-select" name="category">
                                                <option  selected hidden><?php echo $row['category']; ?></option>
                                                <option value="Government">Government</option>
                                                <option value="Private">Private</option>

                                            
                                </select>
                        </div>
                        <div class="col">
                                <label for="" class="fw-bold">TYPES OF EMPLOYMENT</label>
                                <select class="form-select" value="" name="types">
                                                <option selected hidden><?php echo $row['types']; ?></option>
                                                <option value="Permanent/Regular">Permanent/Regular</option>
                                                <option value="Seasonal">Seasonal</option>
                                                <option value="Casual">Casual</option>
                                                <option value="Emergency">Emergency</option>
                                            
                                </select>
                        </div>
                    </div>
                    <div class="row">
                        <label for="" class="fw-bold"> ORGANIZATION INFORMATION</label>
                        <div class="col">
                        <input type="text" class="form-control" value="<?php echo $row['orgaffi']; ?>" name="orgaffi" placeholder="Organization Affiliated">
                        </div>
                        <div class="col">
                        <input type="text" class="form-control" value="<?php echo $row['cperson']; ?>" name="cperson" placeholder="Contact Person">
                        </div>
                        <div class="col"> 
                        <input type="text" class="form-control" value="<?php echo $row['oadd']; ?>" name="oadd" placeholder="Office Address">
                        </div>
                        <div class="col">
                        <input type="text" class="form-control" value="<?php echo $row['tnos']; ?>" name="tnos" placeholder="Tel. Nos">
                        </div>
                    </div>
                    <div class="row">
                        <label for="" class="fw-bold"> ID REFERRENCES NO.</label>
                        <div class="col">
                        <input type="text" class="form-control" value="<?php echo $row['sno']; ?>" name="sno" placeholder="SSS NO.">
                        </div>
                        <div class="col">
                        <input type="text" class="form-control" value="<?php echo $row['gno']; ?>" name="gno" placeholder="GSIS NO.">
                        </div>
                        <div class="col">
                        <input type="text" class="form-control" value="<?php echo $row['pno']; ?>" name="pno" placeholder="PAG-IBIG NO.">
                        </div>
                        <div class="col">
                        <input type="text" class="form-control" value="<?php echo $row['philno']; ?>" name="philno" placeholder="PhilHealth NO.">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col">
                            <label for="" class="fw-bold">FAMILY BACKGROUND</label>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-auto">
                            <label for="" >FATHER'S NAME</label>
                        </div>
                        <div class="col">
                            <input type="text" class="form-control" value="<?php echo $row['fathersname']; ?>" name="fathersname" placeholder="FULLNAME(LASTNAME, FIRSTNAME MIDDLENAME)">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-auto">
                            <label for="" >MOTHER'S NAME</label>
                        </div>
                        <div class="col">
                            <input type="text" class="form-control" value="<?php echo $row['mothersname']; ?>" name="mothersname" placeholder="FULLNAME(LASTNAME, FIRSTNAME MIDDLENAME)">
                        </div>

                    </div>
                    <div class="row">
                        <div class="col-auto">
                            <label for="">GUARDIAN'S NAME</label>
                        </div>
                        <div class="col">
                            <input type="text" class="form-control " value="<?php echo $row['guardianname']; ?>" name="guardianname" placeholder="FULLNAME(LASTNAME, FIRSTNAME MIDDLENAME)">
                        </div>
                       
                    </div>

                    <div class="row g-4 mt-4">
                        <div class="col-auto">
                            <label for="" class="fw-bold" >ACCOMPLISHED BY</label>
                        </div>
                        <div class="col">
                            <input type="text" class="form-control" value="<?php echo $row['accomplished']; ?>" name="accomplished" placeholder="FULLNAME(LASTNAME, FIRSTNAME MIDDLENAME)">
                        </div>
                       
                    </div>
                    <div class="row">
                            <label for="" class="fw-bold" >NAME OF REPORTING UNIT</label>
                        <div class="col">
                            <input type="text" class="form-control" value="<?php echo $row['noru']; ?>" name="noru" placeholder="Name of reporting unit">
                        </div>
                    </div>
                    <div class="row">
                            <label for="" class="fw-bold" >REGISTRATION NUMBER</label>
                        <div class="col-sm-2">
                            <input type="text" class="form-control" value="<?php echo $row['rno']; ?>" name="rno" placeholder="registration no.">
                        </div>
                    </div>
                    <div class="row my-4">
                        <div class="">
                            <button class="btn btn-primary  text-uppercase fw-bold mb-3" type="submit" name="update">Update form</button>
                        </div>
                    </div>
                </form>
                </div> 
      

            </div>
            
     </div>
     <!-- /#page-content-wrapper -->
    </div>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>

    <script>
        var el = document.getElementById("wrapper");
        var toggleButton = document.getElementById("menu-toggle");

        toggleButton.onclick = function () {
            el.classList.toggle("toggled");
        };
    </script>
</body>
<style>
  .error {
    color: red;
  }
</style>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.1/jquery.validate.min.js"></script>
<script>
  $(document).ready(function () {
    $('#form').validate({
      rules: {
          //I
        pwdno: {
          required: true,
          //rangelength:[17],
          number: true
        },
        date: {
          required: true
        },
        gender:{
          required: true
        },
        applicantname: {
          required: true
        },
        dob: {
          required: true
        },
        age: {
          required: true,
          number: true
        },
        disability1: {
          required: true
        },
        disability2: {
          required: true
        },
        raddress: {
          required: true
        },
        lno: {
         
          number: true
        },
        mno: {
        
          number: true
        },
        tnos:{
          number:true
        },
        eadd: {
        
          email: true
        },
        sno: {
        
          number: true
        },
        pno: {
      
          number: true
        },
        philno: {
       
          number: true
        },
        fathersname: {
          required: true
        },
        mothersname: {
          required: true
        },
        rno: {
          
          number: true
        },



        
      },
      messages: {
        pwdno: {
          required: '*enter PWD number*',
          number:'*number only*'
          //rangelength: '*PWD number compose of 17 digits*'
        },
        date: {
          required: '*please choose date*'
         
        },
        gender:{
          required:'*select gender*'
        },
        applicantname: {
          required: '*enter fullname*'
         
        },
        dob: {
          required: 'select birthdate*' 
        },
        age: {
          required: '*enter age*',
          number: '*number only*' 
        },
       
        disability1: {
          required: '*select here*' 
        },
        disability2: {
          required: '*select here*' 
        },
        raddress: {
          required: '*select address*'
        },
        lno: {
        
          number: '*number only*' 
        },
        mno: {
       
          number: '*number only*' 
        },

        tnos: {
         
          number: '*number only*' 
        },
        eadd:{
          email: '*invalid email*'
        },
        sno: {
        
          number: '*number only*' 
        },
        pno: {
          
          number: '*number only*' 
        },
        philno: {
        
           number: '*number only*' 
        },
        fathersname: {
          required: '*fill the form*'
        },
        mothersname: {
          required: '*fill the form*'
        },
        rno:{
         number: '*Number only*'
        },
        

      },
      submitHandler: function (form) {
        form.submit();
      }
    });
  });
</script>
</html>
<?php
}else{  
    header("location:../login/LoginForm.php");     
}
?>
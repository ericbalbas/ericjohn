<?php
include '../../database/database.php';


if(isset($_POST['query'])){
    $search = mysqli_real_escape_string($conn, $_POST["query"]);
    $query = "SELECT * from pwdprofile where applicantname LIKE '%".$search."%'
    OR age LIKE '%".$search."%' OR raddress LIKE '%".$search."%' 
    OR disability1 LIKE '%".$search."%' OR date LIKE '%".$search."%' OR gender LIKE '%".$search."%'";
}else{
    $query = "select * from pwdprofile ORDER BY id";
}
$result = mysqli_query($conn, $query);

if(mysqli_num_rows($result)>0){ 
    ?>
    <style>
        .scrollable{
            height: 680px;
            overflow: auto;
        }
        .scrollable::-webkit-scrollbar {
            width: 8px;
        }
            
        .scrollable::-webkit-scrollbar-track {
            box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.3);
        }
            
        .scrollable::-webkit-scrollbar-thumb {
            background-color:#42A5F5;
            outline: 1px solid slategrey;
        }
        table{
            cursor:pointer;
        }
       
    </style>
    <div class="scrollable bg-light rounded">
    <table class="table bg-white rounded shadow-sm  table-hover table-fixed py-3 px-3">
            <thead style="background:#42A5F5">
                <tr class="text-light">
                    <th></th>
                    <th>Name</th>
                    <th>Age</th>
                    <th>Sex</th>
                    <th>Adress</th>
                    <th>Date added</th>
                    
                </tr>
            </thead>
            <tbody>
                <?php 
                $i = 1;
                    while($row = mysqli_fetch_assoc($result)){
                       
                        $id = $row['id'];
                        $applicantname = $row['applicantname'];
                        $age = $row['age']; 
                        $gender = $row['gender']; 
                        $raddress = $row['raddress']; 
                        $disability= $row['disability1'];
                        $date= $row['date'];
                       
                ?>
                      <tr onclick="window.location='us-pwd-view.php?id=<?php echo $row['id'];?>';" data-toggle="tooltip" data-placement="bottom" title="Click the data to manage!" >
                 
                        <td><?php echo $i;$i++; ?></td>
                        <td><?php echo $applicantname;?></td>
                        <td><?php echo $age;?></td>
                        <td><?php echo $gender;?></td>
                        <td><?php echo $raddress;?></td>
                        
                        <td><?php echo $date; ?></td>
                        
                    </tr>
                <?php
                    }
                ?>
            </tbody>
        </table>
     
        </div>           
    <?php
   
    }
    else{
        echo "No data found!";
}
 



?>
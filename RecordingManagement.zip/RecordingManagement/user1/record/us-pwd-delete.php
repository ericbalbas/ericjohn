<?php
session_start();
include '../../database/database.php';
function validate($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
if(isset($_POST['delete_btn'])) {
    $s_id = $_POST['s_id'];
    $sql = "Select * from `login2` where id = $s_id ";

    $result1=mysqli_query($conn,$sql);
    $row1 = mysqli_fetch_assoc($result1);

    $id = $_POST['id'];
    $con = $_POST['con'];
    if($row1['password'] == $con){

        $sql = "Select * from `pwdprofile` where id=$id";
        $result=mysqli_query($conn,$sql);
        $row = mysqli_fetch_assoc($result);
        $applicantname = validate($row['applicantname']);

        $sql = "delete from `pwdprofile` where id=$id";
        $result = mysqli_query($conn,$sql);
        if($result){
            date_default_timezone_set('Asia/Manila');
            $user = "PWD USER";
            $action = "DELETE";
            $data= $applicantname;// query for inser user log in to data base
            $date = date('m/d/Y h:i:s a', time());
            mysqli_query($conn,"insert into pwd_logs(session,date,data,user) values('$action','$date','$data','$user')");
            $_SESSION['statuspwd']="Record deleted successfully!";
            header('Location: ../../user1/record/us-pwd-display.php');
        }else{
            die(myqli_error($conn));
            $_SESSION['statuspwd']="Record failed to delete!";
            header('Location: ../../user1/record/us-pwd-display.php');
        }
    }else{
        $_SESSION['statuspwd']="Record failed to delete invalid password!";
        header('Location: ../../user1/record/us-pwd-display.php');
    }
}

?>
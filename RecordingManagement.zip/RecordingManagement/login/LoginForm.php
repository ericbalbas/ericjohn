
<!doctype html>
<html lang="en">
<head>
  
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="login.css">

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

  <title>Login Page</title>
  
</head>

<body>

  <section class="x vh-100">
          <style>
            .x{
              overflow: auto
            }
            .x::-webkit-scrollbar {
            display: none;
            }
          </style>
    <div class="container py-5 h-100">
      <div class="row d-flex align-items-center justify-content-center h-100">
     
        <div class="col-md-8 col-lg-7 col-xl-6">
          <img src="cover.png" class="img-fluid" alt="Responsive image" style="height:500px">
        </div>
        <div class="col-md-7 col-lg-5 col-xl-5 offset-x1-1 border" style="background: ">
          
          <form class="row g-3 " autocomplete="off" action="loginprocess.php" method="POST">
            <label for="" class="">
              <h3 class="text-center fw-bold fs-3 mt-2">MSWDO LOGIN</h3>
            </label>
            <?php if(isset($_GET['error'])) {?>
            <div class="alert alert-warning text-center alert-dismissible fade show" role="alert">
              <strong>Warning: </strong><?=$_GET['error'] ?> 
            </div>
            <?php }?>
            <!-- username input -->
            <div class="form-outline ">
              <label class="form-label fw-bold " for="form1Example13">Username</label>
              <input type="text" name="username" autocomplete="off" placeholder="Enter username..."
                class="form-control form-control-lg" />
              
            </div>

            <!-- Password input -->
            <div class="form-outline mb-1 ">
            <label class="form-label fw-bold " for="form1Example23">Password</label>
              <input type="password" name="password" autocomplete="off" placeholder="Enter password..."
                class="form-control form-control-lg" />
             
            </div>
            
            <div class="col-sm-4">
            <label class="form-label fw-bold  " for="form1Example23">Select user type:</label>
            <div class="form-outline mb-3  ">
              <select class="form-select fs-5 me-3" name="role" id="role">
                <option selected value="user" class="">user</option>
                <option value="admin" class="">admin</option>
              </select>
            </div>
            </div>
          
            <div class="form-outline mb-4">

              <!-- Submit button -->
              <div class=" text-center ">
                <button type="submit" class=" form-control btn btn-primary btn-lg btn-block">Log in</button>

              </div>
          </form>
        </div>
      </div>
    </div>
  </section>



  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
  </script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"
    integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous">
  </script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js"
    integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous">
  </script>

</body>

</html>
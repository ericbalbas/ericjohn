<?php
session_start();
include '../database/database.php';
function validate($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
if(isset($_POST['add_username'])&&isset($_POST['add_role'])&&
isset($_POST['add_pass'])&&isset($_POST['add_confirm'])){
    $add_username = validate($_POST['add_username']);
    $add_pass = validate($_POST['add_pass']);
    $add_role = validate($_POST['add_role']);
    $add_confirm = validate($_POST['add_confirm']);
    if($add_pass != $add_confirm){
        header("location:../aics/admindashboard.php");
        $_SESSION['statusadmin']="Confirm password didn't match!";
    }else{
        $query="INSERT INTO login2 (role,username,password) 
        VALUES ('$add_role','$add_username','$add_pass')";
        $query_run = mysqli_query($conn,$query);

        if($query_run){
            header("location:../aics/admindashboard.php");
             $_SESSION['statusadmin']="User added successfully!";
            
        }else{
            header("location:../aics/admindashboard.php");
         $_SESSION['statusadmin']="user failed to add!";
        }
    }
    
}

?>
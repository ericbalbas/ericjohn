<?php
session_start();
include '../database/database.php';
$username = $_SESSION['username'];
$id = $_SESSION['id'];
$_SESSION['status'] = "";
function validate($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
if(isset($_POST['current'])&&isset($_POST['new'])&&
isset($_POST['confirm'])){

    $current = validate($_POST['current']);
    $new = validate($_POST['new']);
    $confirm = validate($_POST['confirm']);


    if($username == 'senior'){
            if(empty($current)){
                header("location:../user2/scdashboard.php");
            
            }elseif(empty($new)){
                header("location:../user2/scdashboard.php");
               
            }elseif(empty($confirm)){
                header("location:../user2/scdashboard.php");
                
            }else{
        
                    $sql = "SELECT * FROM login2 WHERE id = $id";
                    $result = mysqli_query($conn, $sql);
                    $row = mysqli_fetch_assoc($result);
            
                        if($row['password']===$current ){  
                            
                            if($new == $confirm){
                
                                $query = "UPDATE login2 SET id='$id', password = '$new' WHERE id = '$id'";
                                $query_run = mysqli_query($conn,$query);
                                
                                if($query_run){
                                    header("location:../login/loginForm.php?error=Pasword updated required to login!");
                                    
                                }else{
                                    header("location:../user2/scdashboard.php");
                                    $_SESSION['status']="Password failed to update!";
                                }
                        
                            }else{
                                header("location:../user2/scdashboard.php");
                                $_SESSION['status']="New and confirm password didn't match!!";
                            }
                        } 
                            else{
                                header("locatiossn:../user2/scdashboard.php");
                                $_SESSION['status']="Current password didn't match!!";
                        }  
                }
            }
        if($username == 'pwd'){
                if(empty($current)){
                    header("location:../user1/pwddashboard.php");
                    
                }elseif(empty($new)){
                    header("location:../user1/pwddashboard.php");
                
                }elseif(empty($confirm)){
                    header("location:../user1/pwddashboard.php");
                
                }else{

                $sql = "SELECT * FROM login2 WHERE id = $id";
                $result = mysqli_query($conn, $sql);
                $row = mysqli_fetch_assoc($result);
        
                if($row['password']===$current ){  
                    
                    if($new == $confirm){
        
                        $query = "UPDATE login2 SET id='$id', password = '$new' WHERE id = '$id'";
                        $query_run = mysqli_query($conn,$query);
                        
                        if($query_run){
                            header("location:../login/LoginForm.php?error=Pasword updated required to login!");
                            
                        }else{
                            header("location:../user1/pwddashboard.php");
                            $_SESSION['status1']="Password update failed!";
                        }
                
                    }else{
                        header("location:../user1/pwddashboard.php");
                        $_SESSION['status1']="New and confirm password didn't match!";
                    }
                } else{
                    header("location:../user1/pwddashboard.php");
                    $_SESSION['status1']="Current password didn't match!";
                }
            }
      
        }
        if($username =='aics'){
            if(empty($current)){
                header("location:../user/aicsdashboard.php");
                
            }elseif(empty($new)){
                header("location:../user/aicsdashboard.php");
            
            }elseif(empty($confirm)){
                header("location:../user/aicsdashboard.php");
            
            }else{

            $sql = "SELECT * FROM login2 WHERE id = $id";
            $result = mysqli_query($conn, $sql);
            $row = mysqli_fetch_assoc($result);
    
            if($row['password']===$current ){  
                
                if($new == $confirm){
    
                    $query = "UPDATE login2 SET id='$id', password = '$new' WHERE id = '$id'";
                    $query_run = mysqli_query($conn,$query);
                    
                    if($query_run){
                        header("location:../login/LoginForm.php?error=Pasword updated required to login!");
                        
                    }else{
                        header("location:../user/aicsdashboard.php");
                        $_SESSION['status1']="Password update failed!";
                    }
            
                }else{
                    header("location:../user/aicsdashboard.php");
                    $_SESSION['status1']="New and confirm password didn't match!";
                }
            } else{
                header("location:../user/aicsdashboard.php");
                $_SESSION['status1']="Current password didn't match!";
            }
        }
        }   
        if($username =='admin'){
            if(empty($current)){
                header("location:../aics/admindashboard.php");
                
            }elseif(empty($new)){
                header("location:../aics/admindashboard.php");
            
            }elseif(empty($confirm)){
                header("location:.../aics/admindashboard.php");
            
            }else{

            $sql = "SELECT * FROM login2 WHERE id = $id";
            $result = mysqli_query($conn, $sql);
            $row = mysqli_fetch_assoc($result);
    
            if($row['password']===$current ){  
                
                if($new == $confirm){
    
                    $query = "UPDATE login2 SET id='$id', password = '$new' WHERE id = '$id'";
                    $query_run = mysqli_query($conn,$query);
                    
                    if($query_run){
                        header("location:../login/LoginForm.php?error=Pasword updated required to login!");
                        
                    }else{
                        header("location:../aics/admindashboard.php");
                        $_SESSION['statusadmin']="Password update failed!";
                    }
            
                }else{
                    header("location:../aics/admindashboard.php");
                    $_SESSION['statusadmin']="New and confirm password didn't match!";
                }
            } else{
                header("location:../aics/admindashboard.php");
                $_SESSION['statusadmin']="Current password didn't match!";
            }
        }
  
    }

}

?>
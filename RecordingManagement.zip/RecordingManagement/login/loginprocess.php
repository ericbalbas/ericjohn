<?php
session_start();
include '../database/database.php';


function validate($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
if(isset($_POST['username'])&&isset($_POST['password'])&&
isset($_POST['role'])){

    $username = validate($_POST['username']);
    $password = validate($_POST['password']);
    $role = validate($_POST['role']);

    if(empty($username)){
        header("location:../login/LoginForm.php?error= Username is required");
    }elseif(empty($password)){
        header("location:../login/LoginForm.php?error= Password is required");
    }
    else{
      
      
        $sql = "SELECT * FROM login2 WHERE username='$username' AND 
        password ='$password'";

        $result = mysqli_query($conn, $sql);
        
        if(mysqli_num_rows($result)> 0){
            
            $row = mysqli_fetch_assoc($result);
            if($row['username']=='admin'){
                if($row['password']===$password && $row['role']===$role){
                    $_SESSION['name'] = $row['name'] ;
                    $_SESSION['id'] = $row['id'] ;
                    $_SESSION['username'] = $row['username'] ;
                    $_SESSION['role'] = $row['role'] ;
                    
                    header("location:../aics/admindashboard.php");
                }else{
                    header("location:../login/LoginForm.php?error= Didn't match!");
                }
            }else if($row['username']=='aics'){
                if($row['password']===$password && $row['role']==$role){
                    $_SESSION['name'] = $row['name'] ;
                    $_SESSION['id'] = $row['id'] ;
                    $_SESSION['username'] = $row['username'] ;
                    $_SESSION['role'] = $row['role'] ;
                    
                    header("location:../user/aicsdashboard.php");
                }else{
                    header("location:../login/LoginForm.php?error= Didn't match!");
                }
            }
            else if($row['username']=='pwd'){
                if($row['password']===$password && $row['role']==$role){
                    $_SESSION['name'] = $row['name'] ;
                    $_SESSION['id'] = $row['id'] ;
                    $_SESSION['username'] = $row['username'] ;
                    $_SESSION['role'] = $row['role'] ;
                    
                    header("location:../user1/pwddashboard.php");
                }else{
                    header("location:../login/LoginForm.php?error= Didn't match!");
                }
            }
            else if($row['username']=='senior'){
                if($row['password']===$password && $row['role']==$role){
                    $_SESSION['name'] = $row['name'] ;
                    $_SESSION['id'] = $row['id'] ;
                    $_SESSION['username'] = $row['username'] ;
                    $_SESSION['role'] = $row['role'] ;
                    
                    header("location:../user2/scdashboard.php");
                }else{
                    header("location:../login/LoginForm.php?error= Didn't match!");
                }
            }
            
          
            
            
        }else{  
            header("location:../login/LoginForm.php?error= Invalid authentication!");
        }
    }
}
else{
    header("location:../login/LoginForm.php");
}





?>

<?php
session_start();
include_once '../../database/database.php';
function validate($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}


if(isset($_POST['submit'])){
    $firstname = validate(mysqli_real_escape_string($conn,$_POST['firstname']));
    $middlename = validate(mysqli_real_escape_string($conn,$_POST['middlename']));
    $lastname =  validate(mysqli_real_escape_string($conn,$_POST['lastname']));
    $extension =  validate(mysqli_real_escape_string($conn,$_POST['extension']));
    $sex =  validate(mysqli_real_escape_string($conn,$_POST['sex']));
    $address =  validate(mysqli_real_escape_string($conn,$_POST['address']));
    $age =  validate(mysqli_real_escape_string($conn,$_POST['age']));
    $relationship =  validate(mysqli_real_escape_string($conn,$_POST['relationship']));
    $civil =  validate(mysqli_real_escape_string($conn,$_POST['civil']));
    $contact =  validate(mysqli_real_escape_string($conn,$_POST['contact']));
    $educational =  validate(mysqli_real_escape_string($conn,$_POST['educational']));
    $skill =  validate(mysqli_real_escape_string($conn,$_POST['skill']));
    $income =  validate(mysqli_real_escape_string($conn,$_POST['income']));
    //II.

    $iifirstname =  validate(mysqli_real_escape_string($conn,$_POST['iifirstname']));
    $iimiddlename =  validate(mysqli_real_escape_string($conn,$_POST['iimiddlename']));
    $iilastname =  validate(mysqli_real_escape_string($conn,$_POST['iilastname']));
    $iiextension =  validate(mysqli_real_escape_string($conn,$_POST['iiextension']));
    $iisex =  validate(mysqli_real_escape_string($conn,$_POST['iisex']));
    $iiaddress =  validate(mysqli_real_escape_string($conn,$_POST['iiaddress']));

for($i=0;$i<count($_POST['fullname']);$i++)
{
    //set the value for variable
    $fullname[]= validate(mysqli_real_escape_string($conn,$_POST['fullname'][$i])) ;
    //$full[] = $fullname;
  
}
for($i=0;$i<count($_POST['aget']);$i++)
{ 
    $aget[] =  validate(mysqli_real_escape_string($conn,$_POST['aget'][$i]));
    //$age[] = $aget;
}
for($i=0;$i<count($_POST['sext']);$i++)
{ 
    $sext[$i] =  validate(mysqli_real_escape_string($conn,$_POST['sext'][$i]));
   // $sex[] = $sext;
}
for($i=0;$i<count($_POST['civilt']);$i++)
{ 
    $civilt[] =  validate(mysqli_real_escape_string($conn,$_POST['civilt'][$i]));
    
}
for($i=0;$i<count($_POST['relationshipt']);$i++)
{ 
    $relationshipt[] =  validate(mysqli_real_escape_string($conn,$_POST['relationshipt'][$i]));
  //  $relationship[] = $relationshipt;
}
for($i=0;$i<count($_POST['educationalt']);$i++)
{ 
    $educationalt[] =  validate(mysqli_real_escape_string($conn,$_POST['educationalt'][$i]));
  //  $educational[] = $educationalt;
}
for($i=0;$i<count($_POST['relationshipt']);$i++)
{ 
    $skillt[] =  validate(mysqli_real_escape_string($conn,$_POST['skillt'][$i]));
  // $skill[] = $skillt;
}
for($i=0;$i<count($_POST['incomet']);$i++)
{ 
    $incomet[] =  validate(mysqli_real_escape_string($conn,$_POST['incomet'][$i]));
  //  $income[] = $incomet;
}


    $newfull = implode(',',$fullname);
    $newsex = implode(',',$sext);
    $newage = implode(',',$aget);
    $newcivil = implode(',',$civilt);
    $newrelationship = implode(',',$relationshipt);
    $neweducational = implode(',',$educationalt);
    $newskill = implode(',',$skillt);
    $newincome = implode(',',$incomet);
    
   
    //IV
    $problem =  validate(mysqli_real_escape_string($conn,$_POST['problem']));
    $assessment =  validate(mysqli_real_escape_string($conn,$_POST['assessment']));

    //V
    $service =  validate(mysqli_real_escape_string($conn,$_POST['service']));
    $recommendation =  validate(mysqli_real_escape_string($conn,$_POST['recommendation']));

   
    $sql = "INSERT INTO aicsprofile(firstname,middlename,lastname,extension
    ,sex,address,age,relationship,civil,contact,educational,skill,income,
    iifirstname,iimiddlename,iilastname,iiextension,iisex,iiaddress,fullname,sext,aget,civilt,relationshipt,educationalt,
    skillt,incomet,problem,assessment,service,recommendation)
     VALUES
    ('$firstname','$middlename','$lastname','$extension','$sex','$address'
    ,'$age','$relationship','$civil','$contact','$educational','$skill','$income'
    ,'$iifirstname','$iimiddlename','$iilastname','$iiextension','$iisex','$iiaddress','$newfull'
    ,'$newsex','$newage','$newcivil'
    ,'$newrelationship','$neweducational','$newskill','$newincome'
    ,'$problem','$assessment','$service','$recommendation')";

    if(mysqli_query($conn, $sql)){
        date_default_timezone_set('Asia/Manila');
        $user = "AICS USER";
        $action = "INSERT";
        $data= $firstname.' '.$middlename.' '.$lastname;// query for inser user log in to data base
        $date = date('m/d/Y h:i:s a', time());
        mysqli_query($conn,"insert into activity_logs(session,date,data,user) values('$action','$date','$data','$user')");

        $_SESSION['statusss']="Record inserted successfully!";
        header('Location: ../../user/record/us-aics-display.php');
    }else{
        $_SESSION['statusss']="Record failed to insert!";
        header('Location: ../../user/record/us-aics-form.php');
    }
    mysqli_close($conn);
}

?>
<?php
session_start();
function validate($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
include '../../database/database.php';


if(isset($_POST['delete_btn'])) {
    $s_id = $_POST['s_id'];
    $sql = "Select * from `login2` where id = $s_id ";

    $result1=mysqli_query($conn,$sql);
    $row1 = mysqli_fetch_assoc($result1);

    $id = $_POST['id'];
    $con = $_POST['con'];
    if($row1['password'] == $con){

        $sql = "Select * from `aicsprofile` where id=$id";
        $result=mysqli_query($conn,$sql);
        $row = mysqli_fetch_assoc($result);
        $firstname=validate($row['firstname']);
        $middlename=validate($row['middlename']);
        $lastname=validate($row['lastname']);

        $sql = "delete from `aicsprofile` where id=$id";
        $result = mysqli_query($conn,$sql);

        if($result){
            date_default_timezone_set('Asia/Manila');
            $user = "AICS USER";
            $action = "DELETE";
            $data= $firstname.' '.$middlename.' '.$lastname;// query for inser user log in to data base
            $date = date('m/d/Y h:i:s a', time());
            mysqli_query($conn,"insert into activity_logs(session,date,data,user) values('$action','$date','$data','$user')");
            $_SESSION['statusss']="Record deleted successfully!";
            header('Location:../../user/record/us-aics-display.php');
            echo $_SESSION['password'];
        }else{
            
            $_SESSION['statusss']="Record failed to delete!";
            header('Location:../../user/record/us-aics-display.php');
            die(myqli_error($conn));
        }
    }else{
        $_SESSION['statusss']="Record failed to delete invalid password!";
        header('Location:../../user/record/us-aics-display.php');
    }
    
}

?>
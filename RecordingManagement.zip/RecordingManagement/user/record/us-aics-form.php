<?php
session_start();
if(isset($_SESSION['username']) && isset($_SESSION['id'])){

?>
   

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
    <link rel="stylesheet" href="../../aics/css/scstyle.css" />
    <title>AICS form</title>
</head>
<body>
<div class="d-flex" id="wrapper">
                            <!-- Sidebar -->
            <div  style="background:#231f20" id="sidebar-wrapper">
             <div class="sidebar-heading text-center py-4 text-success fs-4 fw-bold text-uppercase"><i
                    class="	fas fa-campground me-2"></i>e-rms</div>
            <div class="list-group list-group-flush my-3">
                <a href="../../user/aicsdashboard.php" class="list-group-item list-group-item-action text-uppercase bg-transparent text-light fw-bold "><i
                        class="fas fa-tachometer-alt me-2"></i>Dashboard</a>
                <a href="../../user/record/us-aics-report.php" class="list-group-item list-group-item-action bg-transparent text-light  fw-bold"><i
                        class="	fas fa-chart-bar "></i> REPORT</a>       
               
                <a href="../../user/record/us-aics-display.php" class="list-group-item   list-group-item-action bg-transparent text-light  fw-bold"><i
                        class="fa fa-edit "></i> MANAGE RECORD</a> 
                        <a href="../../user/record/aics_logs.php" class="list-group-item list-group-item-action text-light bg-transparent  fw-bold"><i
                        class="fa fa-tasks "></i> LOGS</a>   
                        <a href="#" data-toggle="modal" data-target="#changeModal" class="list-group-item list-group-item-action bg-transparent text-light fw-bold"><i
                    class="fa fa-cog me-2"></i>SETTING</a> 
                    <!-- Modal -->
                    <div class="modal fade" id="changeModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                        <style>
                                .form-control{
                                    border-top: 0;
                                    border-left: 0;
                                    border-right: 0;
   
                                }
                                .form-select{
                                    border-top: 0;
                                    border-left: 0;
                                    border-right: 0;
                                }
                                .form-select:focus{
                                    border-top: 0;
                                    border-left: 0;
                                    border-right: 0;
                                }
                                .form-control:focus{  
                                    box-shadow: none;
                                  
                                }
                            </style>
                        <div class="modal-header" style="background:#42A5F5">
                            <h5 class="modal-title fw-bold" id="exampleModalLabel"><i  class="fa fa-cog me-2"></i>CHANGE PASSWORD</h5>
                            <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                        <form action="../login/changepass.php" method="POST" autocomplete="off">
                        <div class="row">
                            <div class="col">
                                <label for="">Current Password</label>
                                    <input type="text" name="current" class="form-control" placeholder="Current Password">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col">
                                <label for="">New Password</label>
                                    <input type="Password" name="new" class="form-control" placeholder="New Password">
                                </div>
                        </div>
                        <div class="row">
                            <div class="col">
                                <label for="">Confirm Password</label>
                                    <input type="password" name="confirm" class="form-control" placeholder="Confirm Password">
                            </div>
                        </div>
                            
                        
                        </div>
                        <div class="modal-footer">
                             <button type="submit" class="btn fw-bold text-light text-uppercase " name="change_btn" style="background:#42A5F5">Change Password</button>          
                        </form>
                              
                           
                        </div>
                        </div>
                    </div>
                    </div>     
                                       
                <a href="#" data-toggle="modal" data-target="#logoutModal" class="list-group-item text-uppercase list-group-item-action bg-transparent text-light fw-bold"><i
                        class="fas fa-power-off me-2"></i>Logout</a>
                <!-- Button trigger modal -->
                 
                    <!-- Modal -->
                    <div class="modal fade" id="logoutModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Warning</h5>
                            <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            Ready to leave the site?
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                           <form action="../../login/logout.php" method="POST">
                               <button type="submit" name="logout_btn" class="btn btn-primary">LOGOUT</button>
                           </form>
                        </div>
                        </div>
                    </div>
                    </div>
            </div>
        </div>
        <!-- /#sidebar-wrapper -->

        <!-- Page Content -->
        <div id="page-content-wrapper" style="background:#E0E0E0">
                            <?php 
                            if(isset($_SESSION['statusss'])&& $_SESSION !=''){
                            ?>
                            <div class="alert alert-warning alert-dismissible text-center fade show" role="alert">
                            <strong>HEY!</strong> <?php echo $_SESSION['statusss'];?>
                            </div>
                            <?php
                            unset($_SESSION['statusss']);
                            }
                        ?>
            <nav class="navbar navbar-expand-lg navbar-light bg-transparent text-light py-2 px-4">
                <div class="d-flex align-items-center">
                    <i class="fas fa-align-left text-dark fs-4 me-3" id="menu-toggle"></i>
                    <h2 class="fs-3 m-0 fw-bold text-uppercase text-dark">STORE RECORD</h2>
                
                </div>
            </nav>

            <div class="container-fluid px-4 ">
            <div class="scrollable">
            <form id="form" action="../../user/record/us-aics-insert.php" class="bg-light px-2 rounded" method="POST" autocomplete="off" >
            <style>
                            .form-control{
                                border-top: 0;
                                border-left: 0;
                                border-right: 0;
                            }
                            .form-control:focus{  
                                box-shadow: none;
                            }
                            .form-label{  
                                font-weight: bold;
                            }
                            .form-select{
                                border-top: 0;
                                border-left: 0;
                                border-right: 0;
                            }
                            .form-select:focus{  
                                box-shadow: none;
                            }
                            .scrollable{
                                height:650px;
                                overflow: auto;
                            }
                            .scrollable::-webkit-scrollbar {
                                    display: none;
                                }
                        </style>
            <label for=""  class="my-3"><h5>I. Client Identifying Information</h5></label>
            <div class="row">

            <div class="col-sm-3">
                <div class="form-group">
                <label class="form-label" for="form10Example1">First name</label>
                <input type="text" id="form10Example1" name="firstname" id="firstname" class="form-control" placeholder="First name"/> 
                </div>
               
            </div>

            <div class="col-sm-3">
                <div class="form-outline">
                <label class="form-label" for="form10Example2">Middle name</label>
                <input type="text" id="form10Example2" name="middlename" id="middlename" class="form-control" placeholder="Middle name" />

                </div>
            </div>

            <div class="col-sm-3">
                <div class="form-outline">
                <label class="form-label" for="form10Example3">Last Name</label>
                <input type="text" id="form10Example3" name="lastname" id="lastname" class="form-control" placeholder="Last name" />
                </div>
            </div>
            
            <div class="col">
                <div class="form-outline">
                <label class="form-label" for="selectext">Ext(Jr/Sr.)</label>
                <select class="form-select " id="selectext" name="extension">
                <option value="" disable selected hidden>Ext.</option>
                <option value=""></option>
                <option value="Sr.">Sr.</option>
                <option value="Jr.">Jr.</option>
                
                </select>
                </div>

            </div>
            <div class="col">
                <label class="form-label" for="selectsex">Sex</label>
                <select class="form-select" id="selectsex" name="sex">
                <option value="" disable selected hidden>Sex</option>
                <option value="Female">Female</option>
                <option value="Male">Male</option>
                </select>
            </div>

            </div>
            

            <div class="row g-2">
                <div class="col">
                        <label class="form-label" for="">Address</label>
                        <select class="form-select" id="address" name="address">
                            <option value="" disable selected hidden>Address</option>
                            <option value="Amallapay, Tubao, La Union">Amallapay, Tubao, La Union</option>
                            <option value="Anduyan, Tubao, La Union">Anduyan, Tubao, La Union</option>
                            <option value="Caoigue, Tubao, La Union">Caoigue, Tubao, La Union</option>
                            <option value="Francia Sur, Tubao, La Union">Francia Sur, Tubao, La Union</option>
                            <option value="Francia West, Tubao, La Union">Francia West,Tubao, La Union</option>
                            <option value="Gonzales, Tubao, La Union">Gonzales, Tubao,  La Union</option>
                            <option value="Garcia, Tubao, La Union">Gonzales, Tubao, La Union</option>
                            <option value="Halog East, Tubao, La Union">Halog East, Tubao, La Union</option>
                            <option value="Halog West, Tubao, La Union">Halog West, Tubao, La Union</option>
                            <option value="Leones East, Tubao, La Union">Leones East, Tubao, La Union</option>
                            <option value="Leones West, Tubao, La Union">Leones West, Tubao, La Union</option>
                            <option value="Linapew, Tubao, La Union">Linapew, Tubao, La Union</option>
                            <option value="Lloren, Tubao, La Union">Lloren, Tubao, La Union</option>
                            <option value="Magsaysay, Tubao, La Union">Magsaysay, Tubao, La Union</option>
                            <option value="Pideg, Tubao, La Union">Pideg, Tubao, La Union</option>
                            <option value="Poblacion, Tubao, La Union">Poblacion, Tubao, La Union</option>
                            <option value="Rizal, Tubao, La Union">Rizal, Tubao, La Union</option>
                            <option value="Santa Teresa, Tubao, La Union">Santa Teresa, Tubao, La Union</option>
                        </select>

                </div>
                <div class="col-sm-1">
                    <div class="form-outline">
                    <label class="form-label" for="f2">Age</label>
                    <input type="text"  class="form-control" name="age" id="age"  placeholder="Age" />
                    </div>
                </div>
            </div>
            
            <div class="row g-3">
                <div class="col">
                    <div class="form-outline">
                    <label class="form-label" for="f3">Relationship to Beneficiary</label>
                    <input type="text"  class="form-control" name="relationship" id="relationship" placeholder="Relationship to Beneficiary" />
                    </div>
                </div>

                <div class="col">
                    <div class="form-outline">
                    <label class="form-label" for="f4">Civil Status</label>
                    <select class="form-select" id="civil" name="civil">
                        <option value="" disable selected hidden>Civil Status</option>
                        <option value="Single">Single</option>
                        <option value="Married">Married</option>
                        <option value="Widowed">Widowed</option>
                        <option value="Divorced">Divorced</option>
                    </select>
                    </div>
                </div>

                <div class="col">
                    <div class="form-outline">
                    <label class="form-label" for="f5">Contact</label>
                    <input type="text"  class="form-control" name="contact" placeholder="Contact" />
                    </div>
                </div>
            </div>

            <div class="row g-3">

                <div class="col">
                    <div class="form-outline">
                    <label class="form-label" for="f3">Highest Educational Background</label>
                    <input type="text" class="form-control" name="educational" id="educational" placeholder="Highest Educational Background" />
                  
                    </div>
                </div>

                <div class="col">
                    <div class="form-outline">
                    <label class="form-label" for="f4">Skill/Occupation</label>
                    <input type="text"  class="form-control" name="skill" id="skill" placeholder="Skill/Occupation" />
                    </div>
                </div>

                <div class="col">
                    <div class="form-outline">
                    <label class="form-label" for="f5">Est. Monthly Income</label>
                    <input type="text"  class="form-control" name="income" id="income"  placeholder="Est. Monthly Income" />
                    </div>
                </div>
            </div>

            <label for="" class="my-3"><h5>II. Cause of Assistance</h5></label>

            <div class="row">
            <div class="col-sm-3">
                <div class="form-outline">
                <label class="form-label" for="form10Example1">First name</label>
                <input type="text" name="iifirstname" id="iifirstname" class="form-control" placeholder="First name" />
                </div>
            </div>
            <div class="col-sm-3">
                <div class="form-outline">
                <label class="form-label" for="form10Example2">Middle name</label>
                <input type="text"  name="iimiddlename" id="iimiddlename" class="form-control" placeholder="Middle name" />

                </div>
            </div>
            <div class="col-sm-3">
                <div class="form-outline">
                <label class="form-label" for="form10Example3">Last Name</label>
                <input type="text"  name="iilastname" id="iilastname" class="form-control" placeholder="Last name"/>
                
                </div>
            </div>

            <div class="col-sm-auto">
                <div class="form-outline">
                <label class="form-label" for="form10Example3">Ext(Jr/Sr.)</label>
                <select class="form-select" id="select" name="iiextension">
                <option value="" disable selected hidden>Ext.</option>
                <option value=""></option>
                <option value="Jr.">Jr.</option>
                <option value="Sr.">Sr.</option>
                </select>

                </div>
            </div>

            <div class="col">
            <label class="form-label" for="select">Sex</label>
            <select class="form-select" id="select" name="iisex"> 
            <option value="" disabled selected hidden>Sex </option>
            <option value="F">F</option>
            <option value="M">M</option>
            </select>
           
            </div>

            <div class="col-auto">
                <label class="form-label" for="">Address</label>
                <select class="form-select" id="iiaddress" name="iiaddress">
                    <option value="" disable selected hidden>Address</option>
                    <option value="Amallapay, Tubao, La Union">Amallapay ,Tubao, La Union</option>
                    <option value="Anduyan ,Tubao, La Union">Anduyan ,Tubao, La Union</option>
                    <option value="Caoigue ,Tubao, La Union">Caoigue ,Tubao, La Union</option>
                    <option value="Francia Sur ,Tubao, La Union">Francia Sur ,Tubao, La Union</option>
                    <option value="Francia West ,Tubao, La Union">Francia West ,Tubao, La Union</option>
                    <option value="Gonzales ,Tubao, La Union">Gonzales ,Tubao, La Union</option>
                    <option value="Garcia ,Tubao, La Union">Gonzales ,Tubao, La Union</option>
                    <option value="Halog East ,Tubao, La Union">Halog East ,Tubao, La Union</option>
                    <option value="Halog West ,Tubao, La Union">Halog West ,Tubao, La Union</option>
                    <option value="Leones East ,Tubao, La Union">Leones East ,Tubao, La Union</option>
                    <option value="Leones West ,Tubao, La Union">Leones West ,Tubao, La Union</option>
                    <option value="Linapew ,Tubao, La Union">Linapew ,Tubao, La Union</option>
                    <option value="Lloren ,Tubao, La Union">Lloren ,Tubao, La Union</option>
                    <option value="Magsaysay ,Tubao, La Union">Magsaysay  ,Tubao, La Union</option>
                    <option value="Pideg ,Tubao, La Union">Pideg ,Tubao, La Union</option>
                    <option value="Poblacion,Tubao, La Union">Poblacion ,Tubao, La Union</option>
                    <option value="Rizal,Tubao, La Union">Rizal ,Tubao, La Union</option>
                    <option value="Santa Teresa ,Tubao, La Union">Santa Teresa ,Tubao, La Union</option>
                </select>
               
            </div>

            <label for="" class="my-3"><h5>III. Benefeciary Family Composition</h5></label>
               
                <table class="table table-bordered sm me-5">
                            <thead>
                                <tr>
                                    <th>FULL NAME</th>
                                    <th>SEX</th>
                                    <th>AGE</th>
                                    <th>CIVIL STATUS</th>
                                    <th>RELATIONSHIP</th>
                                    <th>EDUCATIONAL ATTAINMENT</th>
                                    <th>OCCUPATION</th>
                                    <th>SALARY</th>
                                </tr>
                            </thead>
                            
                                <tbody> 
                                    
                                <td> <input type="text" id="fullname" class="form-control" name="fullname[]" placeholder="Full name" />
                                </td>
                                <td class="col-auto"> <select class="form-select" id="select" name="sext[]"> 
                                    <option value="" disable selected hidden>Sex</option>
                                    <option value="F">F</option>
                                    <option value="M">M</option>
                                    </select> </td>
                                <td class="col-sm-1"> <input type="text" id="aget" class="form-control" name="aget[]" placeholder="Age"/></td>
                                <td class="col-sm-1"> <input type="text" class="form-control" id="civilt" name="civilt[]"></td>
                                <td class="col-sm-2">  <input type="text" id="relationshipt" class="form-control" name="relationshipt[]" placeholder="Relationship" /></td>
                                <td class="col-sm-2"> <input type="text" id="educationalt" name="educationalt[]"  class="form-control" placeholder="Highest educational attainment" /></td>
                                <td class="col-sm-1"><input type="text" id="skillt" name="skillt[]"  class="form-control" placeholder="Skill/Occupation" /></td>
                                <td> <input type="text" id="incomet" name="incomet[]" class="form-control" placeholder="Est. Monthly Income" /></td>
                                <td> <button type="submit" id="add_btn" class="btn btn-primary text-uppercase add_btn"><i class="fa fa-plus"></i></button></td>
                            </tbody>  
                           
                    </table>

                <label for="" class="my-3"><h5>IV. Assessment</h5></label>
                <div class="row g-2">
                    <div class="col">
                        <div class="form-outline">  
                            <label for="ff7">Problem(s) presented</label>
                            <textarea class="form-control" id="ff7" rows="3" name="problem" placeholder="Problem(s) presented"></textarea>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-outline">
                            <label for="ff8">Workers assessment</label>
                            <textarea class="form-control" id="ff8" rows="3" name="assessment" placeholder="Workers assessment"></textarea>
                        </div>
                    </div>
                   
                </div>
                <label for="" class="mt-3"><h5>V. Service Extended</h5></label>
                <div class="row">
                    <div class="col">
                                <div class="form-outline">
                                <label class="form-label" for="ff9">Service extended</label>
                                <input type="text" id="ff9" class="form-control" name="service" placeholder="Service extended"/>
                            </div>
                        </div>
                    </div>
                    <label for="" class=""><h5>VI. Recommendation</h5></label>
                    <div class="row">
                    <div class="col">
                                <div class="form-outline">
                                <label class="form-label" for="ff9">Recommendation</label>
                                <input type="text" id="ff9" class="form-control" name="recommendation" placeholder="Recommendation"/>
                            </div>
                        </div>
                </div>
               
                <div class="row my-4">
                    <div class="col">
                        <button class="btn btn-primary text-primary text-uppercase fw-bold mb-3" type="submit" name="submit">Submit form</button>
                    </div>
                </div>
               
            </form> 
            </div>
          
            
        </div>
           
  
         
            
        </div>
     </div>
     <!-- /#page-content-wrapper -->
    </div>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>

    <script>
        var el = document.getElementById("wrapper");
        var toggleButton = document.getElementById("menu-toggle");

        toggleButton.onclick = function () {
            el.classList.toggle("toggled");
        };
    </script>
</body>

<style>
  .error {
    color: red;
  }
</style>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.1/jquery.validate.min.js"></script>
<script>
 $(document).ready(function () {
   
   $('#form').validate({
     rules: {
         //I
       firstname: {
         required: true,
         
       },
       middlename: {
         required: true
       },
       lastname: {
         required: true
       },
       sex: {
         required: true
       },
       address: {
         required: true
       },
       age: {
         required: true,
         number: true
        
         
       },
     
       civil: {
        required: true
       },
       contact: {
         required: true,
         rangelength: [11, 12],
         number: true
       },
       
       
     },
     messages: {
       firstname: {
        required: '* Enter first name *'
       }
       ,
       middlename: {
         required:  '* Enter Middle name *'
       },
       lastname: {
         required:  '* Enter Last name *'
       },
       sex:{   
         required: '* Select here*'
       },
       address:{
         required: '* Select address *'
       },
       age:{
         required: '* Enter age *',
         number: '* Numeric *'
       },
     
       civil: {
           required: '*Select civil status*'
           },
       contact: {
         required: '* Please enter Contact *',
         rangelength: '* Contact should be 11 digit number*',
       },
     
     },
     submitHandler: function (form) {
       form.submit();
     }
   });
 });
  $(document).ready(function(){
    $(".add_btn").click(function(e){
        e.preventDefault();
        $("table").prepend(`<tbody>
                            <td> <input type="text" id="fullname" class="form-control" name="fullname[]" placeholder="Full name" />
                            </td>
                            <td class="col-sm-1"> <select class="form-select" id="select" name="sext[]"> 
                                <option value="" disable selected hidden>Sex</option>
                                <option value="F">F</option>
                                <option value="M">M</option>
                                </select> </td>
                            <td class="col-sm-1"> <input type="text" id="aget" class="form-control" name="aget[]" placeholder="Age"/></td>
                            <td class="col-sm-1"> <input type="text" class="form-control" id="civilt" name="civilt[]"></td>
                            <td class="col-sm-2">  <input type="text" id="relationshipt" class="form-control" name="relationshipt[]" placeholder="Relationship" /></td>
                            <td class="col-sm-2"> <input type="text" id="educationalt" name="educationalt[]"  class="form-control" placeholder="Highest educational attainment" /></td>
                            <td class="col-sm-1"><input type="text" id="skillt" name="skillt[]"  class="form-control" placeholder="Skill/Occupation" /></td>
                            <td> <input type="text" id="incomet" name="incomet[]" class="form-control" placeholder="Est. Monthly Income" /></td>
                            <td> <button type="submit"  class="btn btn-danger text-uppercase del_btn"><i class="fa fa-trash"></i></button></td>
                            </tbody>  `);
    });
    $(document).on('click','.del_btn', function(e){
        e.preventDefault
        let row = $(this).parent().parent();
        $(row).remove();
    });
  });

</script>

</html>
<?php
}else{
    header("location:../login/LoginForm.php");     
}
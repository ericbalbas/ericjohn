<?php
session_start();
function validate($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
include '../database/database.php';
$sql = "Select * from `login2`";
$result1=mysqli_query($conn,$sql);
$row1 = mysqli_fetch_assoc($result1);

if(isset($_POST['delete_btn'])) {

    $id = $_POST['id'];
    $con = $_POST['con'];
    if($row1['password'] == $con){

        $sql = "Select * from `aicsprofile` where id=$id";
        $result=mysqli_query($conn,$sql);
        $row = mysqli_fetch_assoc($result);
        $firstname=validate($row['firstname']);
        $middlename=validate($row['middlename']);
        $lastname=validate($row['lastname']);

        $sql = "delete from `aicsprofile` where id=$id";
        $result = mysqli_query($conn,$sql);
        
        if($result){
            date_default_timezone_set('Asia/Manila');
            $user = "ADMIN";
            $action = "DELETE";
            $data= $firstname.' '.$middlename.' '.$lastname;// query for inser user log in to data base
            $date = date('m/d/Y h:i:s a', time());

            mysqli_query($conn,"insert into activity_logs(session,date,data,user) values('$action','$date','$data','$user')");
            $_SESSION['aics']="Record deleted successfully!";
            header('location:../aics/aicsdisplay.php');
            
        }else{
            $_SESSION['aics']="Record failed to delete!";
            header('location:../aics/aicsdisplay.php');
        }
    }else{
        $_SESSION['aics']="Record failed to delete invalid password!";
            header('location:../aics/aicsdisplay.php');
    }
}

?>  
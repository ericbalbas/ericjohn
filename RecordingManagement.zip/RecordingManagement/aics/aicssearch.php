<?php
include '../database/database.php';
$output = '';

if(isset($_POST['query'])){
    $search = mysqli_real_escape_string($conn, $_POST["query"]);
    $query = "SELECT * from aicsprofile where firstname LIKE '%".$search."%'
    OR middlename LIKE '%".$search."%' OR lastname LIKE '%".$search."%' 
    OR extension LIKE '%".$search."%' OR sex LIKE '%".$search."%'OR age LIKE '%".$search."%'
    OR address LIKE '%".$search."%' OR date LIKE '%".$search."%' ";
}else{
    $query = "select * from aicsprofile";
}
$result = mysqli_query($conn, $query);

if(mysqli_num_rows($result)>0){ 
    ?>
   <style>
       .scrollable{
           height: 600px;
           overflow: auto;
       }
       .scrollable::-webkit-scrollbar {
            width: 8px;
        }
            
        .scrollable::-webkit-scrollbar-track {
            box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.3);
        }
            
        .scrollable::-webkit-scrollbar-thumb {
            background-color:#42A5F5;
            outline: 1px solid slategrey;
        }
        table{
            cursor:pointer;
        }
   </style>
   
   <div class="scrollable bg-light rounded">
        <table class="table bg-white rounded shadow-sm  table-hover py-3 px-3" >
                <thead  style="background:#7dd07d">
                    <tr class=" text-light">
                        <th></th>
                        <th>Name</th>
                        <th>Adress</th>
                        <th>Sex</th>
                        <th>Age</th>
                        <th>Date added</th>
                        
                    </tr>
                </thead>
                <tbody >
                    <?php 
                    $i = 1;
                        while($row = mysqli_fetch_assoc($result)){
                        
                            $id = $row['id'];
                            $firstname = $row['firstname'];
                            $middlename = $row['middlename'];
                            $lastname = $row['lastname'];
                            $sex = $row['sex'];
                            $age = $row['age']; 
                            $address = $row['address']; 
                            $extension = $row['extension'];
                            $date = $row['date'];
                            
                    ?>
                        <tr onclick="window.location='aicsview.php?id=<?php echo $row['id'];?>';" data-toggle="tooltip" data-placement="bottom" title="Click the data to manage!" >
          
                            <td><?php echo $i; $i++; ?></td>
                            <td><?php echo $lastname.', '. $firstname. ' ' .$middlename. ' ' .$extension; ?></td>
                            <td><?php echo $address;?></td>
                            <td><?php echo $sex;?></td>
                            <td><?php echo $age; ?></td>
                            <td><?php echo $date; ?></td>
                         
                            
                        </tr>
                    <?php
                        }
                    ?>
                </tbody>
            </table>
               
         </div>
    <?php
   
    }
    else{
        echo "No data found!";
}
 



?>
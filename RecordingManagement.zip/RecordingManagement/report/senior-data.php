<?php 
include '../database/database.php';
$sql = "SELECT COUNT(*) FROM seniorprofile";
$result = mysqli_query($conn, $sql);
$count = mysqli_fetch_assoc($result) ['COUNT(*)'];

$query2 = "SELECT * from seniorprofile ORDER BY id";
$result2 = mysqli_query($conn, $query2);
  $i = 1;

      while($row = mysqli_fetch_assoc($result2)){
      
          $id = $row['id'];
          $familyname = $row['familyname'];
          $givenname = $row['givenname'];
          $middlename = $row['middlename'];
          $sex = $row['sex'];
          $age = $row['age']; 
          $address = $row['address']; 
          $date = $row['date'];

  ?>
      <tr>

          <td><?php echo  $i;$i++; ?></td>
          <td><?php echo $familyname.', '. $givenname. ' ' .$middlename;?></td>
          <td><?php echo $address;?></td>
          <td><?php echo $sex;?></td>
          <td><?php echo $age; ?></td>
          
         
         
 
      </tr>
     
  <?php
      }
      ?>
      <tr >
      <td colspan="4"></td>
      <td>TOTAL DATA: <?php echo $count?></td>
  </tr>
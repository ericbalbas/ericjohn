<?php
include '../database/database.php';
$query5 = "SELECT disability1, count(*) as numbers FROM pwdprofile GROUP BY disability1";
$result5 = mysqli_query($conn, $query5);

while($row = mysqli_fetch_assoc($result5)){
    $dis1 = $row['disability1'];
    $numbers = $row['numbers'];
    
?>

    <tr>
        <td><?php echo $dis1; ?></td>
        <td><?php echo $numbers; ?></td>
    </tr>

<?php
    }
?>


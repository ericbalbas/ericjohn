<?php
include '../database/database.php';

$query3 = "SELECT sex, count(*) as number FROM seniorprofile GROUP BY sex";
$result3 = mysqli_query($conn, $query3);

while($row = mysqli_fetch_assoc($result3)){
    $sex = $row['sex'];
    $num = $row['number'];
    
?>

    <tr>
        <td><?php echo $sex; ?></td>
        <td><?php echo $num; ?></td>
    </tr>

<?php
    }
?>
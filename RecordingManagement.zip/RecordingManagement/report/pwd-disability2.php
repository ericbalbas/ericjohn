<?php
include '../database/database.php';
$query6 = "SELECT disability2, count(*) as numberss FROM pwdprofile GROUP BY disability2";
$result6 = mysqli_query($conn, $query6);

while($row = mysqli_fetch_assoc($result6)){
    $dis2 = $row['disability2'];
    $numbers = $row['numberss'];
    
?>

    <tr>
        <td><?php echo $dis2; ?></td>
        <td><?php echo $numbers; ?></td>
    </tr>

<?php
    }
?>


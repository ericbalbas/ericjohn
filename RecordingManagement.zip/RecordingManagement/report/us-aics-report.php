<?php
include '../database/database.php';

$sql = "SELECT COUNT(*) FROM aicsprofile";
$result = mysqli_query($conn, $sql);
$count = mysqli_fetch_assoc($result) ['COUNT(*)'];

$query2 = "SELECT * from aicsprofile ORDER BY id";
$result2 = mysqli_query($conn, $query2);

$query3 = "SELECT sex, count(*) as number FROM aicsprofile GROUP BY sex";
$result3 = mysqli_query($conn, $query3);

$query4 = "SELECT address, count(*) as num FROM aicsprofile GROUP BY address";
$result4 = mysqli_query($conn, $query4);

$query5 = "SELECT * FROM aicsprofile";
$result5 = mysqli_query($conn, $query5);

$row = mysqli_num_rows($result5);
 
?>

<?php
session_start();
if (isset($_SESSION['username']) && isset($_SESSION['id']))
{

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
    <link rel="stylesheet" href="../aics/css/scstyle.css" />
    <link rel="stylesheet" type="text/css" href="../aics/css/print2.css" media="print">
 
    <title>admin-AICS report</title>
</head>
<body>
    <div class="d-flex" id="wrapper">
       <!-- Sidebar -->
             
       <div style="background:#231f20" id="sidebar-wrapper">
                       
                       <div class="sidebar-heading text-center py-4 text-success fs-4 fw-bold text-uppercase"><i
                              class="	fas fa-campground me-2"></i>e-rms</div>
                      <div class="list-group list-group-flush my-3">
                        <a href="../user/aicsdashboard.php" class="list-group-item text-uppercase list-group-item-action bg-transparent text-light fw-bold "><i
                                  class="fas fa-tachometer-alt me-2"></i>Dashboard</a>
                        <a href="../report/us-aics-report.php" class="list-group-item list-group-item-action text-light bg-transparent  fw-bold"><i
                    class="	fas fa-chart-bar "></i> REPORT</a>    
                          <a href="../user/record/us-aics-display.php" class="list-group-item list-group-item-action bg-transparent text-light  fw-bold"><i
                                  class="fa fa-edit"></i> MANAGE RECORD</a>
                                  <a href="../user/record/aics_logs.php" class="list-group-item list-group-item-action text-light bg-transparent  fw-bold"><i
                                  class="fa fa-tasks "></i> LOGS</a>     
                          <a href="#" data-toggle="modal" data-target="#changeModal" class="list-group-item list-group-item-action bg-transparent text-light fw-bold"><i
                              class="fa fa-cog me-2"></i> SETTING</a> 
                              <!-- Modal -->
                              <div class="modal fade" id="changeModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                              <div class="modal-dialog">
                                  <div class="modal-content">
                                  <style>
                                          .form-control{
                                              border-top: 0;
                                              border-left: 0;
                                              border-right: 0;
             
                                          }
                                          .form-select{
                                              border-top: 0;
                                              border-left: 0;
                                              border-right: 0;
                                          }
                                          .form-select:focus{
                                              border-top: 0;
                                              border-left: 0;
                                              border-right: 0;
                                          }
                                          .form-control:focus{  
                                              box-shadow: none;
                                            
                                          }
                                      </style>
                                  <div class="modal-header" style="background:#42A5F5" >
                                      <h5 class="modal-title fw-bold" id="exampleModalLabel"><i  class="fa fa-cog me-2"></i>CHANGE PASSWORD</h5>
                                      <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"></button>
                                  </div>
                                  <div class="modal-body">
                                  <form action="../login/changepass.php" method="POST" autocomplete="off">
                                  <div class="row">
                                      <div class="col">
                                          <label for="">Current Password</label>
                                              <input type="text" name="current" class="form-control" placeholder="Current Password">
                                      </div>
                                  </div>
                                  <div class="row">
                                      <div class="col">
                                          <label for="">New Password</label>
                                              <input type="Password" name="new" class="form-control" placeholder="New Password">
                                          </div>
                                  </div>
                                  <div class="row">
                                      <div class="col">
                                          <label for="">Confirm Password</label>
                                              <input type="password" name="confirm" class="form-control" placeholder="Confirm Password">
                                      </div>
                                  </div>
                                      
                                  
                                  </div>
                                  <div class="modal-footer">
                                       <button type="submit" class="btn fw-bold text-light text-uppercase " name="change_btn" style="background:#42A5F5" >Change Password</button>          
                                  </form>
                                        
                                     
                                  </div>
                                  </div>
                              </div>
                              </div>    
                         
                           
                          <a href="#" data-toggle="modal" data-target="#logoutModal" class="list-group-item text-uppercase list-group-item-action bg-transparent text-light text-danger fw-bold"><i
                                  class="fas fa-power-off me-2"></i>Logout</a>
                          <!-- Button trigger modal -->
                           
                              <!-- Modal -->
                              <div class="modal fade" id="logoutModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                              <div class="modal-dialog">
                                  <div class="modal-content">
                                  <div class="modal-header">
                                      <h5 class="modal-title" id="exampleModalLabel">Warning</h5>
                                      <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"></button>
                                  </div>
                                  <div class="modal-body">
                                      Ready to leave the site?
                                  </div>
                                  <div class="modal-footer">
                                      <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                     <form action="../login/logout.php" method="POST">
                                         <button type="submit" name="logout_btn" class="btn btn-primary">LOGOUT</button>
                                     </form>
                                  </div>
                                  </div>
                              </div>
                              </div>
                      </div>
                  </div>
                  <!-- /#sidebar-wrapper -->

        <!-- Page Content -->
        <div id="page-content-wrapper" style="background:#E0E0E0">
        
        <div class="d-flex px-3">
                <div class="flex-grow-1 ">
                    <nav class="navbar navbar-expand navbar-light bg-transparent text-light">
                        <div class="d-flex align-items-center">
                            <i class="fas fa-align-left text-dark fs-4 me-3" id="menu-toggle"></i>
                            <h2 class="fs-3 m-0 fw-bold text-dark text-uppercase border-bottom">AICS REPORT</h2>
                        </div>      
                    </nav>
                </div>
                <div class="dp pt-2">
                    <div class="dropdown show">
                        <a class="btn btn-secondary bg-transparent dropdown-toggle border-0 text-dark" href="#" role="button" id="btn_print" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="fa fa-cog me-2"></i> Action
                        </a>

                        <div class="dropdown-menu" aria-labelledby="btn_print" id="btn_print" >
                            <button onclick="window.print();" class="btn bg-transparent text-uppercase fw-bold dropdown-item " id="btn_print"><i class="fas fa-print"></i> print</button>                  
                        </div>
                        
                    </div>
                </div>
            </div>
           <div class="container-fluid px-4">
           
                    <div class="row g-3 ms-4">
                        <div class="col">
                         

                        </div>
                
                        <div class="col-sm-2">
                           
                          
                                <style>
                                .form-control{
                                    border-top: 0;
                                    border-left: 0;
                                    border-right: 0;
                                }
                                .form-control:focus{  
                                    box-shadow: none;
                                }
                                </style>
                                <form name="myform" action="" method="get">
                                        <Select name="search" id="btn_print" class="form-control mb-2" onchange="myform.submit()">

                                        <option value="" class="fw-bold" disable><b>Select here:</b> </option>
                                        <option value="address">By address </option> 
                                        <option value="sex">By sex</option> 
                                        <option value="age">By age </option>                   
                                        <option value="general">By general</option>
                                        </select>
                                    </form>
                    </div>       
                 
                                 
                
           </div>
           <?php            

                            if (isset($_GET['search']))
                                {                    
                                    if($_GET['search'] == 'general'){
                                       
                                        ?>
                                            <style>
                                                .scrollable{
                                                    height: 600px;
                                                    overflow:auto;
                                                }
                                                .scrollable::-webkit-scrollbar {
                                                        width: 8px;
                                                    }
                                                        
                                                    .scrollable::-webkit-scrollbar-track {
                                                        box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.3);
                                                    }
                                                        
                                                    .scrollable::-webkit-scrollbar-thumb {
                                                        background-color:#42A5F5;
                                                        outline: 1px solid slategrey;
                                                    }
                                                .scrollable .d-flex img {
                                                    width: 90px;
                                                    
                                                }
                                                    
                                                }
                                                .scrollable .d-flex img {
                                                    width: 90px;
                                                    
                                                }
                                            </style>
                                            
                                            <div class="scrollable bg-light rounded px-4">
                                            <div class="d-flex align-items-center pt-2">
                            
                                                    <img src="../asset/aics.png" class="me-4 mb-2 " alt=""> 
                                            
                                                        
                                                    <label for="" class="fw-bold">Republic of the Philippine<br>Province of La Union<br>
                                                    Municipality of Tubao <br>Municipal Social Welfare and Development<br>
                                                    </label><br>
                                                
                                            </div>
                                            <label for=""><?php echo "Report as of ".date("h:i:sa") .' - '.date("Y/m/d").'.'; ?></label>
                                            <table class="table bg-white border rounded shadow-sm  table-hover table-bordered" >
                                                <thead>

                                                    <tr>

                                                        <th></th>
                                                        <th>Name</th>
                                                        <th>Adress</th>
                                                        <th>Sex</th>
                                                        <th>Age</th>
                                                        
                                   
                                                    </tr>

                                                </thead>
                                                <tbody>
                                                    <?php
                                                        include '../report/aics-data.php';
                                                    ?>
                                                    
                                                    
                                                </tbody>
                                            </table>

                                            <div class="row">
                                                <div class="col">
                                                    <table class="table bg-white border rounded shadow-sm  table-hover table-bordered" style="width:300px" >
                                                            <thead>

                                                                <tr>
                                                                    <th>Address</th>
                                                                    <th>Total</th>
                                                                </tr>

                                                            </thead>
                                                            <tbody>
                                                            <tbody >
                                                                <?php 
                                                                    include '../report/aics-address.php';
                                                                ?>

                                                                   
                                                            </tbody>
                                                    </table>
                                                
                                                </div>
                                                <div class="col">
                                                    <table class="table bg-white border rounded shadow-sm  table-hover table-bordered" style="width:300px" >
                                                        <thead>

                                                            <tr>
                                                                <th>Gender</th>
                                                                <th>Total</th>
                                                            </tr>

                                                        </thead>
                                                        <tbody>
                                                        <tbody >
                                                                <?php 
                                                                     include '../report/aics-sex.php';
                                                                ?>
                                                            </tbody>
                                                    </table>
                                                </div>
                                                <div class="col">
                                                                        <table class="table bg-white border rounded shadow-sm  table-hover table-bordered" style="width:300px" >
                                                        <thead>

                                                            <tr>
                                                                <th>Age bracket</th>
                                                                <th>Total</th>
                                                            </tr>

                                                        </thead>
                                                        <tbody>
                                                        <tbody >
                                                                <?php 
                                                                     include '../report/aics-age.php';
                                                                ?>
                                                            </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                          
                                            </div>
                                        <?php
                                    }
                                    
                                    elseif($_GET['search'] =='address'){
                                        ?>
                                          <style>
                                                .scrollable{
                                                    height: 600px;
                                                    overflow:auto;
                                                }
                                                .scrollable::-webkit-scrollbar {
                                                        width: 8px;
                                                    }
                                                        
                                                    .scrollable::-webkit-scrollbar-track {
                                                        box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.3);
                                                    }
                                                        
                                                    .scrollable::-webkit-scrollbar-thumb {
                                                        background-color:#42A5F5;
                                                        outline: 1px solid slategrey;
                                                    }
                                                .scrollable .d-flex img {
                                                    width: 90px;
                                                    
                                                }
                                                    
                                                }
                                                .scrollable .d-flex img {
                                                    width: 90px;
                                                    
                                                }
                                            </style>
                                            
                                            <div class="scrollable bg-light rounded px-4">
                                                <div class="d-flex align-items-center pt-2">
                                
                                                        <img src="../asset/aics.png" class="me-4 mt-2 " alt=""> 
                                                
                                                            
                                                        <label for="" class="fw-bold">Republic of the Philippine<br>Province of La Union<br>
                                                        Municipality of Tubao <br>Municipal Social Welfare and Development<br>
                                                        </label><br>
                                                    
                                                </div>
                                            <label for=""><?php echo "Report as of ".date("h:i:sa") .' - '.date("Y/m/d").'.'; ?></label>
                                        <table class="table bg-white border rounded shadow-sm  table-hover table-bordered mt-2" >
                                          <thead>
                                              <tr>

                                                  <th></th>
                                                  <th>Name</th>
                                                  <th>Adress</th>
                                                  <th>Sex</th>
                                                  <th>Age</th>
                                                             

                                              </tr>
                                          </thead>
                                          <tbody >
                                                    <?php 
                                                        include '../report/aics-data.php';
                                                    ?>
                                                  
                                                </tbody>
                                            </table>
                                                   
                                    <table class="table bg-white border rounded shadow-sm  table-hover table-bordered" style="width:300px" >
                                        <thead>

                                            <tr>
                                                <th>Address</th>
                                                <th>Total</th>
                                            </tr>

                                        </thead>
                                        <tbody>
                                        <tbody >
                                            <?php 
                                                include '../report/aics-address.php';
                                            ?>
                                          </tbody>
                                    </table>
                                    </div>
                                  <?php
                                
                                }
                                elseif($_GET['search']=='sex'){
                                ?>
                                <style>
                                      .scrollable{
                                          height: 600px;
                                          overflow:auto;
                                      }
                                      .scrollable::-webkit-scrollbar {
                                              display: none;
                                          
                                      }
                                      .scrollable .d-flex img {
                                          width: 90px;
                                          
                                      }
                                  </style>
                                  
                                  <div class="scrollable bg-light rounded px-4">
                                  <div class="d-flex align-items-center pt-2">
                  
                                          <img src="../asset/aics.png" class="me-4 mt-2 " alt=""> 
                                  
                                              
                                          <label for="" class="fw-bold">Republic of the Philippine<br>Province of La Union<br>
                                          Municipality of Tubao <br>Municipal Social Welfare and Development<br>
                                          </label><br>
                                      
                                  </div>
                                  <label for=""><?php echo "Report as of ".date("h:i:sa") .' - '.date("Y/m/d").'.'; ?></label>
                              <table class="table bg-white border rounded shadow-sm  table-hover table-bordered mt-2" >
                                <thead>
                                    <tr>

                                        <th></th>
                                        <th>Name</th>
                                        <th>Adress</th>
                                        <th>Sex</th>
                                        <th>Age</th>
                                                   

                                    </tr>
                                </thead>
                                <tbody >
                                            <?php 
                                            include '../report/aics-data.php';
                                            ?>
                                      </tbody>
                                  </table>
                                  
                          <table class="table bg-white border rounded shadow-sm  table-hover table-bordered" style="width:300px" >
                              <thead>

                                  <tr>
                                      <th>Gender</th>
                                      <th>Total</th>
                                  </tr>

                              </thead>
                              <tbody>
                              <tbody >
                                            <?php 
                                                include '../report/aics-sex.php';
                                            ?>
                                </tbody>
                          </table>
                                    </div>
                         
                        <?php
                            }
                            elseif($_GET['search']=='age'){
                                ?>
                                <style>
                                      .scrollable{
                                          height: 600px;
                                          overflow:auto;
                                      }
                                      .scrollable::-webkit-scrollbar {
                                              display: none;
                                          
                                      }
                                      .scrollable .d-flex img {
                                          width: 90px;
                                          
                                      }
                                  </style>
                                  
                                  <div class="scrollable bg-light rounded px-4">
                                  <div class="d-flex align-items-center pt-2">
                  
                                          <img src="../asset/aics.png" class="me-4 mt-2 " alt=""> 
                                  
                                              
                                          <label for="" class="fw-bold">Republic of the Philippine<br>Province of La Union<br>
                                          Municipality of Tubao <br>Municipal Social Welfare and Development<br>
                                          </label><br>
                                      
                                  </div>
                                  <label for=""><?php echo "Report as of ".date("h:i:sa") .' - '.date("Y/m/d").'.'; ?></label>
                              <table class="table bg-white border rounded shadow-sm  table-hover table-bordered mt-2" >
                                <thead>
                                    <tr>

                                        <th></th>
                                        <th>Name</th>
                                        <th>Adress</th>
                                        <th>Sex</th>
                                        <th>Age</th>
                                                   

                                    </tr>
                                </thead>
                                <tbody >
                                             <?php 
                                                include '../report/aics-data.php';
                                            ?>
                                      </tbody>
                                  </table>
                                  
                            <table class="table bg-white border rounded shadow-sm  table-hover table-bordered" style="width:300px" >
                                <thead>

                                    <tr>
                                        <th>Age bracket</th>
                                        <th>Total</th>
                                    </tr>

                                </thead>
                                <tbody>
                                <tbody >
                                            <?php 
                                                include '../report/aics-age.php';
                                            ?>
                                    </tbody>
                            </table>
                         
                        <?php
                            }  
                        }else{
                            ?>
                            <style>
                                                .scrollable{
                                                    height: 600px;
                                                    overflow:auto;
                                                }
                                                .scrollable::-webkit-scrollbar {
                                                        width: 8px;
                                                    }
                                                        
                                                    .scrollable::-webkit-scrollbar-track {
                                                        box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.3);
                                                    }
                                                        
                                                    .scrollable::-webkit-scrollbar-thumb {
                                                        background-color:#42A5F5;
                                                        outline: 1px solid slategrey;
                                                    }
                                                .scrollable .d-flex img {
                                                    width: 90px;
                                                    
                                                }
                                                    
                                                }
                                                .scrollable .d-flex img {
                                                    width: 90px;
                                                    
                                                }
                                            </style>
                                            
                                            <div class="scrollable bg-light rounded px-4">
                                            <div class="d-flex align-items-center pt-2">
                            
                                                    <img src="../asset/aics.png" class="me-4 mb-2 " alt=""> 
                                            
                                                        
                                                    <label for="" class="fw-bold">Republic of the Philippine<br>Province of La Union<br>
                                                    Municipality of Tubao <br>Municipal Social Welfare and Development<br>
                                                    </label><br>
                                                
                                            </div>
                                            <label for=""><?php echo "Report as of ".date("h:i:sa") .' - '.date("Y/m/d").'.'; ?></label>
                                            <table class="table bg-white border rounded shadow-sm  table-hover table-bordered" >
                                                <thead>

                                                    <tr>

                                                        <th></th>
                                                        <th>Name</th>
                                                        <th>Adress</th>
                                                        <th>Sex</th>
                                                        <th>Age</th>
                                                        
                                   
                                                    </tr>

                                                </thead>
                                                <tbody>

                                                        <?php 
                                                            include '../report/aics-data.php';
                                                        ?>
                                                </tbody>
                                            </table>
                                            <div class="row">
                                                <div class="col">
                                                    <table class="table bg-white border rounded shadow-sm  table-hover table-bordered" style="width:300px" >
                                                            <thead>

                                                                <tr>
                                                                    <th>Address</th>
                                                                    <th>Total</th>
                                                                </tr>

                                                            </thead>
                                                            <tbody>
                                                            <tbody >
                                                                <?php 
                                                                    include '../report/aics-address.php';
                                                                ?>
                                                            </tbody>
                                                    </table>
                                                
                                                </div>
                                                <div class="col">
                                                    <table class="table bg-white border rounded shadow-sm  table-hover table-bordered" style="width:300px" >
                                                        <thead>

                                                            <tr>
                                                                <th>Gender</th>
                                                                <th>Total</th>
                                                            </tr>

                                                        </thead>
                                                        <tbody>
                                                        <tbody >
                                                                <?php 
                                                                    include '../report/aics-sex.php';
                                                                ?>
                                                            </tbody>
                                                    </table>
                                                </div>
                                                <div class="col">
                                                                        <table class="table bg-white border rounded shadow-sm  table-hover table-bordered" style="width:300px" >
                                                        <thead>

                                                            <tr>
                                                                <th>Age bracket</th>
                                                                <th>Total</th>
                                                            </tr>

                                                        </thead>
                                                        <tbody>
                                                        <tbody >
                                                                <?php 
                                                                    include '../report/aics-age.php';
                                                                ?>
                                                            </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                            </div>
                                            <?php
                        }
                        ?> 
                                            
                  
        </div>
    </div>
    <!-- /#page-content-wrapper -->
    </div>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>  
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script>
      
        var el = document.getElementById("wrapper");
        var toggleButton = document.getElementById("menu-toggle");

        toggleButton.onclick = function () {
            el.classList.toggle("toggled");
        };
    </script>
</body>

</html>
<?php
}
else
{
    header("location:../login/LoginForm.php");
}
?>

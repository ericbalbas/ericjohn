<?php
include '../database/database.php';
$sql = "SELECT COUNT(*) FROM pwdprofile";
$result = mysqli_query($conn, $sql);
$count = mysqli_fetch_assoc($result)['COUNT(*)'];
$query2 = "SELECT * from pwdprofile ORDER BY id";
$result2 = mysqli_query($conn, $query2);
 $i = 1;

     while($row = mysqli_fetch_assoc($result2)){
     
         $id = $row['id'];
         $applicantname = $row['applicantname'];
         $age = $row['age']; 
         $raddress = $row['raddress']; 
         $gender= $row['gender'];

 ?>
     <tr>

         <td><?php echo $i;$i++; ?></td>
         <td><?php echo $applicantname; ?></td>
         <td><?php echo $raddress?></td>
         <td><?php echo $age; ?></td>
         <td><?php echo $gender;?></td>
         
        
        

     </tr>
    
 <?php
     }
     ?>
     <tr >
     <td colspan="4"></td>
     <td>TOTAL DATA: <?php echo $count?></td>
 </tr>



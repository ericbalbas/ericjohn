<?php 
include '../database/database.php';
$query4 = "SELECT address, count(*) as num FROM aicsprofile GROUP BY address";
$result4 = mysqli_query($conn, $query4);
    while($row = mysqli_fetch_assoc($result4)){
        $address = $row['address'];
        $num = $row['num'];
?>

    <tr>
        <td><?php echo $address; ?></td>
        <td><?php echo $num; ?></td>
    </tr>

<?php
    }
?>
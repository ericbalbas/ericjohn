<?php
include '../database/database.php';

$query1 = "SELECT age, count(*) as num FROM seniorprofile GROUP BY id";
$result1 = mysqli_query($conn, $query1);

$q = 0; $w = 0; $e = 0; $r = 0;
while($row = mysqli_fetch_assoc($result1)){
    if($row['age'] <= '70' && $row['age'] >= '60'){
        $q++;   
    }
    if($row['age'] <= '89' && $row['age'] >= '71'){
        $w++;
    }
    if($row['age'] >= '90' && $row['age'] <= '99'){
        $e++;
    }  
    if($row['age'] >= '100'){
        $r++;
    }
         ?>
     <?php
         }
     ?>
             <tr>
                 <td>60-70</td>
                 <td><?php if($q == '0'){ echo '0';} else{ echo $q;}  ?></td>
             </tr>
             <tr>
                 <td>70-80</td>
                 <td><?php if($w == '0'){ echo '0';} else{ echo $w;}  ?></td>
             </tr>
             <tr>
                 <td>80-100</td>
                 <td><?php if($e == '0'){ echo '0';} else{ echo $e;}  ?></td>
             </tr>
             <tr>
                 <td>100 ↑</td>
                 <td><?php if($r == '0'){ echo '0';} else{ echo $r;}  ?></td>
             </tr>

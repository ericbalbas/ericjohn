<?php 
include '../database/database.php';
$query5 = "SELECT * FROM aicsprofile";
$result5 = mysqli_query($conn, $query5);

$row = mysqli_num_rows($result5);

 $q = 0; $w = 0; $e = 0; $r = 0;
 while($row = mysqli_fetch_assoc($result5)){
     if($row['age'] <= '20' && $row['age'] >= '1'){
         $q++;   
     }
     if($row['age'] <= '39' && $row['age'] >= '21'){
         $w++;
     }
     if($row['age'] >= '40' && $row['age'] <= '59'){
         $e++;
     }  
     if($row['age'] >= '61'){
         $r++;
     }
     ?>
     
 <?php
     }
 ?>
         <tr>
             <td>20↓</td>
             <td><?php if($q == '0'){ echo '0';} else{ echo $q;}  ?></td>
         </tr>
         <tr>
             <td>21-39</td>
             <td><?php if($w == '0'){ echo '0';} else{ echo $w;}  ?></td>
         </tr>
         <tr>
             <td>40-59</td>
             <td><?php if($e == '0'){ echo '0';} else{ echo $e;}  ?></td>
         </tr>
         <tr>
             <td>60 ↑</td>
             <td><?php if($r == '0'){ echo '0';} else{ echo $r;}  ?></td>
         </tr>

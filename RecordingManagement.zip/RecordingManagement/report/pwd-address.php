<?php
include '../database/database.php';
$query4 = "SELECT raddress, count(*) as num FROM pwdprofile GROUP BY raddress";
$result4 = mysqli_query($conn, $query4);

while($row = mysqli_fetch_assoc($result4)){
    $address = $row['raddress'];
    $num = $row['num'];
?>

<tr>
    <td><?php echo $address; ?></td>
    <td><?php echo $num; ?></td>
</tr>

<?php
}
?>

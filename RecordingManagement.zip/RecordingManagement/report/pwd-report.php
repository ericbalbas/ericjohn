<?php
include '../database/database.php'; 
?>

<?php
session_start();
if (isset($_SESSION['username']) && isset($_SESSION['id']))
{

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
    <link rel="stylesheet" href="../aics/css/adminstyle.css" />
    <link rel="stylesheet" type="text/css" href="../aics/css/print2.css" media="print">
 
    <title>admin-AICS report</title>
</head>
<body>
    <div class="d-flex" id="wrapper">
        <!-- Sidebar -->
        <div style="background:#232B2B"  id="sidebar-wrapper">
        <div class="sidebar-heading text-center py-4 text-success fs-4 fw-bold text-uppercase "><i
                    class="	fas fa-campground me-2"></i>e-rms</div>
            <div class="list-group list-group-flush my-3">
                <a href="../aics/admindashboard.php" class="list-group-item list-group-item-action bg-transparent text-light fw-bold "><i
                        class="fas fa-tachometer-alt me-2"></i>Dashboard</a>
                <a class="list-group-item list-group-item-action bg-transparent text-light  fw-bold" 
                data-toggle="collapse" href="#collapse1">Reports</a>
                <div id="collapse1" class="list-group list-group-flush my-3 collapse">
                <a href="../report/senior-report.php" class="list-group-item list-group-item-action bg-transparent text-light  fw-bold"><i
                        class="fas fa-assistive-listening-systems ms-3"></i> Senior Citizen</a>
                
                <a href="../report/aics-report.php" class="list-group-item list-group-item-action bg-transparent text-light  fw-bold"><i
                        class="	fas fa-money-check-alt ms-3"></i> AICS</a>
                <a href="../report/pwd-report.php" class="list-group-item list-group-item-action bg-transparent text-light  fw-bold"><i
                class="	fas fa-heartbeat ms-3"></i> PWD</a>    
                </div>
                
                <a class="list-group-item list-group-item-action bg-transparent text-light fw-bold" 
                data-toggle="collapse" href="#collapse2">Manage Records</a>
                <div id="collapse2" class="list-group list-group-flush my-3 collapse">
                <a href="../seniorcitizen/sc-display.php" class="list-group-item list-group-item-action bg-transparent text-light fw-bold"><i
                        class="fas fa-assistive-listening-systems ms-3"></i> Senior Citizen</a>
             
                <a href="../aics/aicsdisplay.php" class="list-group-item list-group-item-action bg-transparent text-light  fw-bold"><i
                        class="fas fa-money-check-alt ms-3"></i> AICS</a>  
                <a href="../pwd/pwd-display.php" class="list-group-item list-group-item-action bg-transparent text-light  fw-bold"><i
                        class="fas fa-heartbeat ms-3"></i> PWD</a>
                </div>
                <a class="list-group-item list-group-item-action bg-transparent text-light fw-bold" 
                data-toggle="collapse" href="#collapse3">Memorandum</a>
                <div id="collapse3" class="list-group list-group-flush my-3 collapse">
           
                <a href="../memorandum/display_memo.php" class="list-group-item list-group-item-action bg-transparent text-light  fw-bold"><i
                        class="	fas fa-file-signature ms-3"></i> Manage</a>
        
                </div>

                <a class="list-group-item list-group-item-action text-light bg-transparent fw-bold" 
                data-toggle="collapse" href="#collapse4">Settings</a>
                <div id="collapse4" class="list-group list-group-flush my-3 collapse">
                <a href="#" data-toggle="modal" data-target="#changeModal" class="list-group-item text-light list-group-item-action bg-transparent text-light fw-bold"><i
                    class="fa fa-cog me-2"></i> Change password</a> 
                    <a href="#" data-toggle="modal" data-target="#addModal" class="list-group-item text-light list-group-item-action bg-transparent text-light fw-bold"><i
                    class="fa fa-plus me-2"></i> Add user</a> 
                    <a href="../logs/admin_logs.php" class="list-group-item list-group-item-action text-light bg-transparent  fw-bold"><i
                        class="fas fa-tasks me-2"></i> Logs</a>
                        <a href="../backup/export.php" class="list-group-item list-group-item-action text-light bg-transparent  fw-bold"><i class="fa fa-archive" aria-hidden="true"></i>
                     Back up</a> 
                        </div>
                 <!-- Button trigger modal -->
                 
                    <!-- Modal -->
                    <div class="modal fade" id="changeModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                        <div class="modal-header text-center" style="background:#7dd07d">
                            <h5 class="modal-title fw-bold text-light " id="exampleModalLabel" ><i class="fa fa-cog me-2"></i>CHANGE PASSWORD</h5>
                            <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <style>
                                .form-control{
                                    border-top: 0;
                                    border-left: 0;
                                    border-right: 0;
   
                                }
                                .form-select{
                                    border-top: 0;
                                    border-left: 0;
                                    border-right: 0;
                                }
                                .form-select:focus{
                                    border-top: 0;
                                    border-left: 0;
                                    border-right: 0;
                                }
                                .form-control:focus{  
                                    box-shadow: none;
                                  
                                }
                            </style>
                        <form action="../login/changepass.php" method="POST" class="" autocomplete="off">
                        <div class="row">
                            <div class="col">
                                <label for="">Current Password</label>
                                    <input type="text" name="current" class="form-control" placeholder="Current Password" required>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col">
                                <label for="">New Password</label>
                                    <input type="Password" name="new" class="form-control" placeholder="New Password" required>
                                </div>
                        </div>
                        <div class="row">
                            <div class="col">
                                <label for="">Confirm Password</label>
                                    <input type="password" name="confirm" class="form-control" placeholder="Confirm Password" required>
                            </div>
                        </div>
                            
                        
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn fw-bold text-light text-uppercase mt-2" name="change_btn" style="background:#7dd07d">Change password</button>          
                            </form>

                        </div>
                        </div>
                    </div>
                    </div>    

                      <!-- Modal -->
                      <div class="modal fade" id="addModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                        <div class="modal-header" style="background:#7dd07d">
                            <h5 class="modal-title fw-bold text-light" id="exampleModalLabel"><i class="fa fa-cog me-2"></i>ADD USER</h5>
                            <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                        <!-- STATUS -->
                       
                    <!-- STATUS -->
                        
                        <form action="../login/add-user.php" method="POST" class="">
                        <div class="row">
                            <div class="col">
                                <label for="">Username</label>
                                <select class="form-select" name="add_username" required>
                                  <option value="" disable selected hidden>user</option>
                                  <option value="admin">admin</option>
                                  <option value="pwd">pwd</option>   
                                  <option value="senior">senior</option>
                                  <option value="aics">aics</option>     
                                </select>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col">
                                <label for="">Role</label>
                                <select class="form-select" name="add_role" required>
                                  <option value="" disable selected hidden>role</option>
                                  <option value="admin">admin</option>
                                  <option value="user">user</option>   
                                </select>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col">
                                <label for="">Password</label>
                                    <input type="Password" name="add_pass" class="form-control" placeholder="New Password" required>
                                </div>
                        </div>
                        <div class="row">
                            <div class="col">
                                <label for="">Confirm Password</label>
                                    <input type="password" name="add_confirm" class="form-control" placeholder="Confirm Password" required>
                            </div>
                        </div>
                           
                        
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn fw-bold text-light text-uppercase" name="add_btn" style="background:#7dd07d">Add user</button>          
                            </form>
                              
                           
                        </div>
                        </div>
                    </div>
                    </div>    
                <a href="#" data-toggle="modal" data-target="#logoutModal" class="list-group-item list-group-item-action bg-transparent text-light text-danger fw-bold"><i
                        class="fas fa-power-off me-2"></i>Logout</a>
                <!-- Button trigger modal -->
                 
                    <!-- Modal -->
                    <div class="modal fade" id="logoutModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Warning</h5>
                            <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            Ready to leave the site?
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                           <form action="../login/logout.php" method="POST">
                               <button type="submit" name="logout_btn" class="btn btn-primary">logout</button>
                           </form>
                        </div>
                        </div>
                    </div>
                    </div>
            </div>
        </div>
        <!-- /#sidebar-wrapper -->

        <!-- Page Content -->
        <div id="page-content-wrapper" style="background:#E0E0E0">
        
        <div class="d-flex px-3">
                <div class="flex-grow-1 ">
                    <nav class="navbar navbar-expand navbar-light bg-transparent text-light">
                        <div class="d-flex align-items-center">
                            <i class="fas fa-align-left text-dark fs-4 me-3" id="menu-toggle"></i>
                            <h2 class="fs-3 m-0 fw-bold text-dark text-uppercase border-bottom">PWD REPORT</h2>
                        </div>      
                    </nav>
                </div>
                <div class="dp pt-2">
                    <div class="dropdown show">
                        <a class="btn btn-secondary bg-transparent dropdown-toggle border-0 text-dark" href="#" role="button" id="btn_print" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="fa fa-cog me-2"></i> Action
                        </a>

                        <div class="dropdown-menu" aria-labelledby="btn_print" id="btn_print" >
                            <button onclick="window.print();" class="btn bg-transparent text-uppercase fw-bold dropdown-item " id="btn_print"><i class="fas fa-print"></i> print</button>                  
                        </div>
                        
                    </div>
                </div>
            </div>
           <div class="container-fluid px-4">
           
                    <div class="row g-3 ms-4">
                        <div class="col">
                         

                        </div>
                
                        <div class="col-sm-2">
                           
                         
                                <style>
                                .form-control{
                                    border-top: 0;
                                    border-left: 0;
                                    border-right: 0;
                                }
                                .form-control:focus{  
                                    box-shadow: none;
                                }
                                </style>
                               
                               <form name="myform" action="" method="get">
                                        <Select name="search" id="btn_print" class="form-control mb-2" onchange="myform.submit()">

                                        <option value="" class="fw-bold" disable><b>Select here:</b> </option>
                                        <option value="address">By address </option> 
                                        <option value="sex">By sex</option> 
                                        <option value="age">By age </option>                   
                                        <option value="disabilities">By Disabilities</option>
                                        <option value="caused">By Causes</option>
                                        <option value="general">By general</option>
                                        </select>
                                    </form>
                        
                    </div>       
                 
                                 
                
           </div>
           <?php            

                            if (isset($_GET['search']))
                                {                    
                                    if($_GET['search'] == 'general'){
                                       
                                        ?>
                                            <style>
                                                .scrollable{
                                                    height: 600px;
                                                    overflow: auto;
                                                }
                                                .scrollable::-webkit-scrollbar {
                                                        width: 8px;
                                                    }
                                                        
                                                    .scrollable::-webkit-scrollbar-track {
                                                        box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.3);
                                                    }
                                                        
                                                    .scrollable::-webkit-scrollbar-thumb {
                                                        background-color:#7dd07d;
                                                        outline: 1px solid slategrey;
                                                    }
                                                    
                                                
                                                .scrollable .d-flex img {
                                                    width: 90px;
                                                    
                                                }
                                            </style>
                                            
                                            <div class="scrollable bg-light rounded px-4">
                                            <div class="d-flex align-items-center pt-2">
                            
                                                    <img src="../asset/aics.png" class="me-4 mb-2 " alt=""> 
                                            
                                                        
                                                    <label for="" class="fw-bold">Republic of the Philippine<br>Province of La Union<br>
                                                    Municipality of Tubao <br>Municipal Social Welfare and Development<br>
                                                    </label><br>
                                                
                                            </div>
                                            <label for=""><?php echo "Report as of ".date("h:i:sa") .' - '.date("Y/m/d").'.'; ?></label>
                                            <table class="table bg-white border rounded shadow-sm  table-hover table-bordered" >
                                                <thead>

                                                    <tr>

                                                        <th></th>
                                                        <th>Name</th>
                                                        <th>Adress</th>
                                                        <th>Sex</th>
                                                        <th>Age</th>
                                                        
                                   
                                                    </tr>

                                                </thead>
                                                <tbody>

                                                    <?php 
                                                            include '../report/pwd-data.php';

                                                    ?>
                                                        
                                                </tbody>
                                            </table>

                                            <div class="row">
                                                <div class="col">
                                                    <table class="table bg-white border rounded shadow-sm  table-hover table-bordered" style="width:300px" >
                                                            <thead>

                                                                <tr>
                                                                    <th>Address</th>
                                                                    <th>Total</th>
                                                                </tr>

                                                            </thead>
                                                            <tbody>
                                                            <tbody >
                                                                <?php 
                                                                   include '../report/pwd-address.php';
                                                              
                                                                ?>
                                                            </tbody>
                                                    </table>
                                                
                                                </div>
                                                <div class="col">
                                                    <table class="table bg-white border rounded shadow-sm  table-hover table-bordered" style="width:300px" >
                                                        <thead>

                                                            <tr>
                                                                <th>Gender</th>
                                                                <th>Total</th>
                                                            </tr>

                                                        </thead>
                                                        <tbody>
                                                        <tbody >
                                                                <?php 
                                                                    
                                                                    include '../report/pwd-sex.php';
                                                              
                                                                ?>
                                                            </tbody>
                                                    </table>
                                                </div>
                                                <div class="col">
                                                                <table class="table bg-white border rounded shadow-sm  table-hover table-bordered" style="width:300px" >
                                                        <thead>

                                                            <tr>
                                                                <th>Age bracket</th>
                                                                <th>Total</th>
                                                            </tr>

                                                        </thead>
                                                        <tbody>
                                                        <tbody >
                                                                <?php 
                                                                    include '../report/pwd-age.php';
                                                                ?>
                                                                        
                                                                
                                                            </tbody>
                                                    </table>
                                                </div>
                                                <div class="col">
                                                                <table class="table bg-white border rounded shadow-sm  table-hover table-bordered" style="width:300px" >
                                                        <thead>

                                                            <tr>
                                                                <th>Disabilities</th>
                                                                <th>Total</th>
                                                            </tr>

                                                        </thead>
                                                        <tbody>
                                                        <tbody >
                                                                <?php 
                                                                    include '../report/pwd-disability1.php';
                                                                ?>
                                                                        
                                                                
                                                            </tbody>
                                                    </table>
                                                </div>
                                                <div class="col">
                                                                <table class="table bg-white border rounded shadow-sm  table-hover table-bordered" style="width:300px" >
                                                        <thead>

                                                            <tr>
                                                                <th>Caused</th>
                                                                <th>Total</th>
                                                            </tr>

                                                        </thead>
                                                        <tbody>
                                                        <tbody >
                                                                <?php 
                                                                    include '../report/pwd-disability2.php';
                                                                ?>
                                                                        
                                                                
                                                            </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                          
                                            </div>
                                        <?php
                                    }
                                    elseif($_GET['search'] =='address'){
                                        ?>
                                          <style>
                                                .scrollable{
                                                    height: 600px;
                                                    overflow: auto;
                                                }
                                                .scrollable::-webkit-scrollbar {
                                                        width: 8px;
                                                    }
                                                        
                                                    .scrollable::-webkit-scrollbar-track {
                                                        box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.3);
                                                    }
                                                        
                                                    .scrollable::-webkit-scrollbar-thumb {
                                                        background-color:#7dd07d;
                                                        outline: 1px solid slategrey;
                                                    }
                                                    
                                                
                                                .scrollable .d-flex img {
                                                    width: 90px;
                                                    
                                                }
                                            </style>
                                            
                                            <div class="scrollable bg-light rounded px-4">
                                                <div class="d-flex align-items-center pt-2">
                                
                                                        <img src="../asset/aics.png" class="me-4 mt-2 " alt=""> 
                                                
                                                            
                                                        <label for="" class="fw-bold">Republic of the Philippine<br>Province of La Union<br>
                                                        Municipality of Tubao <br>Municipal Social Welfare and Development<br>
                                                        </label><br>
                                                    
                                                </div>
                                            <label for=""><?php echo "Report as of ".date("h:i:sa") .' - '.date("Y/m/d").'.'; ?></label>
                                            <table class="table bg-white border rounded shadow-sm  table-hover table-bordered" >
                                                <thead>

                                                    <tr>

                                                        <th></th>
                                                        <th>Name</th>
                                                        <th>Adress</th>
                                                        <th>Sex</th>
                                                        <th>Age</th>
                                                        
                                   
                                                    </tr>

                                                </thead>
                                                <tbody>

                                                    <?php 
                                                            include '../report/pwd-data.php';

                                                    ?>
                                                        
                                                </tbody>
                                            </table>
                                                   
                                            <table class="table bg-white border rounded shadow-sm  table-hover table-bordered" style="width:300px" >
                                                            <thead>

                                                                <tr>
                                                                    <th>Address</th>
                                                                    <th>Total</th>
                                                                </tr>

                                                            </thead>
                                                            <tbody>
                                                            <tbody >
                                                                <?php 
                                                                   include '../report/pwd-address.php';
                                                              
                                                                ?>
                                                            </tbody>
                                                    </table>
                                    </div>
                                  <?php
                                
                                }
                                elseif($_GET['search'] =='disabilities'){
                                    ?>
                                      <style>
                                            .scrollable{
                                                height: 600px;
                                                overflow: auto;
                                            }
                                            .scrollable::-webkit-scrollbar {
                                                    display: none;
                                                
                                            }
                                            .scrollable .d-flex img {
                                                width: 90px;
                                                
                                            }
                                        </style>
                                        
                                        <div class="scrollable bg-light rounded px-4">
                                            <div class="d-flex align-items-center pt-2">
                            
                                                    <img src="../asset/aics.png" class="me-4 mt-2 " alt=""> 
                                            
                                                        
                                                    <label for="" class="fw-bold">Republic of the Philippine<br>Province of La Union<br>
                                                    Municipality of Tubao <br>Municipal Social Welfare and Development<br>
                                                    </label><br>
                                                
                                            </div>
                                        <label for=""><?php echo "Report as of ".date("h:i:sa") .' - '.date("Y/m/d").'.'; ?></label>
                                        <table class="table bg-white border rounded shadow-sm  table-hover table-bordered" >
                                            <thead>

                                                <tr>

                                                    <th></th>
                                                    <th>Name</th>
                                                    <th>Adress</th>
                                                    <th>Sex</th>
                                                    <th>Age</th>
                                                    
                               
                                                </tr>

                                            </thead>
                                            <tbody>

                                                <?php 
                                                        include '../report/pwd-data.php';

                                                ?>
                                                    
                                            </tbody>
                                        </table>
                                               
                                        <table class="table bg-white border rounded shadow-sm  table-hover table-bordered" style="width:300px" >
                                                        <thead>

                                                            <tr>
                                                                <th>Disabilities</th>
                                                                <th>Total</th>
                                                            </tr>

                                                        </thead>
                                                        <tbody>
                                                        <tbody >
                                                            <?php 
                                                               include '../report/pwd-disability1.php';
                                                          
                                                            ?>
                                                        </tbody>
                                                </table>
                                </div>
                              <?php
                            
                            }
                            elseif($_GET['search'] =='caused'){
                                ?>
                                  <style>
                                        .scrollable{
                                            height: 600px;
                                            overflow: auto;
                                        }
                                        .scrollable::-webkit-scrollbar {
                                                display: none;
                                            
                                        }
                                        .scrollable .d-flex img {
                                            width: 90px;
                                            
                                        }
                                    </style>
                                    
                                    <div class="scrollable bg-light rounded px-4">
                                        <div class="d-flex align-items-center pt-2">
                        
                                                <img src="../asset/aics.png" class="me-4 mt-2 " alt=""> 
                                        
                                                    
                                                <label for="" class="fw-bold">Republic of the Philippine<br>Province of La Union<br>
                                                Municipality of Tubao <br>Municipal Social Welfare and Development<br>
                                                </label><br>
                                            
                                        </div>
                                    <label for=""><?php echo "Report as of ".date("h:i:sa") .' - '.date("Y/m/d").'.'; ?></label>
                                    <table class="table bg-white border rounded shadow-sm  table-hover table-bordered" >
                                        <thead>

                                            <tr>

                                                <th></th>
                                                <th>Name</th>
                                                <th>Adress</th>
                                                <th>Sex</th>
                                                <th>Age</th>
                                                
                           
                                            </tr>

                                        </thead>
                                        <tbody>

                                            <?php 
                                                    include '../report/pwd-data.php';

                                            ?>
                                                
                                        </tbody>
                                    </table>
                                           
                                    <table class="table bg-white border rounded shadow-sm  table-hover table-bordered" style="width:300px" >
                                                    <thead>

                                                        <tr>
                                                            <th>Caused</th>
                                                            <th>Total</th>
                                                        </tr>

                                                    </thead>
                                                    <tbody>
                                                    <tbody >
                                                        <?php 
                                                           include '../report/pwd-disability2.php';
                                                      
                                                        ?>
                                                    </tbody>
                                            </table>
                            </div>
                          <?php
                        
                        }
                                elseif($_GET['search']=='sex'){
                                ?>
                                <style>
                                      .scrollable{
                                          height: 600px;
                                          overflow: auto;
                                      }
                                      .scrollable::-webkit-scrollbar {
                                              display: none;
                                          
                                      }
                                      .scrollable .d-flex img {
                                          width: 90px;
                                          
                                      }
                                  </style>
                                  
                                  <div class="scrollable bg-light rounded px-4">
                                  <div class="d-flex align-items-center pt-2">
                  
                                          <img src="../asset/aics.png" class="me-4 mt-2 " alt=""> 
                                  
                                              
                                          <label for="" class="fw-bold">Republic of the Philippine<br>Province of La Union<br>
                                          Municipality of Tubao <br>Municipal Social Welfare and Development<br>
                                          </label><br>
                                      
                                  </div>
                                  <label for=""><?php echo "Report as of ".date("h:i:sa") .' - '.date("Y/m/d").'.'; ?></label>
                                  <table class="table bg-white border rounded shadow-sm  table-hover table-bordered" >
                                                <thead>

                                                    <tr>

                                                        <th></th>
                                                        <th>Name</th>
                                                        <th>Adress</th>
                                                        <th>Sex</th>
                                                        <th>Age</th>
                                                        
                                   
                                                    </tr>

                                                </thead>
                                                <tbody>

                                                    <?php 
                                                            include '../report/pwd-data.php';

                                                    ?>
                                                        
                                                </tbody>
                                            </table>
                                                   
                                            <table class="table bg-white border rounded shadow-sm  table-hover table-bordered" style="width:300px" >
                                                            <thead>

                                                                <tr>
                                                                    <th>Sex</th>
                                                                    <th>Total</th>
                                                                </tr>

                                                            </thead>
                                                            <tbody>
                                                            <tbody >
                                                                <?php 
                                                                   include '../report/pwd-sex.php';
                                                              
                                                                ?>
                                                            </tbody>
                                                    </table>
                                    </div>
                         
                        <?php
                            }
                            elseif($_GET['search']=='age'){
                                ?>
                                <style>
                                      .scrollable{
                                          height: 600px;
                                          overflow: auto;
                                      }
                                      .scrollable::-webkit-scrollbar {
                                              display: none;
                                          
                                      }
                                      .scrollable .d-flex img {
                                          width: 90px;
                                          
                                      }
                                  </style>
                                  
                                  <div class="scrollable bg-light rounded px-4">
                                  <div class="d-flex align-items-center pt-2">
                  
                                          <img src="../asset/aics.png" class="me-4 mt-2 " alt=""> 
                                  
                                              
                                          <label for="" class="fw-bold">Republic of the Philippine<br>Province of La Union<br>
                                          Municipality of Tubao <br>Municipal Social Welfare and Development<br>
                                          </label><br>
                                      
                                  </div>
                                  <label for=""><?php echo "Report as of ".date("h:i:sa") .' - '.date("Y/m/d").'.'; ?></label>
                                  <table class="table bg-white border rounded shadow-sm  table-hover table-bordered" >
                                                <thead>

                                                    <tr>

                                                        <th></th>
                                                        <th>Name</th>
                                                        <th>Adress</th>
                                                        <th>Sex</th>
                                                        <th>Age</th>
                                                        
                                   
                                                    </tr>

                                                </thead>
                                                <tbody>

                                                    <?php 
                                                            include '../report/pwd-data.php';

                                                    ?>
                                                        
                                                </tbody>
                                            </table>
                                  
                               <div class="col">
                                                                <table class="table bg-white border rounded shadow-sm  table-hover table-bordered" style="width:300px" >
                                                        <thead>

                                                            <tr>
                                                                <th>Age bracket</th>
                                                                <th>Total</th>
                                                            </tr>

                                                        </thead>
                                                        <tbody>
                                                        <tbody >
                                                                <?php 
                                                                    include '../report/pwd-age.php';
                                                                ?>
                                                                        
                                                                
                                                            </tbody>
                                                    </table>
                                                </div>
                         
                        <?php
                            }  
                        }else{
                            ?>
                            <style>
                                                .scrollable{
                                                    height: 600px;
                                                    overflow: auto;
                                                }
                                                .scrollable::-webkit-scrollbar {
                                                        width: 8px;
                                                    }
                                                        
                                                    .scrollable::-webkit-scrollbar-track {
                                                        box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.3);
                                                    }
                                                        
                                                    .scrollable::-webkit-scrollbar-thumb {
                                                        background-color:#7dd07d;
                                                        outline: 1px solid slategrey;
                                                    }
                                                    
                                                
                                                .scrollable .d-flex img {
                                                    width: 90px;
                                                    
                                                }
                                            </style>
                                            
                                            <div class="scrollable bg-light rounded px-4">
                                            <div class="d-flex align-items-center pt-2">
                            
                                                    <img src="../asset/aics.png" class="me-4 mb-2 " alt=""> 
                                            
                                                        
                                                    <label for="" class="fw-bold">Republic of the Philippine<br>Province of La Union<br>
                                                    Municipality of Tubao <br>Municipal Social Welfare and Development<br>
                                                    </label><br>
                                                
                                            </div>
                                            <label for=""><?php echo "Report as of ".date("h:i:sa") .' - '.date("Y/m/d").'.'; ?></label>
                                            <table class="table bg-white border rounded shadow-sm  table-hover table-bordered" >
                                                <thead>

                                                    <tr>

                                                        <th></th>
                                                        <th>Name</th>
                                                        <th>Adress</th>
                                                        <th>Sex</th>
                                                        <th>Age</th>
                                                        
                                   
                                                    </tr>

                                                </thead>
                                                <tbody>

                                                    <?php 
                                                            include '../report/pwd-data.php';

                                                    ?>
                                                        
                                                </tbody>
                                            </table>

                                            <div class="row">
                                                <div class="col">
                                                    <table class="table bg-white border rounded shadow-sm  table-hover table-bordered" style="width:300px" >
                                                            <thead>

                                                                <tr>
                                                                    <th>Address</th>
                                                                    <th>Total</th>
                                                                </tr>

                                                            </thead>
                                                            <tbody>
                                                            <tbody >
                                                                <?php 
                                                                   include '../report/pwd-address.php';
                                                              
                                                                ?>
                                                            </tbody>
                                                    </table>
                                                
                                                </div>
                                                <div class="col">
                                                    <table class="table bg-white border rounded shadow-sm  table-hover table-bordered" style="width:300px" >
                                                        <thead>

                                                            <tr>
                                                                <th>Gender</th>
                                                                <th>Total</th>
                                                            </tr>

                                                        </thead>
                                                        <tbody>
                                                        <tbody >
                                                                <?php 
                                                                    
                                                                    include '../report/pwd-sex.php';
                                                              
                                                                ?>
                                                            </tbody>
                                                    </table>
                                                </div>
                                                <div class="col">
                                                                <table class="table bg-white border rounded shadow-sm  table-hover table-bordered" style="width:300px" >
                                                        <thead>

                                                            <tr>
                                                                <th>Age bracket</th>
                                                                <th>Total</th>
                                                            </tr>

                                                        </thead>
                                                        <tbody>
                                                        <tbody >
                                                                <?php 
                                                                    include '../report/pwd-age.php';
                                                                ?>
                                                                        
                                                                
                                                            </tbody>
                                                    </table>
                                                </div>
                                                <div class="col">
                                                                <table class="table bg-white border rounded shadow-sm  table-hover table-bordered" style="width:300px" >
                                                        <thead>

                                                            <tr>
                                                                <th>Disabilities</th>
                                                                <th>Total</th>
                                                            </tr>

                                                        </thead>
                                                        <tbody>
                                                        <tbody >
                                                                <?php 
                                                                    include '../report/pwd-disability1.php';
                                                                ?>
                                                                        
                                                                
                                                            </tbody>
                                                    </table>
                                                </div>
                                                <div class="col">
                                                                <table class="table bg-white border rounded shadow-sm  table-hover table-bordered" style="width:300px" >
                                                        <thead>

                                                            <tr>
                                                                <th>Caused</th>
                                                                <th>Total</th>
                                                            </tr>

                                                        </thead>
                                                        <tbody>
                                                        <tbody >
                                                                <?php 
                                                                    include '../report/pwd-disability2.php';
                                                                ?>
                                                                        
                                                                
                                                            </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                            </div>
                                            <?php
                        }
                        ?> 
                                            
                  
        </div>
    </div>
    <!-- /#page-content-wrapper -->
    </div>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>  
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script>
      
        var el = document.getElementById("wrapper");
        var toggleButton = document.getElementById("menu-toggle");

        toggleButton.onclick = function () {
            el.classList.toggle("toggled");
        };
    </script>
</body>

</html>
<?php
}
else
{
    header("location:../login/LoginForm.php");
}
?>

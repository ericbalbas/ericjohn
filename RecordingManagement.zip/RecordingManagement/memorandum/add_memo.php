<?php
session_start();
include_once '../database/database.php';
if(isset($_POST['upload'])){
    $memo_name=$_POST['memo_name'];
    $memo_date=$_POST['memo_date'];
    $memo_sender=$_POST['memo_sender'];
    $memo_recipient=$_POST['memo_recepient'];
    $memo_file=$_FILES['memo_file']['name'];

    $allowed_ext = array('png','jpeg','pdf','docx','docs','jpg','svg');
    $filename = $_FILES['memo_file']['name'];
    $file_ext = pathinfo($filename, PATHINFO_EXTENSION);
    $location = "../upload/".$filename;


    if(!in_array($file_ext,$allowed_ext)){
         $_SESSION['memostatus']="Invalid file extension!";
        header('Location:../memorandum/form_memo.php');
        
    }elseif($_FILES['memo_file']['size']>100000){
        $_SESSION['memostatus']="File too large!";
        header('Location:../memorandum/form_memo.php');
    }else{
        
    if(file_exists("../upload/" .$_FILES['memo_file']['name'])){
        $filename= $_FILES['memo_file']['name'];
        $_SESSION['memostatus']="File already exist".$filename;
        header('Location:../memorandum/form_memo.php');

    }else{
        $sql="INSERT INTO memorandum (memo_name,memo_date,memo_sender,memo_recipient,memo_file,location) 
        VALUES ('$memo_name','$memo_date','$memo_sender','$memo_recipient','$memo_file','$location')";
        $sql_run = mysqli_query($conn,$sql);
        
        if($sql_run){
            move_uploaded_file($_FILES["memo_file"]["tmp_name"],
            "../upload/".$_FILES["memo_file"]["name"]);
            $_SESSION['memostatus']="File inserted successfully!";
            header('Location:../memorandum/display_memo.php');
            
        }else{
           $_SESSION['memostatus']="File failed to insert!";
           header('Location:../memorandum/form_memo.php');
        
         
          
        }
    }
    }
 
}


if(isset($_POST['update'])){
    $id = $_POST['id'];
    $memo_name=$_POST['memo_name'];
    $memo_date=$_POST['memo_date'];
    $memo_sender=$_POST['memo_sender'];
    $memo_recipient=$_POST['memo_recepient'];
    $old_memo_file = $_POST['old_memo_file'];
    $new_memo_file= $_FILES['new_memo_file']['name'];
    $filesize = $_FILES['new_memo_file']['size'];

    if($new_memo_file != ''){
        $update_file = $_FILES['new_memo_file']['name'];
    }else{
        $update_file = $old_memo_file;
    }

    $allowed_ext = array('png','jpeg','pdf','docx','docs','jpg','svg');
    $filename = $update_file;
    $file_ext = pathinfo($filename, PATHINFO_EXTENSION);
    $location = "../upload/".$update_file;
    
    if(!in_array($file_ext,$allowed_ext)){
        $_SESSION['upmemostatus']="Invalid file extension!";
        header('Location:../memorandum/update_memo.php?id='.$id);
       
    }elseif($_FILES['memo_file']['size']>100000){
        $_SESSION['memostatus']="File too large!";
        header('Location:../memorandum/form_memo.php');
    }else{

        if(file_exists("../upload/".$_FILES['new_memo_file']['name'])){
        $location = "../upload/".$old_memo_file;
        $query = "UPDATE memorandum SET id='$id', memo_name = '$memo_name', memo_date = '$memo_date', memo_sender = '$memo_sender', memo_recipient = '$memo_recipient',
        memo_file = '$old_memo_file', location = '$location' WHERE id = '$id'";
        $query_run = mysqli_query($conn,$query);
    
        if($query_run){
            
           $_SESSION['memostatus']="Record updated successfully!";
            header('Location:../memorandum/display_memo.php');
            //echo "new file";
        }else{
            $_SESSION['memostatus']="Record failed to update!";
            header('Location:../memorandum/display_memo.php');
        }
        
        
        }else{
        
        $query = "UPDATE memorandum SET id='$id', memo_name = '$memo_name', memo_date = '$memo_date', memo_sender = '$memo_sender', memo_recipient = '$memo_recipient',
        memo_file = '$update_file', location = '$location' WHERE id = '$id'";
        $query_run = mysqli_query($conn,$query);
        
        if($query_run){
            if($_FILES['new_memo_file']['name'] !=''){
                move_uploaded_file($_FILES["new_memo_file"]["tmp_name"],
                "../upload/".$_FILES["new_memo_file"]["name"]);
                unlink("../upload/".$old_memo_file);
            }
           $_SESSION['memostatus']="Record updated successfully!";
           header('Location:../memorandum/display_memo.php');
        }else{
            $_SESSION['memostatus']="Record failed to update!";
            header('Location:../memorandum/display_memo.php');
        }
      
    }
  
}
}

?>




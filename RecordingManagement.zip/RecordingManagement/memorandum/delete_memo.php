<?php
session_start();
include_once '../database/database.php';
if($_GET['id']) {
  $id = $_GET['id'];
      
  $sql = "SELECT * FROM memorandum WHERE id = $id";
  $result = mysqli_query($conn,$sql);
  $row = mysqli_fetch_assoc($result);
  $file_name = $row['location'];
  $trim_path = trim($file_name);
  if(file_exists($trim_path))
    unlink($trim_path);
    $sql = "delete from `memorandum` where id=$id";
    $result = mysqli_query($conn,$sql);
    if($result){
      $_SESSION['memostatus']="Record deleted successfully!";
      header('Location:../memorandum/display_memo.php');
    }else{
        die(myqli_error($conn));
        header('Location:../memorandum/display_memo.php');
    }

 } else {
   $id=NULL;
 }

 

?>


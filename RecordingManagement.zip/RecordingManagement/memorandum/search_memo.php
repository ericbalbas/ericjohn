<?php
include '../database/database.php';


if(isset($_POST['query'])){
    $search = mysqli_real_escape_string($conn, $_POST["query"]);
    $query = "SELECT * from memorandum where memo_name LIKE '%".$search."%'
    OR memo_date LIKE '%".$search."%' OR memo_sender LIKE '%".$search."%' 
    OR memo_recipient LIKE '%".$search."%' OR memo_file LIKE '%".$search."%'";
}else{
    $query = "select * from memorandum";
}
$result = mysqli_query($conn, $query);

if(mysqli_num_rows($result)>0){ 
    ?>
    <style>
        .scrollable{
            height: 600px;
            overflow: auto;
        }
        .scrollable::-webkit-scrollbar {
                        display: none;
                        }
       
    </style>
    <div class="scrollable bg-light rounded">
    <table class="table bg-white rounded shadow-sm  table-hover table-fixed py-3 px-3">
            <thead  style="background:#7dd07d">
                <tr class=" text-light">
                    <th></th>
                    <th>Name</th>
                    <th>Memo/Letter</th>
                    <th>From</th>
                    <th>To</th>
                    <th>Date Recieved</th>
                    <th class="text-center">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $i = 1;
                    while($row = mysqli_fetch_assoc($result)){
                       
                        $id = $row['id'];
                        $memo_name = $row['memo_name'];
                        $memo_file = $row['memo_file'];
                        $memo_sender = $row['memo_sender'];
                        $memo_recipient = $row['memo_recipient'];
                        $memo_date = $row['memo_date']; 
                      
                ?>
                    <tr>
                        
                        <td><?php echo $i;$i++; ?></td>
                        <td><?php echo $memo_name; ?></td>
                        <td><?php echo $memo_file; ?></td>
                        <td><?php echo $memo_sender;?></td>
                        <td><?php echo $memo_recipient; ?></td>
                        <td><?php echo $memo_date; ?></td>
                        <td class="text-center">
                                        <button class="btn btn-success btn-sm rounded-pill">
                                        <a href="../upload/<?php echo $row['memo_file'] ?>" target="_blank"
                                        class="text-light text-decoration-none"><i class="fa fa-eye"></i></a>
                                        </button>
                                        <button class="btn btn-primary btn-sm rounded-pill "> 
                                            <a href="update_memo.php?id=<?php echo $row['id'];?>"
                                        class="text-light text-decoration-none"><i class="fa fa-edit"></i></a>
                                        </button>
                                        <button class="btn btn-danger btn-sm rounded-pill del_btn"></i>
                                        <a onclick='javascript:confirmationDelete($(this));return false;' href='delete_memo.php?id=<?php echo $id ?>'
                                        class="delete_btn text-light text-decoration-none"><i class="fa fa-trash"></i></a>
                                    </button>
                                    </td>             
                    </tr>
                <?php
                    }
                ?>
            </tbody>
        </table>
                 <script>
                    function confirmationDelete(anchor){
                        var conf = confirm('Are you sure want to delete this record?');
                        if(conf)
                            window.location=anchor.attr("href");
                    }
                </script>       
        </div>           
    <?php
   
    }
    else{
        echo "No data found!";
}
?>

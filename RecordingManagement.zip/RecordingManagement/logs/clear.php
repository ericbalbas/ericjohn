<?php
include '../database/database.php';
if(isset($_POST['clear_btn'])){
    $ids = $_POST['aics'];
    $pwds = $_POST['pwds'];
    $scs = $_POST['scs'];
    
    $sql = mysqli_query($conn,"DELETE FROM activity_logs WHERE s_id in ($ids)");
    $res = mysqli_query($conn,"DELETE FROM pwd_logs WHERE id in ($pwds)");
    $ress = mysqli_query($conn,"DELETE FROM sc_logs WHERE id in ($scs)");
    if($sql && $res && $ress){
        echo "success";
    }else{
        echo "failed";
    }

    
  
    
 
}

?>
<?php
session_start();
function validate($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
include '../../database/database.php';


if(isset($_POST['delete_btn'])) {
    $s_id = $_POST['s_id'];
    $sql = "Select * from `login2` where id = $s_id ";

    $result1=mysqli_query($conn,$sql);
    $row1 = mysqli_fetch_assoc($result1);

    $id = $_POST['id'];
    $con = $_POST['con'];
    if($row1['password'] == $con){

        $sql = "Select * from `seniorprofile` where id=$id";
        $result=mysqli_query($conn,$sql);
        $row = mysqli_fetch_assoc($result);
        $familyname=validate($row['familyname']);
        $givenname=validate($row['givenname']);
        $middlename=validate($row['middlename']);

        $sql = "delete from `seniorprofile` where id=$id";
        $result = mysqli_query($conn,$sql);

        if($result){
            date_default_timezone_set('Asia/Manila');
            $user = "SENIOR user";
            $action = "DELETE";
            $data= $givenname.' '.$middlename.' '.$familyname;// query for inser user log in to data base
            $date = date('m/d/Y h:i:s a', time());
            mysqli_query($conn,"insert into sc_logs(session,date,data,user) values('$action','$date','$data','$user')");
            $_SESSION['statusss']="Record deleted successfully!";
            header('Location:../../user2/record/us-sc-display.php');
            echo $_SESSION['password'];
        }else{
            
            $_SESSION['statussc']="Record failed to delete!";
            header('Location:../../user2/record/us-sc-display.php');
            die(myqli_error($conn));
        }
    }else{
        $_SESSION['statussc']="Record failed to delete invalid password!";
        header('Location:../../user2/record/us-sc-display.php');
    }
    
}

?>
<?php
include '../../database/database.php';
$id = $_GET['id'];
?>
<?php
session_start();
if(isset($_SESSION['username']) && isset($_SESSION['id'])){
$s_id = $_SESSION['id'];

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
    <link rel="stylesheet" href="../../aics/css/scstyle.css" />
    <link rel="stylesheet" type="text/css" href="../../aics/css/print2.css" media="print">
    <title>SC view</title>
</head>

<div class="d-flex" id="wrapper">
           <!-- Sidebar -->
           <div style="background:#231f20" id="sidebar-wrapper">
         
        <div class="sidebar-heading text-center py-4 text-success fs-4 fw-bold text-uppercase "><i
                    class="	fas fa-campground me-2"></i>e-rms</div>
            <div class="list-group list-group-flush my-3">
                <a href="../../user2/scdashboard.php" class="list-group-item list-group-item-action text-uppercase bg-transparent text-light fw-bold "><i
                        class="fas fa-tachometer-alt text-uppercase me-2"></i>Dashboard</a>
                <a href="../../report/us-senior-report.php" class="list-group-item list-group-item-action bg-transparent text-light  fw-bold"><i
                        class="	fas fa-chart-bar "></i> REPORT</a>       
           
                <a href="../../user2/record/us-sc-display.php" class="list-group-item list-group-item-action bg-transparent text-light  fw-bold"><i
                        class="fa fa-edit "></i> MANAGE RECORD</a> 
                        <a href="../../user2/record/senior_logs.php" class="list-group-item list-group-item-action text-light bg-transparent text-light  fw-bold"><i
                        class="fa fa-tasks "></i> LOGS</a>  
                        <a href="#" data-toggle="modal" data-target="#changeModal" class="list-group-item list-group-item-action bg-transparent text-light text-light fw-bold"><i
                    class="fa fa-cog me-2"></i>SETTING</a> 
                    <!-- Modal -->
                    <div class="modal fade" id="changeModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                        <style>
                                .form-control{
                                    border-top: 0;
                                    border-left: 0;
                                    border-right: 0;
   
                                }
                                .form-select{
                                    border-top: 0;
                                    border-left: 0;
                                    border-right: 0;
                                }
                                .form-select:focus{
                                    border-top: 0;
                                    border-left: 0;
                                    border-right: 0;
                                }
                                .form-control:focus{  
                                    box-shadow: none;
                                  
                                }
                            </style>
                        <div class="modal-header" style="background:#FFC602">
                            <h5 class="modal-title fw-bold" id="exampleModalLabel"><i  class="fa fa-cog me-2"></i>CHANGE PASSWORD</h5>
                            <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                        <form action="../login/changepass.php" method="POST" autocomplete="off">
                        <div class="row">
                            <div class="col">
                                <label for="">Current Password</label>
                                    <input type="text" name="current" class="form-control" placeholder="Current Password">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col">
                                <label for="">New Password</label>
                                    <input type="Password" name="new" class="form-control" placeholder="New Password">
                                </div>
                        </div>
                        <div class="row">
                            <div class="col">
                                <label for="">Confirm Password</label>
                                    <input type="password" name="confirm" class="form-control" placeholder="Confirm Password">
                            </div>
                        </div>
                            
                        
                        </div>
                        <div class="modal-footer">
                             <button type="submit" class="btn fw-bold text-light text-uppercase " name="change_btn" style="background:#FFC602">Change Password</button>          
                        </form>
                              
                           
                        </div>
                        </div>
                    </div>
                    </div> 
                <a href="#" data-toggle="modal" data-target="#logoutModal" class="list-group-item text-uppercase list-group-item-action bg-transparent text-light text-light fw-bold"><i
                        class="fas fa-power-off text-uppercase me-2"></i>Logout</a>      
                  <!-- Button trigger modal -->
                 
                    <!-- Modal -->
                    <div class="modal fade" id="logoutModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Warning</h5>
                            <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            Ready to leave the site?
                        </div>
                        <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                           <form action="../../login/logout.php" method="POST">
                               <button type="submit" name="logout_btn" class="btn btn-primary">logout</button>
                           </form>
                        </div>
                        </div>
                    </div>
                    </div>
            </div>
        </div>
        <!-- /#sidebar-wrapper -->

        <!-- Page Content -->
        <div id="page-content-wrapper" style="background:#E0E0E0">
        
        <div class="d-flex px-3">
            <div class="flex-grow-1 ">
                <nav class="navbar navbar-expand navbar-light bg-transparent text-light">
                    <div class="d-flex align-items-center">
                        <i class="fas fa-align-left text-dark fs-4 me-3" id="menu-toggle"></i>
                        <h2 class="fs-3 m-0 fw-bold text-dark text-uppercase border-bottom">SENIOR</h2>
                    </div>      
                </nav>
            </div>
            <div class="pt-2">
                <div class="dropdown show">
                    <a class="btn btn-secondary bg-transparent dropdown-toggle border-0 text-dark" href="#" role="button" id="btn_print" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i class="fa fa-cog me-2"></i> Action
                    </a>

                    <div class="dropdown-menu" aria-labelledby="btn_print">
                        <a href="us-sc-update.php?id=<?php echo $id?>"
                            class="text-dark text-decoration-none dropdown-item  text-uppercase fw-bold " id="btn_print"><i class="fa fa-edit"></i> Update</a>
                            <a href="#" data-toggle="modal" data-target="#deleteModal" class=" dropdown-item text-uppercase fw-bold " id="btn_print"><i class="fa fa-trash"></i> delete</a>    
                            <button onclick="window.print();" class="btn bg-transparent text-uppercase fw-bold dropdown-item " id="btn_print"><i class="fas fa-print"></i> print</button>                  
                        </div>
                        <div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Warning</h5>
                                <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                            <form action="../record/us-sc-delete.php" method="POST" >
                                Please enter password to delete.
                                <input type="hidden" class="form-control" name="id" value="<?php echo $id ?>">
                                <input type="hidden" class="form-control" name="s_id" value="<?php echo $s_id ?>">
                                <input type="password" class="form-control" name="con" placeholder="Password" required>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                <button type="submit" name="delete_btn" class="btn btn-primary">delete</button>
                            </form>
                            </div>
                            </div>
                        </div>
                        </div>
                </div>
            </div>
        </div>


            <div class="container-fluid px-3" >
                <?php
                  
                        $query="SELECT * FROM seniorprofile WHERE id = '$id'";
                        $query_run=mysqli_query($conn,$query);
                        if(mysqli_num_rows($query_run)>0){
                        foreach($query_run as $row){
                        ?>
                  <form action="sc-insert.php" method="POST" class="bg-light px-2 rounded" >
                            <style>
                                #img {
                                            width: 90px;
                                            
                                        }
                            </style>
                         <div class="d-flex align-items-center pt-2">
                            <img src="../../asset/aics.png" class="me-4 mt-2 " id="img" alt="">  
                            <label for="" class="fw-bold">Republic of the Philippine<br>Province of La Union<br>
                            Municipality of Tubao <br>Municipal Social Welfare and Development<br>
                            </label><br> 
                           
                        </div>
                    <div class="text-center">
                         <label class="text-center my-3"><h3>APPLICATION FORM</h3></label>
                    </div>
                    
                    <div class="row">
                        
                    <div class="col-auto">
                            <div class="form-group">
                                <label for="">Id number</label>
                                <input type="text" class="form-control"  value="<?php echo $row['idnum']; ?>" name="idnum" placeholder="Id number" readonly> 
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <style>
                            .form-control{
                                border-top: 0;
                                border-left: 0;
                                border-right: 0;
                               
                            }
                            label{
                                font-weight: bold;
                            }
                            .form-control:focus{  
                                box-shadow: none;
                            }
                            
                        </style>
                        
                      
                        <div class="col">
                            <div class="form-group">
                                <label for="">Family name</label>
                                <input type="text" class="form-control" name="familyname" placeholder="Family name" value="<?php echo $row['familyname']; ?>" readonly/>
                            </div>
                        </div>
                        <div class="col">
                            <div class="form-group">
                                <label for="">Given name</label>    
                                <input type="text" class="form-control" name="givenname" placeholder="Given name" value="<?php echo $row['givenname']; ?>" readonly>
                            </div>
                        </div>
                        <div class="col">
                            <div class="form-group">
                                 <label for="">Middle name</label>
                                <input type="text" class="form-control" name="middlename" placeholder="Middle name" value="<?php echo $row['middlename']; ?>" readonly>
                            </div>
                        </div>
                        
                    </div>
                    <div class="row">
                         <div class="col-sm-5">
                         <div class="form-group">
                                <label for="">Address</label>
                                <input type="text" class="form-control" name="address" placeholder="Address" value="<?php echo $row['address']; ?>" readonly>
                            </div>
                         </div>
                         <div class="col">
                         <div class="form-group">
                                <label for="">Age</label>   
                                <input type="text" class="form-control" name="age" placeholder="Age" value="<?php echo $row['age']; ?>" readonly>
                            </div>
                         </div>
                         <div class="col">
                         <div class="form-group">
                                <label for="">Sex</label>
                                <input type="text" class="form-control" name="sex" placeholder="Sex" value="<?php echo $row['sex']; ?>" readonly>
                            </div>
                         </div>
                         <div class="col">
                         <div class="form-group">
                                <label for="">Place of birth</label>
                                <input type="text" class="form-control" name="placeofbirth" placeholder="Place of birth" value="<?php echo $row['placeofbirth']; ?>" readonly>
                            </div>
                         </div>
                    </div>
                    <div class="row">
                         <div class="col">
                            <div class="form-group">
                                    <label for="">Civil Status</label>
                                    <input type="text" class="form-control" name="civil" placeholder="Civil Status" value="<?php echo $row['civil']; ?>" readonly>
                            </div>
                         </div>
                         <div class="col">
                            <div class="form-group">
                                    <label for="">Educational Attainment</label>
                                    <input type="text" class="form-control" name="educational" placeholder="Educational Attainment" value="<?php echo $row['educational']; ?>" readonly>
                            </div>
                         </div>
                         <div class="col">
                            <div class="form-group">
                                    <label for="">Skills</label>
                                    <input type="text" class="form-control" name="skill" placeholder="Skills" value="<?php echo $row['skill']; ?>" readonly>
                            </div>
                         </div>
                         <div class="col">
                            <div class="form-group">
                                    <label for="">Occupation</label>
                                    <input type="text" class="form-control" name="occupation" placeholder="Occupation" value="<?php echo $row['occupation']; ?>" readonly>
                            </div>
                         </div>
                    </div>
                    <div class="row">
                        <div class="col-auto">
                            <div class="form-group">
                                    <label for="">Month Salary</label>
                                    <input type="text" class="form-control" name="salary" placeholder="Month Salary" value="<?php echo $row['salary']; ?>" readonly>
                            </div>
                        </div>
                        <div class="col-auto">
                            <div class="form-group">
                                    <label for="">Number of dependents</label>
                                    <input type="text" class="form-control" name="dependents" placeholder="Number of Dependents" value="<?php echo $row['dependent']; ?>" readonly>
                            </div>
                        </div>
                        <div class="col-auto">
                            <div class="form-group">
                                    <label for="">Incase of emergency/accidents/please contact.</label>
                                    <input type="text" class="form-control" name="incase" placeholder="Incase of emergency/accidents/please contact." value="<?php echo $row['incase']; ?>" readonly>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col">
                            <div class="form-group">
                                    <label for="">Address</label>
                                    <input type="text" class="form-control" name="address2" placeholder="Address" value="<?php echo $row['address2']; ?>" readonly>
                            </div>
                        </div>
                        <div class="col-auto">
                            <div class="form-group">
                                    <label for="">Contact no.</label>
                                    <input type="text" class="form-control" name="contact" placeholder="Contact no." value="<?php echo $row['contact']; ?>" readonly>
                            </div>
                        </div>
                        <div class="col-auto">
                            <div class="form-group">
                                    <label for="">Relationship</label>
                                    <input type="text" class="form-control mb-5" name="relationship" placeholder="Relationship" value="<?php echo $row['relationship']; ?>" readonly>
                            </div>
                        </div>
                    </div>
                            
                   
                </form>
                <?php
                        }
                    }
             ?>
            </div>
            
     </div>
     <!-- /#page-content-wrapper -->
    </div>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>

    <script>
        var el = document.getElementById("wrapper");
        var toggleButton = document.getElementById("menu-toggle");

        toggleButton.onclick = function () {
            el.classList.toggle("toggled");
        };
    </script>
</body>




</html>
<?php
}else{  
    header("location:../login/LoginForm.php");     
}
?>
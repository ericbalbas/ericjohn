<?php
session_start();
include '../database/database.php';
$sql = "Select * from `login2`";
$result1=mysqli_query($conn,$sql);
$row1 = mysqli_fetch_assoc($result1);

function validate($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
if(isset($_POST['delete_btn'])) {

    $id = $_POST['id'];
    $con = $_POST['con'];
   
    $sql = "Select * from `seniorprofile` where id=$id";
    $result=mysqli_query($conn,$sql);
    $row = mysqli_fetch_assoc($result);

    if($row1['password'] == $con){
        $familyname = validate($row['familyname']);
        $givenname = validate($row['givenname']);
        $middlename = validate($row['middlename']);

        $sql = "delete from `seniorprofile` where id=$id";
        $result = mysqli_query($conn,$sql);

    
        if($result){

            date_default_timezone_set('Asia/Manila');
            $user = "admin";
            $action = "delete";
            $data= $givenname.' '.$familyname.' '.$middlename;// query for inser user log in to data base
            $date = date('m/d/Y h:i:s a', time());
            mysqli_query($conn,"insert into sc_logs(session,date,data,user) values('$action','$date','$data','$user')");
            $_SESSION['senstatus']="Record deleted successfully!";
            header('location:../seniorcitizen/sc-display.php');
        }else{
            die(myqli_error($conn));
            $_SESSION['senstatus']="Record failed to delete there's something on your internet!";
            header('location:../seniorcitizen/sc-display.php');
        }
    }else{
        $_SESSION['senstatus']="Record failed to delete invalid password!";
        header('location:../seniorcitizen/sc-display.php');
    }
}

?>
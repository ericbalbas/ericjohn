<?php
session_start();
include_once '../database/database.php';
function validate($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
$id = $_GET['id'];

$sql = "Select * from `seniorprofile` where id=$id";
$result=mysqli_query($conn,$sql);
$row = mysqli_fetch_assoc($result);

$familyname = validate($row['familyname']);
$givenname = validate($row['givenname']);
$middlename = validate($row['middlename']);
$address = validate($row['address']);
$age = validate($row['age']);
$sex = validate($row['sex']);
$placeofbirth = validate($row['placeofbirth']);
$civil = validate($row['civil']);
$educational = validate($row['educational']);
$skill = validate($row['skill']);
$occupation = validate($row['occupation']);
$salary = validate($row['salary']);
$dependents = validate($row['dependent']);
$incase = validate($row['incase']);
$address2 = validate($row['address2']);
$contact = validate($row['contact']);
$relationship = validate($row['relationship']);
$idnum = validate($row['idnum']);

if(isset($_POST['update'])){
   $idnum = validate(mysqli_real_escape_string($conn,$_POST['idnum']));  
    $familyname = validate(mysqli_real_escape_string($conn,$_POST['familyname']));
    $givenname = validate(mysqli_real_escape_string($conn,$_POST['givenname']));
    $middlename = validate(mysqli_real_escape_string($conn,$_POST['middlename']));
    $address = validate(mysqli_real_escape_string($conn,$_POST['address']));
    $age = validate(mysqli_real_escape_string($conn,$_POST['age']));
    $sex = validate(mysqli_real_escape_string($conn,$_POST['sex']));
    $placeofbirth = validate(mysqli_real_escape_string($conn,$_POST['placeofbirth']));
    $civil = validate(mysqli_real_escape_string($conn,$_POST['civil']));
    $educational = validate(mysqli_real_escape_string($conn,$_POST['educational']));
    $skill = validate(mysqli_real_escape_string($conn,$_POST['skill']));
    $occupation = validate(mysqli_real_escape_string($conn,$_POST['occupation']));
    $salary = validate(mysqli_real_escape_string($conn,$_POST['salary']));
    $dependents = validate(mysqli_real_escape_string($conn,$_POST['dependents']));
    $incase = validate(mysqli_real_escape_string($conn,$_POST['incase']));
    $address2 = validate(mysqli_real_escape_string($conn,$_POST['address2']));
    $contact = validate(mysqli_real_escape_string($conn,$_POST['contact']));
    $relationship = validate(mysqli_real_escape_string($conn,$_POST['relationship']));

    $sql="update `seniorprofile` set id=$id, familyname='$familyname', givenname='$givenname', middlename='$middlename',
    address='$address', age='$age', sex='$sex', placeofbirth='$placeofbirth', civil='$civil', educational='$educational', skill='$skill',
    occupation='$occupation', salary='$salary', dependent='$dependents', incase='$incase', address2='$address2', contact='$contact', relationship='$relationship',idnum='$idnum' 
    where id=$id";
    
    if(mysqli_query($conn, $sql)){
        $user = "ADMIN";
        $action = "UPDATE";
        $data= $givenname.' '.$familyname.' '.$middlename;// query for inser user log in to data base
        $date = date('m/d/Y h:i:s a', time());
        mysqli_query($conn,"insert into sc_logs(session,date,data,user) values('$action','$date','$data','$user')");
        $_SESSION['senstatus']="Record updated successfully!";
        header('location:../seniorcitizen/sc-display.php');
    }else{
        $_SESSION['senstatus']="Record failed to update!";
        header('location:../seniorcitizen/sc-display.php');
    }
    mysqli_close($conn);
}


?>
<?php

if(isset($_SESSION['username']) && isset($_SESSION['id'])){

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
    <link rel="stylesheet" href="../aics/css/aicsstyle.css"" />
    <title>Admin-SC update</title>
</head>

<div class="d-flex" id="wrapper">
         <!-- Sidebar -->
         <div style="background:#232B2B"  id="sidebar-wrapper">
        <div class="sidebar-heading text-center py-4 text-success fs-4 fw-bold text-uppercase "><i
                    class="	fas fa-campground me-2"></i>e-rms</div>
            <div class="list-group list-group-flush my-3">
                <a href="../aics/admindashboard.php" class="list-group-item list-group-item-action bg-transparent text-light fw-bold "><i
                        class="fas fa-tachometer-alt me-2"></i>Dashboard</a>
                <a class="list-group-item list-group-item-action bg-transparent text-light  fw-bold" 
                data-toggle="collapse" href="#collapse1">Reports</a>
                <div id="collapse1" class="list-group list-group-flush my-3 collapse">
                <a href="../report/senior-report.php" class="list-group-item list-group-item-action bg-transparent text-light  fw-bold"><i
                        class="fas fa-assistive-listening-systems ms-3"></i> Senior Citizen</a>
                
                <a href="../report/aics-report.php" class="list-group-item list-group-item-action bg-transparent text-light  fw-bold"><i
                        class="	fas fa-money-check-alt ms-3"></i> AICS</a>
                <a href="../report/pwd-report.php" class="list-group-item list-group-item-action bg-transparent text-light  fw-bold"><i
                class="	fas fa-heartbeat ms-3"></i> PWD</a>    
                </div>
              
                <a class="list-group-item list-group-item-action bg-transparent text-light fw-bold" 
                data-toggle="collapse" href="#collapse2">Manage Records</a>
                <div id="collapse2" class="list-group list-group-flush my-3 collapse">
                <a href="../seniorcitizen/sc-display.php" class="list-group-item list-group-item-action bg-transparent text-light fw-bold"><i
                        class="fas fa-assistive-listening-systems ms-3"></i> Senior Citizen</a>
                
                <a href="../aics/aicsdisplay.php" class="list-group-item list-group-item-action bg-transparent text-light  fw-bold"><i
                        class="fas fa-money-check-alt ms-3"></i> AICS</a>  
                <a href="../pwd/pwd-display.php" class="list-group-item list-group-item-action bg-transparent text-light  fw-bold"><i
                        class="fas fa-heartbeat ms-3"></i> PWD</a>
                </div>
                <a class="list-group-item list-group-item-action bg-transparent text-light fw-bold" 
                data-toggle="collapse" href="#collapse3">Memorandum</a>
                <div id="collapse3" class="list-group list-group-flush my-3 collapse">
              
                <a href="../memorandum/display_memo.php" class="list-group-item list-group-item-action bg-transparent text-light  fw-bold"><i
                        class="	fas fa-file-signature ms-3"></i> Manage</a>
        
                </div>
    
                <a class="list-group-item list-group-item-action text-light bg-transparent fw-bold" 
                data-toggle="collapse" href="#collapse4">Settings</a>
                <div id="collapse4" class="list-group list-group-flush my-3 collapse">
                <a href="#" data-toggle="modal" data-target="#changeModal" class="list-group-item text-light list-group-item-action bg-transparent text-light fw-bold"><i
                    class="fa fa-cog me-2"></i> Change password</a> 
                    <a href="#" data-toggle="modal" data-target="#addModal" class="list-group-item text-light list-group-item-action bg-transparent text-light fw-bold"><i
                    class="fa fa-plus me-2"></i> Add user</a> 
                    <a href="../logs/admin_logs.php" class="list-group-item list-group-item-action text-light bg-transparent  fw-bold"><i
                        class="fas fa-tasks me-2"></i> Logs</a>
                        <a href="../backup/export.php" class="list-group-item list-group-item-action text-light bg-transparent  fw-bold"><i class="fa fa-archive" aria-hidden="true"></i>
                     Back up</a> 
                        </div>
                 <!-- Button trigger modal -->
                 
                    <!-- Modal -->
                    <div class="modal fade" id="changeModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                        <div class="modal-header text-center" style="background:#7dd07d">
                            <h5 class="modal-title fw-bold text-light " id="exampleModalLabel" ><i class="fa fa-cog me-2"></i>CHANGE PASSWORD</h5>
                            <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <style>
                                .form-control{
                                    border-top: 0;
                                    border-left: 0;
                                    border-right: 0;
   
                                }
                                .form-select{
                                    border-top: 0;
                                    border-left: 0;
                                    border-right: 0;
                                }
                                .form-select:focus{
                                    border-top: 0;
                                    border-left: 0;
                                    border-right: 0;
                                }
                                .form-control:focus{  
                                    box-shadow: none;
                                  
                                }
                            </style>
                        <form action="../login/changepass.php" method="POST" class="" autocomplete="off">
                        <div class="row">
                            <div class="col">
                                <label for="">Current Password</label>
                                    <input type="text" name="current" class="form-control" placeholder="Current Password" required>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col">
                                <label for="">New Password</label>
                                    <input type="Password" name="new" class="form-control" placeholder="New Password" required>
                                </div>
                        </div>
                        <div class="row">
                            <div class="col">
                                <label for="">Confirm Password</label>
                                    <input type="password" name="confirm" class="form-control" placeholder="Confirm Password" required>
                            </div>
                        </div>
                            
                        
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn fw-bold text-light text-uppercase mt-2" name="change_btn" style="background:#7dd07d">Change password</button>          
                         </form>
                              
                           
                        </div>
                        </div>
                    </div>
                    </div>    

                      <!-- Modal -->
                      <div class="modal fade" id="addModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                        <div class="modal-header" style="background:#7dd07d">
                            <h5 class="modal-title fw-bold text-light" id="exampleModalLabel"><i class="fa fa-cog me-2"></i>ADD USER</h5>
                            <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                        <!-- STATUS -->
                       
                    <!-- STATUS -->
                        
                        <form action="../login/add-user.php" method="POST" class="">
                        <div class="row">
                            <div class="col">
                                <label for="">Username</label>
                                <select class="form-select" name="add_username" required>
                                  <option value="" disable selected hidden>user</option>
                                  <option value="admin">admin</option>
                                  <option value="pwd">pwd</option>   
                                  <option value="senior">senior</option>
                                  <option value="aics">aics</option>     
                                </select>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col">
                                <label for="">Role</label>
                                <select class="form-select" name="add_role" required>
                                  <option value="" disable selected hidden>role</option>
                                  <option value="admin">admin</option>
                                  <option value="user">user</option>   
                                </select>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col">
                                <label for="">Password</label>
                                    <input type="Password" name="add_pass" class="form-control" placeholder="New Password" required>
                                </div>
                        </div>
                        <div class="row">
                            <div class="col">
                                <label for="">Confirm Password</label>
                                    <input type="password" name="add_confirm" class="form-control" placeholder="Confirm Password" required>
                            </div>
                        </div>
                           
                        
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn fw-bold text-light text-uppercase" name="add_btn" style="background:#7dd07d">Add user</button>          
                            </form>
                              
                           
                        </div>
                        </div>
                    </div>
                    </div>    
                <a href="#" data-toggle="modal" data-target="#logoutModal" class="list-group-item list-group-item-action bg-transparent text-light text-danger fw-bold"><i
                        class="fas fa-power-off me-2"></i>Logout</a>
                <!-- Button trigger modal -->
                 
                    <!-- Modal -->
                    <div class="modal fade" id="logoutModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Warning</h5>
                            <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            Ready to leave the site?
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                           <form action="../login/logout.php" method="POST">
                               <button type="submit" name="logout_btn" class="btn btn-primary">logout</button>
                           </form>
                        </div>
                        </div>
                    </div>
                    </div>
            </div>
        </div>
        <!-- /#sidebar-wrapper -->


        <!-- Page Content -->
        <div id="page-content-wrapper" style="background:#E0E0E0">
        
            <nav class="navbar navbar-expand-lg navbar-light bg-transparent text-light py-2 px-4">
                <div class="d-flex align-items-center">
                    <i class="fas fa-align-left text-dark fs-4 me-3" id="menu-toggle"></i>
                    <h2 class="fs-3 m-0 fw-bold text-uppercase text-dark border-bottom">Senior Citizen</h2>
                
                </div>
            
            </nav>


            <div class="container-fluid px-3">
                <form action="" method="POST" id="form" class="bg-light px-2" >
                    <div class="text-center">
                         <label class="text-center my-3"><h3>APPLICATION FORM</h3></label>
                    </div>
                 
                    <div class="row">
                    <style>
                           .form-control{
                                border-top: 0;
                                border-left: 0;
                                border-right: 0;
                            }
                            .form-control:focus{  
                                box-shadow: none;
                            }
                           label{  
                                font-weight: bold;
                            }
                            .form-select{
                                border-top: 0;
                                border-left: 0;
                                border-right: 0;
                            }
                            .form-select:focus{  
                                box-shadow: none;
                            }
                            
                        </style>
                        <div class="col-sm-2">
                            <div class="form-group">
                                <label for="">Id number</label>
                                <input type="text" class="form-control"  value="<?php echo $row['idnum']; ?>" name="idnum" placeholder="Id number">
                            </div>
                        </div>
                        <div class="col">
                            <div class="form-group">
                                <label for="">Family name</label>
                                <input type="text" class="form-control" name="familyname" value="<?php echo $row['familyname']; ?>" placeholder="Family name">
                            </div>
                        </div>
                        <div class="col">
                            <div class="form-group">
                                <label for="">Given name</label>    
                                <input type="text" class="form-control" name="givenname" value="<?php echo $row['givenname']; ?>" placeholder="Given name">
                            </div>
                        </div>
                        <div class="col">
                            <div class="form-group">
                                 <label for="">Middle name</label>
                                <input type="text" class="form-control" name="middlename" value="<?php echo $row['middlename']; ?>" placeholder="Middle name">
                            </div>
                        </div>
                        
                    </div>
                    <div class="row g-4">
                         <div class="col-sm-5">
                         <div class="form-group">
                         <label class="form-label" for="">Address</label>
                          <select class="form-select" id="address" name="address">
                              <option selected hidden><?php echo $row['address']; ?></option>
                              <option value="Amallapay, Tubao, La Union">Amallapay, Tubao, La Union</option>
                              <option value="Anduyan, Tubao, La Union">Anduyan, Tubao, La Union</option>
                              <option value="Caoigue, Tubao, La Union">Caoigue, Tubao, La Union</option>
                              <option value="Francia Sur, Tubao, La Union">Francia Sur, Tubao, La Union</option>
                              <option value="Francia West, Tubao, La Union">Francia West,Tubao, La Union</option>
                              <option value="Gonzales, Tubao, La Union">Gonzales, Tubao,  La Union</option>
                              <option value="Garcia, Tubao, La Union">Gonzales, Tubao, La Union</option>
                              <option value="Halog East, Tubao, La Union">Halog East, Tubao, La Union</option>
                              <option value="Halog West, Tubao, La Union">Halog West, Tubao, La Union</option>
                              <option value="Leones East, Tubao, La Union">Leones East, Tubao, La Union</option>
                              <option value="Leones West, Tubao, La Union">Leones West, Tubao, La Union</option>
                              <option value="Linapew, Tubao, La Union">Linapew, Tubao, La Union</option>
                              <option value="Lloren, Tubao, La Union">Lloren, Tubao, La Union</option>
                              <option value="Magsaysay, Tubao, La Union">Magsaysay, Tubao, La Union</option>
                              <option value="Pideg, Tubao, La Union">Pideg, Tubao, La Union</option>
                              <option value="Poblacion, Tubao, La Union">Poblacion, Tubao, La Union</option>
                              <option value="Rizal, Tubao, La Union">Rizal, Tubao, La Union</option>
                              <option value="Santa Teresa, Tubao, La Union">Santa Teresa, Tubao, La Union</option>
                          </select>
                            </div>
                         </div>
                         <div class="col-sm-2">
                         <div class="form-group">
                                <label for="">Age</label>   
                                <input type="text" class="form-control" name="age" value="<?php echo $row['age']; ?>" placeholder="Age">
                            </div>
                         </div>
                         <div class="col-sm-2">
                        <label for="" class="fw-bold">GENDER</label>
                                <select class="form-select" name="sex">
                                  <option hidden><?php echo $row['sex']; ?></option>
                                  <option value="Female">Female</option>
                                  <option value="Male">Male</option>       
                                </select>
                        </div> 
                         <div class="col">
                         <div class="form-group">
                                <label for="">Place of birth</label>
                                <input type="text" class="form-control" name="placeofbirth" value="<?php echo $row['placeofbirth']; ?>" placeholder="Place of birth">
                            </div>
                         </div>
                    </div>
                    <div class="row">
                         <div class="col-sm-2">
                            <div class="form-group">
                                    <label for="">Civil Status</label>
                                    <input type="text" class="form-control" name="civil" value="<?php echo $row['civil']; ?>" placeholder="Civil Status">
                            </div>
                         </div>
                         <div class="col-sm-4">
                            <div class="form-group">
                                    <label for="">Educational Attainment</label>
                                    <input type="text" class="form-control" name="educational" value="<?php echo $row['educational']; ?>" placeholder="Educational Attainment">
                            </div>
                         </div>
                         <div class="col">
                            <div class="form-group">
                                    <label for="">Skills</label>
                                    <input type="text" class="form-control" name="skill" value="<?php echo $row['skill']; ?>" placeholder="Skills">
                            </div>
                         </div>
                         <div class="col">
                            <div class="form-group">
                                    <label for="">Occupation</label>
                                    <input type="text" class="form-control" name="occupation" value="<?php echo $row['occupation']; ?>" placeholder="Occupation">
                            </div>
                         </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-3">
                            <div class="form-group">
                                    <label for="">Month Salary</label>
                                    <input type="text" class="form-control" name="salary" value="<?php echo $row['salary']; ?>" placeholder="Month Salary">
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="form-group">
                                    <label for="">Number of dependents</label>
                                    <input type="text" class="form-control" name="dependents" value="<?php echo $row['dependent']; ?>" placeholder="Number of Dependents">
                            </div>
                        </div>
                        <div class="col">
                            <div class="form-group">
                                    <label for="">Incase of emergency/accidents/please contact.</label>
                                    <input type="text" class="form-control" name="incase" value="<?php echo $row['incase']; ?>" placeholder="Incase of emergency/accidents/please contact.">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col">
                            <div class="form-group">
                            <label class="form-label" for="">Address</label>
                          <select class="form-select" id="address2" name="address2">
                              <option selected hidden><?php echo $row['address2']; ?></option>
                              <option value="Amallapay, Tubao, La Union">Amallapay, Tubao, La Union</option>
                              <option value="Anduyan, Tubao, La Union">Anduyan, Tubao, La Union</option>
                              <option value="Caoigue, Tubao, La Union">Caoigue, Tubao, La Union</option>
                              <option value="Francia Sur, Tubao, La Union">Francia Sur, Tubao, La Union</option>
                              <option value="Francia West, Tubao, La Union">Francia West,Tubao, La Union</option>
                              <option value="Gonzales, Tubao, La Union">Gonzales, Tubao,  La Union</option>
                              <option value="Garcia, Tubao, La Union">Gonzales, Tubao, La Union</option>
                              <option value="Halog East, Tubao, La Union">Halog East, Tubao, La Union</option>
                              <option value="Halog West, Tubao, La Union">Halog West, Tubao, La Union</option>
                              <option value="Leones East, Tubao, La Union">Leones East, Tubao, La Union</option>
                              <option value="Leones West, Tubao, La Union">Leones West, Tubao, La Union</option>
                              <option value="Linapew, Tubao, La Union">Linapew, Tubao, La Union</option>
                              <option value="Lloren, Tubao, La Union">Lloren, Tubao, La Union</option>
                              <option value="Magsaysay, Tubao, La Union">Magsaysay, Tubao, La Union</option>
                              <option value="Pideg, Tubao, La Union">Pideg, Tubao, La Union</option>
                              <option value="Poblacion, Tubao, La Union">Poblacion, Tubao, La Union</option>
                              <option value="Rizal, Tubao, La Union">Rizal, Tubao, La Union</option>
                              <option value="Santa Teresa, Tubao, La Union">Santa Teresa, Tubao, La Union</option>
                          </select>
                            </div>
                        </div>
                        <div class="col-auto">
                            <div class="form-group">
                                    <label for="">Contact no.</label>
                                    <input type="text" class="form-control" name="contact" value="<?php echo $row['contact']; ?>" placeholder="Contact no.">
                            </div>
                        </div>
                        <div class="col-auto">
                            <div class="form-group">
                                    <label for="">Relationship</label>
                                    <input type="text" class="form-control" name="relationship" value="<?php echo $row['relationship']; ?>" placeholder="Relationship">
                            </div>
                        </div>
                    </div>
                    <div class="row my-4">
                        <div class="">
                        <button class="btn text-uppercase text-light fw-bold mb-3" type="submit" name="update"  style="background:#7dd07d">Update form</button>
                        </div>
                    </div>
                </form>

            </div>
            
     </div>
     <!-- /#page-content-wrapper -->
    </div>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>

    <script>
        var el = document.getElementById("wrapper");
        var toggleButton = document.getElementById("menu-toggle");

        toggleButton.onclick = function () {
            el.classList.toggle("toggled");
        };
    </script>
</body>
<style>
  .error {
    color: red;
  }
</style>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.1/jquery.validate.min.js"></script>
<script>
    jQuery.validator.addMethod("ageUp", function(value,element){
        return this.optional(element) || (parseInt(value)>59);

    },"*Age must be 60 and above*");
  $(document).ready(function () {
    $('#form').validate({


      rules: {
          //I
        idnum:{
          required: true,
          number:true
        },
        familyname: {
          required: true
        },
        middlename: {
          required: true
        },
        givenname: {
          required: true,
        
        },
        address: {
          required: true
        },
        sex: {
          required: true
        },
       
        age: {
          required: true,
          number: true,
          ageUp: true          
        },
    
        civil: {
         required: true
        },
        salary: {
        
          number: true
        },

        dependents: {
         number: true,
         rangelength: [11, 12]
        }
        
        
      },
      messages: {

        idnum:{
          required: '*enter id number*',
          number: '*number only*',
        },
        familyname: {
         required: '* Enter family name *'
        }
        ,
        middlename: {
          required:  '* Enter Middle name *'
        },
        givenname: {
          required:  '* Enter given name *'
        },
        address:{
          required: '* select address *'
        },
        sex:{   
          required: '* Select here*'
        },
        age:{
          required: '* Enter age *',
          number: '* number only*'
        },
      
        civil: {
          required: '* Enter civil status*'
        },
        salary: {
          number: '* number only*'
        },
        dependents: {
          number: '*number only*',
          rangelength: '*Number must contains 11 digits*'
          
        },
     

      },
      submitHandler: function (form) {
        form.submit();
      }
    });
  });
</script>




</html>
<?php
}else{  
    header("location:../login/LoginForm.php");     
}
?>
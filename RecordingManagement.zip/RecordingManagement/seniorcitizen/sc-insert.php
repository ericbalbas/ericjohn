<?php
session_start();
include_once '../database/database.php';
function validate($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

if(isset($_POST['submit'])){
    $idnum = validate(mysqli_real_escape_string($conn,$_POST['idnum']));
    $familyname = validate(mysqli_real_escape_string($conn,$_POST['familyname']));
    $givenname = validate(mysqli_real_escape_string($conn,$_POST['givenname']));  
    $middlename = validate(mysqli_real_escape_string($conn,$_POST['middlename']));
    $address = validate(mysqli_real_escape_string($conn,$_POST['address']));
    $age = validate(mysqli_real_escape_string($conn,$_POST['age']));
    $sex = validate(mysqli_real_escape_string($conn,$_POST['sex']));
    $placeofbirth = validate(mysqli_real_escape_string($conn,$_POST['placeofbirth']));
    $civil = validate(mysqli_real_escape_string($conn,$_POST['civil']));
    $educational = validate(mysqli_real_escape_string($conn,$_POST['educational']));
    $skill = validate(mysqli_real_escape_string($conn,$_POST['skill']));
    $occupation = validate(mysqli_real_escape_string($conn,$_POST['occupation']));
    $salary = validate(mysqli_real_escape_string($conn,$_POST['salary']));
    $incase = validate(mysqli_real_escape_string($conn,$_POST['incase']));
    $address2 = validate(mysqli_real_escape_string($conn,$_POST['address2']));
    $contact = validate(mysqli_real_escape_string($conn,$_POST['contact']));
    $dependents = validate(mysqli_real_escape_string($conn,$_POST['relationship']));

    $sql = "INSERT INTO seniorprofile(familyname,givenname,middlename,address,age,
    sex,placeofbirth,civil,educational,skill,occupation,salary,incase,
    address2,contact,relationship,idnum) 
    VALUES 
    ('$familyname','$givenname','$middlename','$address','$age','$sex',
    '$placeofbirth',' $civil','$educational','$skill',' $occupation','$salary','$incase',
    '$address2','$contact','$dependents','$idnum')";
    
    if(mysqli_query($conn, $sql)){
        date_default_timezone_set('Asia/Manila');
        $user = "ADMIN";
        $action = "INSERT";
        $data= $givenname.' '.$familyname.' '.$middlename;// query for inser user log in to data base
        $date = date('m/d/Y h:i:s a', time());
        mysqli_query($conn,"insert into sc_logs(session,date,data,user) values('$action','$date','$data','$user')");
        $_SESSION['senstatus']="Record inserted successfully!";
        header('location:../seniorcitizen/sc-display.php');
    }else{
        $_SESSION['senstatus']="Record failed to insert";
        header('location:../seniorcitizen/sc-form.php');
    }
    mysqli_close($conn);
}

?>

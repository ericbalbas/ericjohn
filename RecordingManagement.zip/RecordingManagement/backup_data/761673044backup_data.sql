DROP TABLE activity_logs;

CREATE TABLE `activity_logs` (
  `s_id` int(11) NOT NULL AUTO_INCREMENT,
  `session` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  `data` varchar(255) NOT NULL,
  `user` varchar(245) NOT NULL,
  PRIMARY KEY (`s_id`)
) ENGINE=InnoDB AUTO_INCREMENT=69 DEFAULT CHARSET=utf8mb4;

INSERT INTO activity_logs VALUES("64","UPDATE","05/17/2022 07:41:40 pm","Yen111111 Corativu Serrana","ADMIN");
INSERT INTO activity_logs VALUES("65","INSERT","05/17/2022 10:11:54 pm","Henry Misa Hisume","ADMIN");
INSERT INTO activity_logs VALUES("66","INSERT","05/17/2022 10:12:34 pm","Verna Dulpig Venderta","ADMIN");
INSERT INTO activity_logs VALUES("68","UPDATE","05/17/2022 10:32:42 pm","Henry Misa Hisume","AICS USER");



DROP TABLE aicsprofile;

CREATE TABLE `aicsprofile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(255) NOT NULL,
  `middlename` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `extension` varchar(50) NOT NULL,
  `sex` varchar(50) NOT NULL,
  `address` varchar(255) NOT NULL,
  `age` int(5) DEFAULT NULL,
  `relationship` varchar(120) NOT NULL,
  `civil` varchar(120) NOT NULL,
  `contact` varchar(120) NOT NULL,
  `educational` varchar(120) NOT NULL,
  `skill` varchar(120) NOT NULL,
  `income` varchar(120) NOT NULL,
  `iifirstname` varchar(120) NOT NULL,
  `iimiddlename` varchar(120) NOT NULL,
  `iilastname` varchar(120) NOT NULL,
  `iiextension` varchar(50) NOT NULL,
  `iisex` varchar(50) NOT NULL,
  `iiaddress` varchar(255) NOT NULL,
  `fullname` varchar(255) NOT NULL,
  `sext` varchar(255) NOT NULL,
  `aget` varchar(255) NOT NULL,
  `civilt` varchar(255) NOT NULL,
  `relationshipt` varchar(255) NOT NULL,
  `educationalt` varchar(255) NOT NULL,
  `skillt` varchar(255) NOT NULL,
  `incomet` varchar(255) NOT NULL,
  `problem` varchar(255) NOT NULL,
  `assessment` varchar(255) NOT NULL,
  `service` varchar(255) NOT NULL,
  `recommendation` varchar(255) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8mb4;

INSERT INTO aicsprofile VALUES("59","Henry","Misa","Hisume","","Male","Caoigue, Tubao, La Union","21","","Widowed","12345678098","","","","","","","",""," ","","","","","","","","","","","","","2022-05-17");
INSERT INTO aicsprofile VALUES("60","Verna","Dulpig","Venderta","","Female","Gonzales, Tubao, La Union","54","","Married","123456789098","","","","","","","",""," ","","","","","","","","","","","","","2022-05-17");



DROP TABLE login2;

CREATE TABLE `login2` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role` enum('user','admin') NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4;

INSERT INTO login2 VALUES("12","admin","admin","1111");
INSERT INTO login2 VALUES("13","user","aics","1234");
INSERT INTO login2 VALUES("14","user","pwd","12345");
INSERT INTO login2 VALUES("15","user","senior","1111");
INSERT INTO login2 VALUES("21","user","senior","admin");



DROP TABLE memorandum;

CREATE TABLE `memorandum` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `memo_name` varchar(255) DEFAULT NULL,
  `memo_date` varchar(255) DEFAULT NULL,
  `memo_sender` varchar(255) DEFAULT NULL,
  `memo_recipient` varchar(255) DEFAULT NULL,
  `memo_file` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8mb4;

INSERT INTO memorandum VALUES("65","sds11","2022-04-22","12","31","ERD.png","../upload/ERD.png");
INSERT INTO memorandum VALUES("66","hello","2022-05-06","12","12","our-industries.jpg","../upload/our-industries.jpg");



DROP TABLE pwd_logs;

CREATE TABLE `pwd_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `session` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  `data` varchar(255) NOT NULL,
  `user` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8mb4;

INSERT INTO pwd_logs VALUES("33","DELETE","05/17/2022 08:16:25 pm","erc","PWD USER");
INSERT INTO pwd_logs VALUES("34","UPDATE","05/18/2022 02:06:50 pm","Ayna L. Forger","ADMIN");
INSERT INTO pwd_logs VALUES("35","INSERT","05/18/2022 02:08:22","dferw","ADMIN");
INSERT INTO pwd_logs VALUES("36","UPDATE","05/18/2022 02:21:24 pm","dferw","ADMIN");
INSERT INTO pwd_logs VALUES("37","UPDATE","05/18/2022 02:22:06 pm","dferw","ADMIN");
INSERT INTO pwd_logs VALUES("38","UPDATE","05/18/2022 02:24:49 pm","Ayna L. Forger","ADMIN");
INSERT INTO pwd_logs VALUES("39","UPDATE","05/18/2022 02:25:29 pm","dferw","ADMIN");
INSERT INTO pwd_logs VALUES("40","UPDATE","05/18/2022 02:25:59 pm","Loid V. Vermes","ADMIN");
INSERT INTO pwd_logs VALUES("41","DELETE","05/18/2022 02:53:48 pm","dferw","ADMIN");
INSERT INTO pwd_logs VALUES("42","INSERT","05/18/2022 03:52:33","eric jihn","ADMIN");
INSERT INTO pwd_logs VALUES("43","UPDATE","05/18/2022 03:53:09 pm","eric jihn","ADMIN");



DROP TABLE pwdprofile;

CREATE TABLE `pwdprofile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pwdno` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `applicantname` varchar(255) NOT NULL,
  `dob` date NOT NULL,
  `age` int(11) NOT NULL,
  `religion` varchar(255) NOT NULL,
  `egroup` varchar(255) NOT NULL,
  `disability1` varchar(255) NOT NULL,
  `disability2` varchar(255) NOT NULL,
  `raddress` varchar(255) NOT NULL,
  `lno` varchar(255) NOT NULL,
  `mno` varchar(255) NOT NULL,
  `eadd` varchar(255) NOT NULL,
  `educational` varchar(255) NOT NULL,
  `occupation` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `category` varchar(255) NOT NULL,
  `types` varchar(255) NOT NULL,
  `orgaffi` varchar(255) NOT NULL,
  `cperson` varchar(255) NOT NULL,
  `oadd` varchar(255) NOT NULL,
  `tnos` varchar(255) NOT NULL,
  `sno` varchar(255) NOT NULL,
  `gno` varchar(255) NOT NULL,
  `pno` varchar(255) NOT NULL,
  `philno` varchar(255) NOT NULL,
  `fathersname` varchar(255) NOT NULL,
  `mothersname` varchar(255) NOT NULL,
  `guardianname` varchar(255) NOT NULL,
  `accomplished` varchar(255) NOT NULL,
  `noru` varchar(255) NOT NULL,
  `rno` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8mb4;

INSERT INTO pwdprofile VALUES("44","12313","2022-05-12","Ayna L. Forger","2009-08-29","12","","","Intellectuat Disability","Chronic illnes","Francia Sur, Tubao, La Union","","","","","","","","","","","","","","","","","test","test","","","","","Female");
INSERT INTO pwdprofile VALUES("45","322321","2022-05-12","Loid V. Vermes","1993-02-11","29","","","Learning Disability","Congenital/Illness","Francia West, Tubao, La Union","","","","","","","","","","","","","","","","","test","tseet","","","","","Male");
INSERT INTO pwdprofile VALUES("47","12344","2022-05-04","eric jihn","2011-07-20","10","","","Learning Disability","Chronic illnes","Magsaysay, Tubao, La Union","","","","","","","","","","","","","","","","","test","test","","","","","Male");



DROP TABLE sc_logs;

CREATE TABLE `sc_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `session` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  `data` varchar(255) NOT NULL,
  `user` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4;

INSERT INTO sc_logs VALUES("35","INSERT","05/17/2022 10:10:33 pm","Rex Cyrus Revs","ADMIN");
INSERT INTO sc_logs VALUES("36","INSERT","05/17/2022 10:11:11 pm","Cyril Cresa Bensly","ADMIN");



DROP TABLE seniorprofile;

CREATE TABLE `seniorprofile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `familyname` varchar(255) NOT NULL,
  `givenname` varchar(255) NOT NULL,
  `middlename` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `age` int(5) DEFAULT NULL,
  `sex` varchar(100) NOT NULL,
  `placeofbirth` varchar(255) NOT NULL,
  `civil` varchar(255) NOT NULL,
  `educational` varchar(255) NOT NULL,
  `skill` varchar(100) NOT NULL,
  `occupation` varchar(155) NOT NULL,
  `salary` varchar(155) NOT NULL,
  `dependent` varchar(100) NOT NULL,
  `incase` varchar(255) NOT NULL,
  `address2` varchar(255) NOT NULL,
  `contact` varchar(255) NOT NULL,
  `relationship` varchar(255) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp(),
  `idnum` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=84 DEFAULT CHARSET=utf8mb4;

INSERT INTO seniorprofile VALUES("82","Cyrus","Rex","Revs","Francia Sur, Tubao, La Union","67","Male",""," Married","",""," ","","","","","","","2022-05-17","111111");
INSERT INTO seniorprofile VALUES("83","Cresa","Cyril","Bensly","Caoigue, Tubao, La Union","78","Female",""," Single","",""," ","","","","","","","2022-05-17","22222");



